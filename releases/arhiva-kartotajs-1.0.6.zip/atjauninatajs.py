# -*- coding: utf-8 -*-
"""
Programmas atjaunināšana no GitHub.

Publiskajā repozitorijā  askoldsb/arhiva-kartotajs-releases  ir fails latest.json ar jaunāko versiju
(numurs, zip adrese, sha256, kas jauns). Programma to nolasa, lejupielādē zip, pārbauda kontrolsummu,
iepriekšējo versiju noliek mapē _vecas_versijas un ieliek jaunos programmas failus.
Lietotāja dati (arhīvs, lēmumi, vardnica.txt, iestatījumi) netiek aiztikti.
"""
import base64
import hashlib
import json
import os
import shutil
import subprocess
import sys
import ssl
import tempfile
import urllib.request
import zipfile
from datetime import datetime
from pathlib import Path

VERSIJA = "1.0.6"
MANIFESTS_URL = "https://raw.githubusercontent.com/askoldsb/arhiva-kartotajs-releases/main/latest.json"

PROGRAMMAS_MAPE = Path(__file__).resolve().parent
# faili, ko atjauninājums aizstāj
KODA_FAILI = ["arhivs.py", "arhivs_gui.py", "atjauninatajs.py", "LASIMANI.md", "Palaist.bat", "ikona.ico"]
# faili, ko ieliek tikai tad, ja to vēl nav (lietotājs tos var būt atjauninājis pats)
DATU_FAILI = ["vietvardi.txt", "vietvardi_pilns.txt"]
VECAS_VERSIJAS = "_vecas_versijas"


def versijas_skaitli(v):
    out = []
    for d in str(v).strip().lstrip("vV").split("."):
        try:
            out.append(int(d))
        except ValueError:
            out.append(0)
    return tuple(out + [0] * (3 - len(out)))


def ir_jaunaka(v, pret=VERSIJA):
    return versijas_skaitli(v) > versijas_skaitli(pret)


def _atvert(url, timeout):
    req = urllib.request.Request(url, headers={"User-Agent": f"arhiva-kartotajs/{VERSIJA}",
                                               "Cache-Control": "no-cache"})
    return urllib.request.urlopen(req, timeout=timeout, context=ssl.create_default_context())


def iegut_manifestu(kanals="stable", timeout=15):
    """Atgriež {'version', 'url', 'sha256', 'size', 'date', 'notes': {'lv': [...]}} vai izmet kļūdu."""
    with _atvert(MANIFESTS_URL + f"?t={datetime.now():%Y%m%d%H%M%S}", timeout) as r:
        dati = json.loads(r.read().decode("utf-8"))
    info = dati.get(kanals) or dati.get("stable")
    if not info or "version" not in info or "url" not in info:
        raise ValueError("Atjauninājumu manifestā nav versijas informācijas.")
    return info


def jaunumi(info, valoda="lv"):
    n = info.get("notes") or {}
    return n.get(valoda) or n.get("lv") or []


def uzstadit(info, progress=lambda teksts: None, timeout=60):
    """Lejupielādē un uzstāda versiju. Atgriež uzstādīto versiju; kļūdas gadījumā neko nemaina."""
    tmp = Path(tempfile.mkdtemp(prefix="arhiva_atj_"))
    try:
        zf = tmp / "versija.zip"
        progress(f"Lejupielādēju versiju {info['version']}…")
        h = hashlib.sha256()
        with _atvert(info["url"], timeout) as r, open(zf, "wb") as f:
            while True:
                b = r.read(65536)
                if not b:
                    break
                h.update(b)
                f.write(b)
        if info.get("sha256") and h.hexdigest().lower() != info["sha256"].lower():
            raise ValueError("Lejupielādētais fails ir bojāts (nesakrīt kontrolsumma). Nekas netika mainīts.")
        progress("Pārbaudu failus…")
        izp = tmp / "x"
        with zipfile.ZipFile(zf) as z:
            for n in z.namelist():
                if n.startswith("/") or ".." in Path(n).parts:
                    raise ValueError(f"Aizdomīgs ceļš arhīvā: {n}")
            z.extractall(izp)
        # faili var būt arhīva saknē vai vienā apakšmapē
        sakne = izp
        if not (sakne / "arhivs_gui.py").exists():
            apaks = [p for p in izp.iterdir() if p.is_dir() and (p / "arhivs_gui.py").exists()]
            if not apaks:
                raise ValueError("Arhīvā nav programmas failu. Nekas netika mainīts.")
            sakne = apaks[0]
        for f in ("arhivs.py", "arhivs_gui.py"):
            compile((sakne / f).read_text(encoding="utf-8"), f, "exec")   # sintakses pārbaude
        # vecās versijas rezerves kopija
        progress("Saglabāju iepriekšējo versiju…")
        rez = PROGRAMMAS_MAPE / VECAS_VERSIJAS / f"{VERSIJA}_{datetime.now():%Y%m%d_%H%M%S}"
        rez.mkdir(parents=True, exist_ok=True)
        for f in KODA_FAILI:
            if (PROGRAMMAS_MAPE / f).exists():
                shutil.copy2(PROGRAMMAS_MAPE / f, rez / f)
        progress("Ielieku jauno versiju…")
        # visi faili no arhīva saknes; datu failus – tikai, ja to vēl nav
        for p in sakne.iterdir():
            if not p.is_file():
                continue
            if p.name in DATU_FAILI and (PROGRAMMAS_MAPE / p.name).exists():
                continue
            shutil.copy2(p, PROGRAMMAS_MAPE / p.name)
        return info["version"]
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


# ---------------------------------------------------------------- ikona un darbvirsmas saīsne
IKONA = PROGRAMMAS_MAPE / "ikona.ico"
_IKONA_B64 = """
AAABAAcAEBAAAAAAIAC1AgAAdgAAABgYAAAAACAARwQAACsDAAAgIAAAAAAgAKIFAAByBwAAMDAAAAAAIACHCAAAFA0AAEBAAAAA
ACAACwsAAJsVAACAgAAAAAAgAOASAACmIAAAAAAAAAAAIADoHQAAhjMAAIlQTkcNChoKAAAADUlIRFIAAAAQAAAAEAgGAAAAH/P/
YQAAAnxJREFUeF5lkz9oZVUQxn8z59z3z7zdkJggYVfXwKpJoUVELQSbVAFdFrKgiIQgWAqLFnaLhWBhZ61C0M7CQsHCwj+tSTpF
dmOXwpXd1XXfTe6798zIuS8hiX5wYJiZ882Zb+YIwMrKW0X9yPwbIE9AA+6S/f+DiENEkL1Rurd169uPK3nh2vV+Oep/GTuDNbMG
BRzBgWOWYzt7DVCNNFX5XVMWV+PoQf/12B2s1eNRo44coMQjikyUkS9mu0EoMBJjK7qDVWS0qYg9hSUTRyo0XAxl6KgHFw0itMdE
QhAPj4YyNNnE1SwZyJMqIrlpNYRzBbzLDs/YH5REAo7i1FrwbLzLO75N12sSml+lII1mwXLfpQXW5//m8sOBl2f+YoqaxoXGYBiN
1xbuszijrE3d4dB1opUjse1RlXQ4Yva5p7lw5Sq6/w/DD37m/oGhqhTiXNy8xqXFaZa/+Z302W9Ib9jq0xK0yFL3esRej/Nzwtuv
LrUS1smZniqYnjtH6HZJne4k9wgnBC2JQUqIO6+8uEC3E9pZVpVR1QmahPqp22decAwRzJwQlQ+3fqFunPc2lrHKybH/ImsxmbVM
Trs0Irg5P+z+yfe7t/OU0ew74jjNo3k9syNXOhzbmWBKRpPHfapINbY296igx+ASq7HZpYUBzy/P0tRGzKvisLH2OMkmPWdfjq0s
zbB44SHuPTAL4jEaflNCUEup/uiLXzkYp7aF3MtwENtKX/20P9HYnX430DRuGmLhyW5Fr8efI7Je0l/duTlC9USo4+rhlC8L3Ot1
gtcHP5Y++rTNfuylG73pob8ZRS5b/s4nH/EsHFeJGL6nLp9sf/1++S9NvBhtDTrXhwAAAABJRU5ErkJggolQTkcNChoKAAAADUlI
RFIAAAAYAAAAGAgGAAAA4Hc9+AAABA5JREFUeF6NVd1rXEUU/52ZuXt3k2Z3s0kbY22qDW1aMYlooWKFIPhRi6IVilpEH3xQfOmD
+BHEhhQ0D6LVN/8SA+J7SxAUUwK2NBVqNjTms9lkd++dO0fOpNkm2Y2bH1yYOzPndz7nHIJgZERhdNQNDl3Mq1x+wDmbhgVYM/nz
JqCEGAYgqGoUlSanfrmyCIwoYNTRJnn/mS8+VkHqczjXA9oTbz2YwaRm2MXfTf48dkW4PdPg2eEPTdj2k43LYGdZbNkANzP+Ph7c
J9JkwlbE5dInf45//T0Nvj6Sd1H0l9Km0yWWiUiL1IYIg2vCjVFnCiMhpcixW2XNfQq28qRS+gA7S1vJLQgx9P/SC3kM5b9aUAma
nejQOZ3QScVs0iCqxUKBUSWNXrqHfrWIMrTf2wnZq5DBCVrCcVreeU8iwcxJWoFYpGsGyF85Bs4Ht/GuuQlNgGvgh2Mgih0uBLfw
dnDLU+wwg0CK1QPLCGAHmwrxQW8Zx6I59CQreJ7vYA0Gequ4c+B0Gh8dKeFQdR5H3QJOo4g1BHXeblEgKSWk2GJIFRF25MGFAs51
LKGgYjilIDWnFYGVwj6yGNKzMJ0d0IV2vFlYQCtsnbdma2yJCLZqkT1/Did687AJI7+4Dr40gXulGJlQ+bAYo7G4UkH+s7dw+OE2
71t6dhX68m+IHbY9o20KfGESQbVkoNMh4ihBbn8WR3qyOJULUZwv47HuVty4s4qBo+1AOg0Vpjxhkkoj8bnanok6BR7OQbIdxwly
2RQuvNiD44dzuD69jKf7Crg2tYAXTnZhvWKR2ARGS600KgXsouA+tCasrVmceaYbsWUcO7QP1jHe6Djow9eS1kgcI2hspse2JDeC
uC9xTwUKN/8pYXqmBPIdhn1JN0NTBcyMMKUx8+863rt8De9cuoq/iyW/J2fNsAcFQCogzMyVsbwaYXU9xp27ZQSB2pMHddFTRHXv
Vgw1hjypStivGzVakU2aVVGpbBFZB8fsEyj3ZS15EA9kT9ab55IO5xjWOpTKsQ/dVhiwI5D2wZSLzw504pEDLQhCg6w0IgZUqP3e
q6cPeuKerhYoOZfJQQAZhe7ODJ4b3I+JqcXNh8bCbQhUBUvzAycOePnUQ7g9W8L16RWojXnkK0bW75991P/dXapg9mqx1iNFaSbU
XnZiakGuSCuV7hfR4y+NFIyOb5BS7cyOK1Gi5Z01mppC5KV3yZPIZELliDSzS8o6tn3exP5Xhi+mMtkf4uoaCE4mfcP629zcbWJL
xBhEQdiGqLzy5eT42DdKBvPk+NiPcaX0KRHNQaKmjGr0kTL+2+1cZEmp+aiy8pWQ14a+tDhR/sRrw12GzVPOcQZImr2hHdBQpCtU
Xf/j91+/LW5y/gftd9JxhLW6pQAAAABJRU5ErkJggolQTkcNChoKAAAADUlIRFIAAAAgAAAAIAgGAAAAc3p69AAABWlJREFUeF61
V1uIVWUU/tZ/2ecyM47TjE5qllp5z1tEIpiiZmTQFa2HMpDoxYcQU0KKSSy1G0REQeBbPYSQRFSG1EO9RE82mVlDNqA0XabROXM5
5+y9/3/F2ueMznQuM472wYb/7LP/tda31rfW/jdhBB0dCvv3+9JPpsWbX2yRlXdFuvTMJKB0itEMLMHp/qNHj7rExNatGuV1yXjZ
+fL7ds0CNe5i9psBTGNmVfZ5NUEwgRikeonwlc9Hb/7w5eGzIz5pZLFky941RqU/0iZo9y4EM0+Cb20QEZQO4OPwYuyibac+P3RC
fJOke+WmvTNcKtWplG51cRgRoEFXxboSDKHklLYW7Idix8t/PP7yWQUQ+8DuNjZdck5kQST36ZpeREpsexdF2qYblPL7ErGtW9dh
LmTDTmXsQh9HXHL+f4I9KUPs3Tmr7CL1pyk2M1Ebs2ilMu2iBD+JajAo2VsJIogvRksehbaabEX2DgrNCLHDnEG5P8eF7Iug8KT5
GdOpkKzrtVDtANhj0BHW6x48qLuxSvViGAaqBi+B/DfgFG6jvmTPRnUeIdQ4e6qBGc4EWDYlwmZ9Dv1IYavpRpNycHX4SKnamw22
2d8wgAAbTA8W6AHkYWoWpCIDigjFyGH2jEYcmN8LOzSAoZgwx/Xhbu7GMFfPAnsPyqSxf0UR84p/YTAipKMCHuYu+GSmVC+EqUgA
M9gEyPb2QMW/w8ycAUuiB8YWn8M3/xQwwBZaGnuUWa8U0mEetusM1PRpyJBGBOBOxFhxoR8nw2ZkyVdoqTIAIpCLEU+ZirkvPFNS
MzMCq/FH7zBcx7fgqGRIpptjeaLErhAx2p/ejptnN6EQytgnBIZgDn4H35UDMgbwY3ujMoAyYmVAqUCmeJJCZTU4SEFZA+tjWK3g
PEMpBe9lfMjcUuBUCiqwoET9BDIKEYkGqqNOGyaeISVRzCgWY9x4fQZP3DMHK25pwbHDa5HNGHx4YA1WL23F9nvn4J3dtyM/HJac
lffK/loTQVAzA2Mg7CQgZqxa0IIpDRYz2tJ4YO0szJqWwfpV0zGrLYu5MxuRG4qSzCRbJoCJBSA9ToR83mHl/Km4Y/F1GMrH2PXo
AgzmYzx01w0J4Sj2aMoahLFPSjKRF+oVzX1hFcWM4XwMoxW0JjRPCRKH0rqCWNhPgPkIJpyBSyDAKIVC5PDusS6EEeOp++ehIWPg
3MRTP+kARPGNjRbvffwrXn3/TDILYufx/I6lyA2G0BMtfhlXnoEEjPN/59HcaBNt9PTmy2q/ckwyAMAaStTOUhJzJVUfi9pzYDyb
fPm8VOcFmaCeraoZkPaJXf1DqbCXjpBTpazrQWyVXkiVqAhAngusSvo5GSj/2SMiFLWnUxpTyxrIpHRyT/4bjeQUKqLNGKRklFeJ
gRZufK7VptRPSulpCo4vDka0beNNOLxzWWJUC8UqKBRd0v8Ca1QSRDVIANoovHTkFI58chYtTQF7JmLvB2LtlpqGi325qL2tD6A2
75kzKU0nf7mAZ986iWLoqtZPmEhgyQtIekIOMDXGryQlHWic6c4lQYoPKDl0ox8D6b7EwrIt+942QXZnWByKtFI2jBzyRQdVg33J
6Vi+9YQmpZGSSRm895FNZW0cDn/Q+dmhx0UDRM697qLCdm1sk4+jKDDKSNTXEkLcex8rbayLQqneQfGt0NFB33/xSrfz7hEAOZPK
WihNUqdreYE0mSBrASo4Fz52+vih0+J7zMfpok17bg1S6b0Ab2DmVlz+OL06yIGAVB+R+po5eq3z00OnRr6QL0t81Cfz6q1vZIbi
XKv3MbGLxxtJdUHaJGrRw1P7Ok/sGUoeHuXrX36kmWpaMqAqAAAAAElFTkSuQmCCiVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYA
AABXAvmHAAAITklEQVR4Xs1aa4xVVxX+1t7n3Mc8YICSGQQcnbbAdDKUWmoBa7EhAYbaxlavFUMMKTEx/vIPMiAwmUTKtI0/9Y/R
aPxjen+11GJsI2kdS4rVCKPUVIFABwo4FJjHfZzHXmbtc++d22Fm7h3nDvAlk5x7Hmuvb7322nsPMBlSKY2eHjXpszsCppToNAlo
4j15MZ1Oh3K/8+n9K1Wo1hqErWR4UgFzBSZlNKnB0Ji/DRz98YAdR0gUdCviUwSKyq/e+qPHyNEHmcMntJNwyL51C9c5BoMZMEFe
xu5nNodOvXHo9z09Paq3t9fcQiCVekWn098MO7ft262U8yIpTfIxM4cg8BxrOyUI5CgnZp+Hvtc3cPSFvQVdhQRbsxYt37llz243
2fhS4GUMMzMR3dawmQrWiCC4iXod5EZePnW074fFcLLJITHfuXXfOuU6x9mEAYzRoChw7h4wMyhw3IQbepmnTh3te108odIPPBCF
B/FhMTizwd2nvFVQAlmxCYVIn3ggnU4Za+XVXd0rQPo0wMXSeZdZvwzMRjkxFXB+wz9e7zseKazUOh2La4bEWmXlhV0tGc5EHhOM
0i6TUY9Z1aPowXKKLitCBpOy5EPVhITI80EIpN5UHD0Cg4kMf7ZEgLk67WUADwqLKYv76CZy0LOqsCIvD4VWGsUyGrPX1ZJAweLV
mb0ABbZKP6XPY5fzr8Ldqoe8BZKV4slvO//Bc/pMwaszm3KqJqAIVvkVdBPr1RW00QgeVx9jDA70DAcVaGJk4GKt+i866BM8qK5h
jbqGDBxrqGpRNYEwNPAM4evOOSQRIAuNZ/Q5NMKfUfwW4QWA5hDf0OfAhfiXa81sf1eLqggQM3R9Ehvrb+BhXEUWrnX3chrFNncQ
WXJnlAsiL9ZYh67kFazAdeShrXfFExvdK8iQW7UXKhJQijCWD7F/xyp0tw0h5xuQImiCDYEn3UEsVdmqE1BsG0DhJ7vux657LmMs
VHYMmfc90ng2dh7zKPJqNahIAMaAkknkj7+H7Af/ljYXnPfAng8/CFGXHcZXgw8RVFmR2BggFkPuj+8gd+GSjXaRB8+3xmnOXsPm
8Kz1cjW54FRiGUKhweTR8NEZqJYWJHm8XtvBCfhKGOAPV0cwyPWIwUyZgtb6SqPJH0Hy4wtwli1FgscnRZu6BGzxMjg2lMEoYrZA
TJfSFQkoBYyOhYhv/xY61i/B8JgPLSVJlGcg7ipcuDyGGz3HoQPpoyKFygct/pZ7DjGGA43533seHfcvwFg2sCEkMIbRkHTwl38O
Yfjw+3Bi0ZpgOlQkUJx5xXKk5S/KgcKUKN06jNbwrGcia9lBi0Q4IlPsbaWn9KN+oCCPS/KIGORohNqxOeBOMMRkqEig4FVbOaxm
RY2sCyJt5ZmrCfmQoUVTDUhTa5jhSLYTEIZsSWitYOThpPIi+SKvuhQu9EL/L2zl8A2WLEri1wfW2XDavqUVR362CTuf/LwNjV8d
eBSvvvhl3NMUx6a1zXjtp5uwZ0c7cp6JQqdaTadAVR6YDmI01yEsb67D9REPiZjG0mWNqEtoXB/27P0FTXGMSqwT2WcLGmOW+GyV
F8yagHghNGwTcP/ODnS0zUfukyweXrUQB5/vsGGWzQT4wXMr0LIwgdy1LO5d2oB4TMPzzKzXTrMmUKxGkgM7n25D4IXIjfnovHc+
vtC+EJmMb+N/++ZWmJDt77alDTaZxQuzXbjWhEAxn4dHPKuQxHYuH2I0E9iSK7+HR6Xrj57Z8CmrTLNBzQgIyucHRys0Njg2znPZ
AIGtQlHGztbq5agpgVI4uQqZXIDX+i/CDww2P9piEzfvhbOO+YmoKQGZFsQLovz3X34ffz45ZD3w27cu4Ofdj2DBvBiCIJoPaoXK
zdwMIJUomXTw1onL6D85hOaFCbQsSuDvH17Hq+9cRCLh2HdqiZp6IApw4GbGt3ODlFdxS8xVGM74tdS7hJp6oAhpJ8qbMLm2LcYc
YE4ITBYktQ2cOfbA7cSceOB2oiIBacCkJZ5JCMu78o0u/Mm1yKkWxe+LC53pMG0VEkGZfIChG3n4QdnabzoQkPcMhm56pYXNtZue
lVNN9yljyqwt38+vd5CMy4751ANOSUAESc/++JrFaP/cPLS21CGbC6M6PoVAWcBkswFW39eEPTtW2dbathL5EI+0L7LP5B3YE7hb
IQ2ejLG4KY6932nHmcFRvHniMuIxNSUJS4BkLTcB4vJsLsDW9S149pl2YHgMMLAT1bRgYMPaZmz40mfGidpNVQPkQyQTlaeelW3z
sfKhJeg/dh5H+i9aL8ipwKdQ0NlKC4kvTdzCEEvVJRwc+dMlnLuUQRCYUrNWCfKt7J6Mr4OlC0XVeSDfy9LzzOAIkjEdea0MJPvp
jItyyxLQgXrPIC87JKUzMbvjEFN4d2AIx/56dUZJXAvI+DKDy8quXH9iVsYEFKrweESgp0ed7O093dm174R2418M/XxYPNyTD+vi
DuqTtVBp5rDHrOW9U3Q6Q8bPn+XzZ9+V6HdSpzsoLdGtaD9Ab4KUbBlIebV1b7qku91gopC063LgHzh9Ou1t3NjjWCVLJ5Vd3Yfd
RGO3nx8N5G2i8ZC6o2A2orwbr3f93MgvB4727SodsxYUo1TqFSUH3au79r6kY4ndsodpAs/IHtSdVJ4YihxXKeUiCLK/GPjdC99N
pVIqnU6PH3SXIP/g0dtrHuza+zVo9yARPaS0U5qQbjfEuiYMwRx+wMYcPvXGod9Eu7HW7sWt1AkokJC7a7b1bDDKrGM2rcQs5aD6
fmA2sDWemEh9BKgTTaPof/vt3qBct2kx1b+23EnIqfxk4/8PI2KgMBQ9ZTEAAAAASUVORK5CYIKJUE5HDQoaCgAAAA1JSERSAAAA
QAAAAEAIBgAAAKppcd4AAArSSURBVHhe7Vt7jFTlFf99jzt7Z3YXWJaC+ALxhWsBgUrpP65tJVWk1teYpmliTBMb/2iqadOoNC7b
VqvSVE0T28SkTR9JGzcpwbeJaSQpxlYTRVgU1IUAsix03zuv+/hOc767s51d9jV3mWFo+yM3w97c+91zfud855zvBcwM0drapvma
+dHaQDr9vIrkJTGTRNM+kE6nVUdHR1jayIYb2+blVEHN1PDZgNR1tGdn+0Dpt5mMjo67xulQiqkIEGhrE2hvN+u33JsKzOItJMXX
QbSayJwPArN7NnScFkIIAyFOQIhOSfLlEN4Le19+vD96ib1BnCb0JAT858HVm7d+R0j1kJTqUggBMqG9ahlCSgihwPKa0O82hp7a
+8rPtluZ29okG3UaD2iTQLtZvekH9Ugkf6d0Im1CHyYMQgiQIEiI6bvNWQeBaNQ9pVRKOnUwvve3QjD87Y9ef7p7IgklHkAinb5L
Hhi42IWTfEkn3Ot9LxNESgt51hWLBSIiBDqRcsLA6wwod8P+V37RA7QJNjQ3OaYYK88Bj5zE71n5oJDxBIQ+d5VnCIYTeFlfaedq
DWdHa2ubSqf3s+Gt8S0BUaTsCFfdvPVu7aTu8L2sDyESsUivQUQk5HydqN/YX+89zLqm02mr+xgTG9MPuJkR92Op9PkUBnRuW35S
kBCCu0TBC+nSj15/rBtok5JdgnNEdiS5WTvuBSYMOJWco31++ixpyBjluMmEpG/xk62tkKWK3gEhiKN9DXrxmQGxC4REQtzGDe66
HmYsC6za/HCnUk6LCbya9wAWOp6VWHcljDG9nuNfcuCF7cPWA7i8FYQltsiJmefjCRQPJnYpIkDEb1NTMovzxrLAiBnSBIpd37Py
CRjIKtDA1q9DOLcvCSEDGVp9rQcopy62AVnpLBzcrQ9ijexFBroiRLDiBSgsE8O4T3fCt0VpfAihrM5zivasfA4aLaIPX5GfYbM6
AhfhHFx0anBs5tLtJnUUraobG+QpZM8A2XMioOg2d+oueFBYKQZwney2XqDm5qTjEHmZxlrZiy/KkxigBO5QXUgimDPZsQlQInL9
L8keXCN6kYOCD4VvqMNogocgbjSdACF4ICvgwOBO1WU9IQ+NFWIIm9QxZODMiex4BBCQDwguBbhdHUIAaa1UgMSFIoMb1VGM0JmJ
BRQaDAbKetZVYsB6goKxXW+LOoLPIYcCxY8HZRPAbu8ooH5BA7a4x7EcQzY4cUBiEtgiTMBlTnbsfmwQ4KYSWDEfuEUdtu3xN/hb
THozcrgtcQSBciB4EBwDZREgpUAuH+DzVzTj1UfW4Na6Y8iQghwNx/zDEwfz4OHOuiPwbKSOKZgQyOd9/PR71+K3m4D52QEEMiI6
it6EDDnYpI/jCj1ku2BZyoy1UybYJZ16F8Hut+D19kM6TtQCd1YhLBlZkcA6/zNcLSOXjVUfsEXrEnD6/4Xc398GuclI+dHv2Bkq
KSEDH1uoC0byV8onuzzSiCDcOnifHsaJV3dBaI0wX4DxvHFX6HnQfgG3mwPQVqzyMzYP27SjcXLHa8ic6AXIICyM/xa8AjI+YUNw
DF+gHuTglE12eVPdRDzNhJbcMbiLm2GmsS5H7mt8Hy0n+rGXFpaVspguXyicHw7iIjECZ8UyyJBH6Ke7qyEgKQ029ffjvcFFoGJ/
nCXKI0BKmGwBn7asw+UPbkA2H4D76kQYIiQTCh8fHcGnj+y2pWs59bstrQXhs3wC5u57sHrNYgxnfRuDJiI0hMaGBP707Pvw3jiC
ZEPC3pstyusCo6Mwf+b1hjGE5X8iCik20gtr4ZlQfHYWj56GsgkoCjd7xBErGu6WEznKebYUsQj4b0J5MWCW4LjgBQZLml3s3H4d
nvrzR/jrm8fwzP1rsW7lQmRyAR545j30DXn4zY/Wo3m+i0PHR3Dfk+9i/com/OTeVdBaYcebR5HJh4CKa9+ZURECbKwgwNECy5fN
w4IGxwamixan7N9exkPCkVBS4NILGtDUnLJpj//VuxqXXdzIL+O85iTMbILAHFDRLmCXaAohsvnoyhVC+3fOC21FmS0E9p7he8Xn
CiG8goneKwRlRfQ4qJgHMLgrFLwA99x8Cb62cSmuXDaP56ShpMRj962x3aQh6cDzQyxtdvHHto1YwGksJBgK8NV1S6A1l8QBz+3H
0W9GVJQAljkICFdc3IiWFfORL4QITFQXXnvVQqtUrhDYe8k6jS+vX2KVz3shKACWLnJtNuA2KqR/ZQmwKVPAKsRuzoVM0Y4cCK2X
jN7j4mk449vcx57D7/lBlEIrpbz9/ow+cgbAluaAV+rExaqOg1yxUuB7pZVlcdxTSVSFgIlgazMakhoNKceOICsd7adC1Qlg5d2E
stb9x/4+7P7glHX1VFKfFRIqGgQnszwrf7g7gwef3YPOriGb+5cvrcej312NtVc2IZsLJh30VApV9YBihcjKv/thH1JJZQufT46N
4Ie/eh+9gwU4Wtr6oVqoGgHcx1N1Cvs+GcS+rkEsmu/alMcVYlNDAkd6Mnh7Xy9cV4/FiGqgagRE6UzYlMhhvxgIGcX/c51QbVSV
gJlyeiXzfc1kgVpD1T2g1vB/AmrNItXG/zwBZVWCJYsyc8JYO6OtnIlBj93vFy1OlYWyCAhCsnU7/8YFV3m2jYAnPaJ2SEb35lIB
ckEVR7ZZE8CiNqY0HCXsbxwKWEGe4Vk4L2EnQIoE2KGyhJ0njEMCv5NyNZrnJezocojnFWYJ6zCrbn6wCUZ0SakW8D66iY7ENTzP
3Pzy+2ux8epFtpqLQ4JdwAgJGZ7imiAgE5qsU0jwWGCWwhfBbXGbLOeh4xnc+8Q7U7UwttxAob9y7+vbD1gPkDpH5KWm/a4xwHnN
LhZe2ACMeGUuW5RAAE3SnVxAngEuV/tRNDY6gKvHZpGmB5GQ0SYpS8CenU8Prtq89ZSUsonYRBP2CvKT7LpvvNODoydy1gPG7TEt
A/arUynJQayMtkrB3PE0fE9fYZoWeG5RwZhwUCZyJy0B0U5xEYIe6oTUl5PwefvouPTIc/bsms/t7EIQ8kbS+Hs1KwfeBEk2ntQn
pwhtJIzQSoHCT/bsfGaAdx/pkyc7I9JJ7hTAbXYxfxIzsNEaUjq2haqJqVaHSfBWWdbBf4nlaW3dpuSuXdvsGDQJvSP0c31S8joU
jTtXUwSP6bnxWr+mAHGuCf18CCX+wM/wZmnJJ6m4G/zztXaen3pMOa4kQvUH5hUGEQUqkZIE8+sPXnz0EB8J5ANUY84enRF83qy+
6eE3VSJ1HR8z4ZMWFZarKiAygXJcTaF/0B/R6/dfjyzat3G65xosQkdHi43NRuMuPmCkE0mHiLiiiJmYagJ8asq3yhvTHZB/6/5d
7SORZNEZwpJo327Qtk3se/HnPV4wvCkMvN1OXcrhkE+gIOoWtk6r8csuM4csM2up61IOmXC/H/g3dL7y5IdF1y+a5/R4P3q4kM/e
9jUEP5ZC3i+VM5/32VMY2P32tQw+7SN4P6HUMKGXB+G5fH9+64G3tg9PdhR4irojOkDJiq66se1CIc03IWgLCCsBswjgo5k12TO4
X/cJIQ6SEK8h9P/ywauPH7QGm+TUqO0I01hT8NGy0sPTV97yRKP2hhYroRXv3icTxi3cziiisrYOUoZEWp0qPUA9anU2ZlyLtfHJ
Mm0ZPGdA9sj/bGT+N463d19Y7HQRAAAAAElFTkSuQmCCiVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAASp0lEQVR4
Xu1dC4xc1Xn+zjn33nmsd7FjsthQG6w42F2zJsUpIanIWjiAHaAtoeNSFKIqVUBKVEWUJrHjpuNp1NokhVYqKZKt0geqlHhaVWAn
JMVJWClNoZExtvHGmNgBG4TxA3t3Pbsz93FO9Z87dz378O7OzM7jztxPsmzvzpx7z/m/87/Of84BIrQ1WB16zwBVh8e0IrR4ajp4
c00AhnSa9b0I3t29SmV7DitkMrIVRVM3pNM8NTDATp/uYf3dAwrZLI3nnJFijgigWF/fVtHfn3EnDswtqUcSuZHuODfySrqFOXpe
a4MbMT1WVkHJfXsfG5zY276+tNG/FnIuJld1AimyM5vNevolUynxkULPCnjqdgl5IwO7VkpvOeOsE3LOSNs2UFAe42JASXmWM/6K
C/XTODde3bcnM+IPgmJIbeQIxr8CVEyAVGqXyGY3asH3rk//BuPyfjD5OSjWI8yYIC2llISSHqAi4VcKJgwwEhPnkK4NJeUJJtgu
D+KZ13ZnDvrzLiWyFZqGCgigGLCVARm5esOm68HNTWDqPiGsLiVdSM8l0fumQDHGGH2eRY5ghVCKSW3ymR54wbjBuLDgOQWPcf4T
qexvHfr+9r26+XSal2sWyiNAKiUCdbP601v+lHHxTS7MKzw3T7PdZQocjIRdZrsRyoAiYyoZmMGNGEBaVsl/MPL2N8hfKGoD3yTP
ArMmQKDyV9759cUxwf+Zm7E7pZuHJMGDiUjo9YdSymM0+GaSS88+Cs/9/IHnt/2PdhKncMinwqwIEDS4av2m3zYM61nOxWLXzbuk
knz1HqGRIJMruGkoBle6zhcPPb9t52xJMKPwApVSFP6PGGMLPM+mWW80stMRxsPXBpxzw2Kek3+ISFDqqF8OfLqBTKfTnEK8G+/4
6s2GYf4IwALPtb1I+M0HxsgMS4oUPGHGd/Ru2PwFitKIBNO97TQaIM2BjLrhns3dQoqDjItuLXz9oAjNC4q5ueSGKVxn5I7Xnv/W
C9M5hpfVAKnUKiKH4h57hguzW6v9SPghAGNQkinPU5xZz6y+/dHubE+Pgp7QkzHlD33GbPR6N3ztS8JM3O47fJHNDw0Y41K6UpjW
Vcown6TcQCo1MKW2n0SAot2Xa9Zv+RDn1jbp5qXv7UcIE0hbu86oa1iJVO9dW1Lky03lD0wiwMCAZoqymUxz0+qUSsoo1AspFLiS
UkGqv6ZFueyuFK0kjtMEEwig9MLOmju/vhiMf0baeZ1+DGn32x6MTIFrS8OMfXjkYmwdGFOpVGqczMf9h5Z0adQcrh4wrHiHBK3k
RImeMEPRIgItxzH2MPXDdwgvoUQd0D8lW/PQDsM++eZ+YVirPM+mnPO0uYIITQ9Fq4mKsbxw3NX7/3v7r0oXjS4JN/2XHGAq//ax
5YyL66Xn0Bcj4YcfjPw4YVgJz+SfpO5QxVbQrbF/BD/kStwhzJhJxQjh73sEDcYoO6SUVHfTf3VpWRFjBOjvXhX8cI2KCjhaCgyK
K4/yeKyHogHsorpC8u9RYgKogNNny1KdTVSR89dCoOwgiXXRqN0V8/1CH0UNoBgyGbXid7/SyRSWUWWPX8kToTVANkAqLkSS285y
6lM6TVVdpRoAUCLvmoqp+cUavoYRoISgLYOG90lRJChMl8v5NKjFhN/4PIAwY+T5TyrtrieIdYUWyz01T5+oZk+Mk+/kMI8yBw0C
PdgFwwo2CIPqXBr0HnOJpuuToqWdS2iaOD8YqHlw8VXzVVzPL2AUBniIaRCGPjUNAUjQeQjcLt5GNxvFen4SJmSIxU/2tfn71BQE
oIEahcAyNox7xFs4oxJYw8/gk/xdDMOCCCENwtKnpiAAQYLh98WbSMAFrVnaEJoMC1DQfkHDHJMqEIY+NZwANFNyMHAjP4db+bvI
wdQOIJkD0gjrxUn9szD5AmHqU8MJQJ4+Cfwe/lawdFnMUPnE+JR4B4sxAps2HVUxG+uJMPWpoQQg2042nmz9b/GzWuDBTCdhO+C4
EqO4zzgemoggbH1qGAGCEIlsPNl6svkT1TwNJqn/3+Gn0MPOY6TJw8Iw9qlhBPDtpKltPNl6svlTqXhypOLwsFEc16q1mZNDYexT
3QlAa4yckZfPtW0nG1+q+ieCBnUEJnr5OdzEz2pT0GxhYZj7VFcCSKXguAqe6+GiFLjP+LW28WTrp3Pw/JnP8EfiGEzlwdHb5ZsD
Ye9T3QhAJQZxS2Bhp4l4VxK3dAzjE8wP+2aa0UFG7ToM4q7EKSjL3xffaLRCn+qyw1cIhvNDNj634cN4+N4PYdjhOPeP/4SRwzaQ
SAC09WAGkNnIuRx//IF38Gt2LV49ydBhoWFHD7VKn+qqAWIGQ+eiLohjbyA3cBQqHp+V8DVouhkGnHMXsOL0ESjTgq50ayDo8WHv
U90IoA+NIm8pV8CJ7+7RNp2XWXVGRRV5buIe4ySuY0N6/aCxGcLw96l+BJAKIpnAUP9LyL/1NkQ8RidelTV/gzib1gto3YBCxIai
BfpUHwKQ124ayJ85j/d27wWPxahCqSLZBckhWjeg9YPpQsiaokX6VBcnUDt58Ticl/8PtjcIHrP89b8K9534Z6UKbQoO2gsbkxxq
kT7VnAB+IkfgBnEe60aOYMijUi9/ybcaDIPhJv42NoiF2O0tRSecupmEVupTzQmgwTiWeRdQuPoaLOi+AsqlPadViJ8OQREcIxfz
WPzmRSTh1U34Y2iRPtWcAOSodXAP/zW0CMs+tg6PPLgSFwdtHUdXCtry3pE00b//NJ7K/C8WxAGvMpeiIrRSn2pOAB3Cg844VTDo
rNvRAmTeBquSAIpLMNuGpesG6+PLlqJV+lQXAgSgPACjlB7F/2XmAMZBf91vo44Tf0qEvU/1nzoRmgoRAdocEQHaHHX1AWoBWk/g
nHY/0wUVJVFa4CeUOgmMclLjvYZJ6xF0s4GauS16Zisg1AQgYebyxb2ODIiZvkIj4Tuu1MUnE0GfCYRHvx0puJMuNKHfz9QWhbET
yRRGhJIAFAHkbQ8rr+3Cv37jY+hMmjhw7AL+9t+PoCMuMHjRQeq2Jbj3tiUYybnggulZTQUp9JlDxwZhmVx/9ttf+gg6kgIeHYij
FBIxAwePz9xWMmFgy1MH9XtUFdE0GCElAOBKhfnzTKy9qRs8aerZTDOSyEEzf+miDtz80avgXfCTTlS6xRMG5j97TH+XViMMg+Hj
vQvR1WlBuaT2FXiHqbOUM7Y1z9TPp7bCjFASQKt52kouFQo5B53KV+UByATYjoSXczA84owRoEMq/Z3AepPPcHHEhSEY3CIB5hXN
wkxtdRZJGHZPILQECEhA9lr/mZBYov+K4HfksNH6AZ+8x3Ds+9wvOtLfqbCtMKJlwkCSGc1kUvf09+WqjUjAwefo31OhnLbKrWpq
NoRaA1zS0+T1K5wdtOF4/t+jZBImyJcEO5Rz9O+TMXL89MlZ4zHLtuhzgznHNz0htgOhJ4B2+hyJpVclsenB39Th20je086dU5Bj
IV/gHKbWLcXNq66EafihXtzimgS+1i+jLVviwfXX4eoPJuAUvNDmBVqAAEDBkVjSncCffXalv/RIDpotkS94YxEayZccwz+4bQkt
TfqznpzHEWcsnicSzLatgi3x2fXXwfMURvOXnhM2hJ4Aet4W1XZ+0NaCJg6QUzeVM0cmQM/4ohc50Q8oty1/W1h4bUBLECAgATl3
M+Fyjl8pAidwJsymrWZHy0QBESpDRIA2R0SANkdEgDZHRIA2R8tEAeWAwkBaHRwrFimGciGO5ipG2xGAlnkNg2NezLiUEJKAbXso
2J6uWp45mGwdtBUBaNZT8cj7wzZefOU0Xj8xpLXAooUJfGL1lVjandS5/Xa6KrNtCEDFHiT87+49ge/8xxs49X5eryHQdKeEDhV3
fGbtEjz6wAptClxP6VNJWh1tQQAS/rykib96+jCe3n0cyYRAZ8IAkkXxKsB2JXY+ewyHjw/iqa99VC8UUZFIq/sFLR8F6H2ECRPf
e+GEFv6CLgsxQ8CTSi/k6D900ANnuHJ+DD87cAaP/dsvYQgamnCXe80GLU0A/1ghjvPDNp78z6PoiJPCo7uUJwuWfkSVxESCXT8+
gVdeP49kwmyJyt/p0OIEoCpfgZcPn8N77xcQs/jMB5JRQagCfvyLU3418WymUYjR4gTQ25Jx5K0hXQswm/iONAEtJdN3pEunmIRY
urNASxMggFGBOz+bpeVWQFsQoBI1XuEZVqFDWxAgwuUREaDNERGgzRERoM0REaDNERGgzRERoM0REaDNERGgzRERoM0REaDNERGg
zRERoM0REaDNERGgzVHTquCgmqba0+HnAsE7zFThM9vP1RJj71DykFrVJ9SMAFR4KYs3w/gFl1MXY9YDwf2+VOZNVcDTgcrB6F1p
X0AjEIwVvSu9tz7xprh3oRaoCQGCO3XpaFaqyaej24Kf1YrJl0Pw3A90WZjfac6CAP4xcrRvoN4U8KuYGRZ0WvoYWyIAbVRzPYkc
nXdUAwbMOQFK79R96L7lGB7yT+oMzuodLZ7cWQ/Qc+l5f7huKX7v1mv8W0ZmAZp3tC+gQKd/zfI71YIOrBy1XfQuuwLff/xWfdIV
7WmYlzTw89fO4cuP70MybkxZ0l4N5pwAhGDWdXVZEHT6pvA3XNKeu6lq8muJ4F2S8ZnuKL8EfdCUgt4wUk+MaQDLGjv7OJk0a6qN
JhGgeBtu1dD2i2ypPoO32Byd4V91y+XDUwrepaOEZ406Tf5xCHwAAmkAPYZz6I8oJceJYBwBuDGqpNPhzHqEpoHefq+dGN+R8VVD
uDZb1dtfmQg9dnP5EkpJxTBuKhQJwBTSaX4gs3Ww99NbjjJhflA6UjIGUQkZ6J1Ng+vj2TtsWdUdge0M0gA0hnSaaXVQinHBpXSH
hOS/pLay2V16p8wlDTAwQApaQm0+XY3uCxyX5372Dva/cR4u7a6p7u3bFqQ5KSK5MOzo3cpVaQOyZ1IN2qPWaOmAjhGg73QP66ff
MLzCGLsXbOw8zbLgz36GE6dy+NXJ4cYY/VZC0YnWIXWF/VKKSc4NIT339YH+zEXS9sgwfX3zGAG6uwd0+wL8J9J1tjK6jrPCqUsk
oCtZqnnpCD6CiKSq6IkppUNgxfZSm30vgvfT9e2lBAhsQrxjZH/uYvwUF8Y1inZH0i3JFUCHUXPpwESoGExBSNeRMPACNRJMdkKJ
cJnq60sbL2X/bhSMfY8bOhat9pb3CA0GRcDciEFKd9/KxBsHSP1ns1m6ImsiAYC1/b7AuXCf9tyCSzf9Nvj9I1QNBebfk7eTBE/q
v7TJyVZeOwgZ2bth80+FGV/rOXmPMVZROBih0SDbL5RS8oLJ8yv27XniXPFChTF/ctIMT+lwUKdCt0JRCFehJxih4SA3jJtxrqR8
Yt+eJ86mUrs4yCMowZTSTaVSgtTF6g2bvyOs5Bdde8RljNVk3SBCbaCU8oRhCc9z9nsd5i0DPXCRyZDwxxFgShuvI4J0mhdMd5Pn
5o9zYWo9UptXjTD3oMwfJ5F5THp/MpDN2Gn/IZNSCVMSIFATrz/37WEo7wH6HtP+YBTXhQFKMdewkoZ0nT8/+MPH9pNGz2QyU07g
yxAAIEcwldolDv5g+8vSKzzMDUpIcxmRoLlB64dmLGm6hdzOQz/c/vckw9KwbyJm9PAoN9Dfn3F7N2z+gjDjO6Rre7SkyHyVEKF5
QOrZNa2k6dojOw/+4G8eKkZ0k+z+jE7gRIwnQWyHkh4lFihPEDmGTQBy+GhCGlYHc+2cFr7vyOsVv0l2vxSzmsWkAYgEh57ftlMW
7PVK4V3DTBj0YFpjboIxaFPoiguXvH3GyeHPPULCT+ts38zCJ8xoAkrh25ON3opPfeXqeDz+OOfG/cQBz3V0arFoFspqM0IFoMIO
QHEuBDdjkK7zspL2l8lfI+Fnpgj3LoeyhRXkCKjB1Xf9xf2M8y2MiRuoIc8taHVUZBYrVmGW/YwI4+DXVlF5EIPSFeIixhjnJPjT
CupJ89Tp7fv27XCCCVrO+FUoHMWQ3sooUuhJpS0rJzdIyM8DWC/MmEXuCPkJZB00WauqZGhvUCUPFXMwbuj5JD2HGPFzpti/eNx5
7rXd297TI1RM4Zc7WhUSwEepNiDccPfmlQLmxwF1t1JqJYDFDFjAhBFFj2VD11FDSm8QSg2C8SNQ7AXO0f/qnm/+ImiuOOtJ8NM6
e3NmAqYAoxxztuewIo1Q+mJH7Xc6PfvMcmHGOuHmyx6C9oZB4vcsbgyYia7cS9lHS0u5WF9fWvT3b6W9VxUJPkBVGmAS0mlOy41U
cDBd8iFCBSiObT9VbpWs51eLuSXAeFANEpDayFPVvmUbI6jUqlTFR4gwLf4fnyt/iBFkbswAAAAASUVORK5CYIKJUE5HDQoaCgAA
AA1JSERSAAABAAAAAQAIBgAAAFxyqGYAAB2vSURBVHhe7d17kGRVfQfw33nce7t7HvvGYCySohSpARZTGx9rxEERWGUXNWZMiIkV
YwBLWIlRAhGp2RFFjFrEEqsUrPhHpKg4VajAwi4oOvhgFx3EfQlIrWAQZB+z7Lx6+j7OSf1uT88Ow0x3z0w/bvf9fqxRdlh77mPO
97zuOZcIAAAAAAAAAAAA2ppok7Nrl/OA1mNb75BPaLWCI4gsbdhwuS6dwvDwrUEr3wBobb29/Xp8/Pm4HJ166jEzODhops+oJYIh
6QEQH9+GDZfpcgX9DR/4SvfxsWdt5OeSfj7QJlYT0XiezIGhgfH5TomD4aSTDtikB0JCC4wVvb3b1NDQQDj74nJBH5143nEL8jIh
RNaSjSzZjVI5G00UGkFWtsnvFyQeN0atbwXdJoTIK+0pU/B/7pHexYf+yI6B0dmn0NfXp6bDIFEtgyQFgOjr65OzL1JP70c7tbsu
Rzr4sBCil5Tigk7azXaL6UM3JiQTBVT6M0AjKSdT/HFCUOTnyVozaokKWme/afyJH3trTt71yO1XzYQBtwyGhrZFRCIRQZCAAHh5
bb/hki+tDY6PXEFEVxIJT7mZLmuimYJubBTOXEBLUghCzQ9NYMmSKLZSrSUhhCNE8VdRuVkK/UmSQr1IQj5ibfBlLxzd9ciOr5bC
oFThRU048BnNDADR29s/08x/w6at3VOqa6OU7sctmY1S6m6u2fnCxgXeCjGroDfzuAHKiWt2a23IgcAtA6Vc4partdERIrrFWbH6
a8N3fJL/mf+moP5tggYGSoOHDdWUgjTdH4qTr+eC/tVKhR8Twl4hhForlaYo9MmSCQWRouIhNuU4AZapFAZGCCGFVEIqh7uto0LI
n5so+q8922/YyT9jw4bLnGbMaDW8YJ040T519kWnXW8tXandzJq40JvIWlu8WCj00H6stUSRIKmlduLWLZHYSWHhy4/d9/kHiPpl
X98BMTjYuG5BwwKgWOv3WKIBc+Y7/+N85XhXa+WeH/gTPHBSqu0bdjwATVSs6IiEcrMyCqdCQeJzv97+5A1Eg1EjWwMNKXC9vb16
aGgoJOpTr9v82k8bY65XTkaFfj4QQvBDPQ05DoCksdZGPLrleJ0yjPwHoqDwxX3TrQGibbbeswV1Hz3v7++XXPjPfOe/n3/2xWfc
p5zcNi7woZ/nE3dQ+CHNhBCKiKQ/NRZIIc+XQty3fvOn+6mXy6aw3HKu5/WpY81rBdE2wU3+9Vv6NwtrvyelUmEwxbU+F3wAmKXU
GnAz3dLPH98eRlMfPHD/zSPEIVCncYE6BUB/sWXRS/LsjvBOqZ0tURQYawxP5tU10QBanSUKlHJ4lHAkDPx/3LfjpnvrNS5Qhy7A
dOHvOyDWd4bfU252Sxj4EVkjUfgBKhNEThT6PCW2Wmv3rjMvvOYiniLkEKj8/16cGrcAZhX+ydO+r53sRYE/GfAJLe6wAIBnCqRU
JIS0YehfXI+WQA0DAIUfoOZ4urCOIVCrLkAxSLjZj5ofoHa4+jdRnANxd2DTte+qZXegFgEQP9PPA34o/AB1MDcEpscEajFFuOwA
KC3oOStXuFM7OfT5AephOgSMjYR2Mt/v2XTdW/iRYX7Ibjk/blkBwAnEm3acsemaLdrJbgn8CQz4AdQLh4A1RkipHEk3Um+/JjqX
f9qSx/KWHAClFX3rN133FsfJ3hlFPj/Pv6w0AoDyBAkdBlORcjLncKs73jWrr2/J5XipySF4n75g9Wtc4Ry7T2rvnLC4oAEBANAY
odKuDgtT796786a74xBYwtOCS0qOmU061dFPaq/znPjxXhR+gEaS8T6YSt5x8ub+LPXwStvFl+dFBwA3/Xkagpv+0sl8Mn7Qp7ii
DwAaRxpjrFROdl3k3xHvKNTXt+gW/WIDIP4B68//YoeQdKOQstOaCJt3ADQB7zbGrQDleBefdeG1Fxe7AItbPbioAOCmP089WD1y
tfY6zplez4/FPQBNY0XcFZDiDt5ejyh+MUnVLYHFBIDgpj//ECnE1tCf4K270PQHaC5prImUm8tqHWzlXUa5oq72kKpOing54qnH
zFnjr77e8XL9Ae/mg0U+AElgec9Ra83IpOk4/akd103vOFz5JSTVtgC49g97qEcJsldEgc/JUXXKAEBdCWNNoN3c6qya+AD/pGpb
AVUFAL+xh5sWatK8UepMt+XVCYvoZwBAnVmS1oREJnonl1V+UWk1P7GqAGA9ff2uMOFnhRBuvLkxACQGzwjwJiLayV5wxqbrLuDB
+moWC1UTAPE+5SbwuoSgN5nQt3gVF0DyWCIjpLZK2E18dAcPrqpYviv+hXipL1nh+uNXSienDFl+F1rVg4cA0Bg8LhcFU1w6/+G0
zf1rp980VLasVgoAwYsNenq3dRDRVhP6CoN/AInFg4GhdnPrsjb4MB9lpcHASgEQ0y7lBFmvilkFAEgCQyuXPQZQSg/rBn+v3I4O
nmpA8x8guYrdgAIZsv88eKgnfnivXJkt1wIQPJXw6k1f8YSld8Wv77PVtRgAoGmEtZGRylm1vjM4r3gUC+8XULYLwKP/yp1yydpz
TRTwVENVXQYAaB5+A7FyPMda0ctHsWHDwrMBFQu0NZMeCTGJgX+AFmJN3BSo1GVfMABK/f9MFFyqnWw3+v8AraE0DkBkP/Lai7/Q
WW4coGILgIhy/ArT1jh1AJghKDMlJssu168YAFbQKJr/AK3HWhs+8+wrJ8od+YIBMDx8cvTqTVs9svY8HgDEDABA6+BXjSvtZs9Y
9/u3FY96/pmAhQJAEA0YE/5pRgh6O0//YwYAoGUIy6/j1p6nlHk7H/VCMwFluwBS5y1ZmkAXAKAF8apdI5bWBZg1kFBxnAAAEqrC
szso3AAphgCoEs+DYi40+XCfFgcBUAX+pYpIUIgISDTcp8VDAFQgydKk1bReHqV/1XvJJ4UYSCDcp6VBAFSBl0FeoJ6lc9Vz1CNG
KE8q/oWDZMF9WjwEQBlxrUKazpZH6SwxQmPk0Lv104u/ylBXuE9LhwAow5IgQ4I262dITXcFzhYjtF6M0Dg58feg+XCflg4BsAC+
MNzUf7N8Ia79J2c1+9+jf0dZCuOBQcwMNBfu0/IgAObBhZpH/FeRT5fq31BEMv4eX6xx0vSX4gi9Rz0ddwkwFtA8uE/LhwCYBxdq
rv3foZ6lleSTPx0AjJv9x8mht6nn6BWUp3DWv4PGwn1aPgTAHFyrcIHngs8BMHfEv1jryLjwcwhwGGAsoPFwn2oDATBPAHCTn5v+
3AXgrsDcfj7XPNz8524Adwe4W4CuQGMVH/rBfVouBMAsxekkFQ/68eBfsfZ/udITZzwQyAOC0Fi4T7WDAJgHT/vx9B9PLy2Em/08
FchTgmeLo/HzAmgFNBbu0/IhAKYtp0BX84sItYH7VFsIgOlVfjynv9gmfbVNUaiNpXa9cJ8WhgCI5/eXPqhXzWAU1AbuU+2lPgCW
O61XaToKagP3qT5SHwC1eLCn3AMpUBu4T/WR6gDggluLR3sXeiQVagP3qX5SHQAltVjcU25RCtQG7lPtpTYAZtaQi6M1W947e1kq
1AbuU32lNgDqUVjr8cuadrhP9ZXKAGhEc70WzdW0w32qv9QFQL0H7Go1YJV2uE+N0dYBwC81n/ulxMJr/WulFlNWaYL71DxtHQBh
ZF/yFUWWJkJBK+38a/1rpfTQykmUp7er52gk0iSMqdXHtx3cp+bRzfvR9cWFsCunX7qa31oyjkP/EjxKK41PeTH/ct9aKHYFHNos
fkd/6F5Lj/orSPo+Wa7uYAbuU3O1XQBw+eIapSvn0B2f2RiHAP9ZWEsym6HJ/U/Qka89R1PaI8lvT62TuJhLQTQ5RTe+foz+9xWv
o6/8z15aszITH0/a4T4lQ9sFQEmpZunOORQafk2yJZ3VdOjHP6VJ35DrUPz25LoylkwmQ2N7n6CxQycRZTLxccDLWwC4T82RjjGA
ICSRzdLIrx+nFx/7DTkdWbINKohSCsoXQjr5qcfIdRSh8n+5mTEA3KeGa+sAmBldVoqifJ4ObX+w+L0GXmYeC5gSDr0hc5w2ioW3
GUsz3KfmaesAYNYY0p25uPAff3QfqY5cw2r/EywFVtClzsIbjaYd7lNztHcAWCKpFRVeOEpHh3aT7u4kG0UNv9LYM6AC3Kemae8A
iCLSXZ1x4S8cOhKHQbNe54c9A8rAfWqatg0AblJyc5+b/Ye3P0i6syP+XrPU+9HWVoX71FxtGwDFkT5LL9zzIEWTeRJKNq32L2nE
4paWg/vUVG0ZAFyr8FTf6L4n4i/VmSMbNa/2n60ey1tbFe5T87VfAPCAkpA0OWXoj9t/FL/eI0mP3mDPgGm4T4nQdgHALcpAaTp9
8v9IPf00WddrwCN/S5PmPQNwn5KhrQKgNNDGb/b9iPs4KUeRseVe8NUcad8zAPcpOdpqLQAXLH5d92b1DHVRQBPSJZ2oDsAJvE7x
RePRW9XztCM6JX4pKR9rkror9YL7lBxtEwDFh20U/RmN09/og+TaiMZHxyio+4qfxeNj5aUInqfptRlDf60O0jej0+PQSl57pbZw
n5KlbQKA8TN+a2SB7glOIes4dMl7TyHPkcTT/0lahm+MpUxG0669R2hw72ESGY+6KaDwpbsXtC3cp+RomwDgprNHhh63K+kX4Wpa
6Tq09b1voxUdbnE/gEauAKogiCx1rvLomW/tp9t27adXeB555Dd0kVKz4D4lS9sEAONfLpcMrRIhdZOlcHScgtBJXABwIFlRIKcw
SaukT10kyE/W70Vd4T4lR1sFQCkE+FXf/MVP/8Vf3LNOUAsgPh6lyAoZH6eJ6/40DP+dwGeL+9R8bTUNCACLgwAASDEEAECKIQAA
UgwBAJBiCACAFEMAAKQYAgAgxRAAACmGAABIMQQAQIq13VqAViKFIK2KX7Px8mXeyWghc/9+OUn9rOLppWv9QxIhAJqF3xxeCOnQ
sUK8WUEYFjct4JeWZjOKsp6a9+3FXHCOHvfJVtroJOGflcsqcjQaoM2GAGgCKYj8qYg2nrmWrv/QGZTL8N6FFG8U4mU07d57hB7e
e2Tm+yXcKvAcRVf2vabiRidJ/6xH9h2hnzx2OH4tODQPAqAJ+JXhfiGiN5+1ls55/SuK+4PxemVuBazOkPrv/fTgL1+gzpwmM/0+
cf7X1lBc8LdyAHS4FL9rfKFlzgn/LP2t/XT/7j/G1wKaBwHQJFyguQtg8uHMEfBGISuEiL+/0P4FpS5Ad2DLbnTSyp8FjYMAaCIe
BJTqpQfAA3z8/XJmDxyW+6ut/FnQGBiFAUgxBABAiiEAAFIMAQCQYggAgBRDAACkGKYBE4qn90pfbO6fFyPpnwXNgwBIIH7kNwyL
D/rwVykAZv+5Wkn9LF7LUDpHaB4EQMLwk378vH93p0NdOYeiOQHQleMXi1cnyZ/lOopWxOdY/flA7SEAEoSf3MtP+HTJ+afQ+859
VfH5/znHJ0jEqwUjU/51Z0n/rL97xyn03t5XxU89VnM+UB8IgIQp1doZTy24XJ4LfzWS/FncAiidY7XnA7WHAEgg7rfbE2uEXmYx
LzpN6mcVxwCKp7aY84HaQgAkVC0LRRo+C5YGzwEApBgCACDFEAAAKYYAAEgxBABAiiEAAFIMAQCQYggAgBRDAACkGAIAIMUQAAAp
hgAASDEEAECKIQAAUgwBAJBi2A8gpXi3oLlquW8AtAYEQIpwoeftt3i/QEeLl4VAITAkBZHk/4JUQACkgIk3EC0W+s4Ol6bGAzo2
FpCa7gByMHChX7smQzY0NFWIKIhs/D1EQXtDALQ53la8q8OhIDT0/NE8PXD/72nX3sP0qyeOxZtycuHngMi4ii5445/QxjPX0F+c
voZWdro0mQ/iFgPv3AvtCQHQprhg88ab3d0u/WzPEfrGnb+l/QeP08ioT1pJyniSCr6hUhU/ng/p6999im7f+QytXenRe976p3Tp
xafGwZAvRKTQLWhLCIA2xIWfm/zZrKadDz9HH7/5V+SHhnJZTau63ZlaX8y5++tWenGNP3K8QP/57d/QE8+M0Y0fXU/dWYfyhRBj
A20I04Btplj4iYQi2vqlYbrii8PkODJ+Cw835LlLwE1+VmwlnPjiV4/xn5US9Mp1Wfrxoy/QBVt/TEOPHaKuTnfmLUXQPhAAbYab
/Zmspqu/8hjd/dM/xK8Y40AovWOwGhwC/N6+XEZT3g/jENm17wh1dDqL+hxIPgRAG4kH/Lpc+uHuP9LO3c/TulVeXNvPN+dfDe4O
8BhAGBm65TtPxgOJPIW41M+D5EEAtAkurFxDP7znMF1186PUkdXLKvwl3HLg7sPP9h6hT9z8K/Iyqk2uGDAEQJvgqToe6Pv6nU/F
/1vLmppDYFWXG7cqHho+FA8u4n1+7QEB0Aa4Sc4P+Rw+kqd9B0fj2r/WBbQ4jmBo1/6jJNANaBsIgDbAhd3rcOkHv3yBRkYL5NSh
gMZdjKxDP/zFCzQ+7pOrJcYC2gACoMXF03ZS0MSETw/vOVrTpv9spVbGH49O0S8PjJDjqfjNw9DaEABtgGv8sTGfHn2y+HhvvQqm
loJGJ30afvwYaRctgHaAAGgDXA/zwp2sW3y2v174oxU/Yegpiv8ALQ8B0EbqVfO/pCtA1JCfA42BAABIMQQAQIohAABSDAEAkGII
AIAUQwAApBgCACDFEAAAKYYAAEgxBABAiiEAAFIMAQCQYggAgBRDAACkGAIAIMUQAAAphgAASDEEAECKIQAAUgwBAJBiCACAFEMA
AKQYAgAgxRAAACmGAABIMQQAQIohAABSDAEAkGIIAIAUQwAApBgCACDFEAAAKYYAAEgxBABAiiEAAFIMAQCQYroVz12IhY+a/13p
K23qfe5pva6smmtrbev9xrVkAITRwleabxT/+3J/p13NPu96/TKGoSVTrw9PKD5fPu+yv1eWSEgiWa52SqCWCwCu/LtymkT8Ty9X
CoDi30mP0nVhWom6BIBSgvzAkOeounx+EnHW8fl2dzrUlXMomqfy4eqIf+/42vBXK2VAywTAiYLt0B2f2RgXcE7khS42B0Q2oygy
C/+ddsDnz+eYzWi64zNvJhv/OtYHhwwXCNeRlJ/w46BpZ3x+fJ6XnH8Kve/cV8XXer6ry6HQvcKjrw8+SV8dfJLWrPBapgXaMgFQ
UqrpunNO2QBgXDDSYnYLoK64EBhKTTeg1ALIeGr+0k/FLmdHp9OSLaOWC4DSBS/1xyoNCKZJo8Y9WqmJWws8BmDDhT+Jr7tt0bGR
lgyA2SOyaftlLAfXon4qVTSteu3xHABAiiEAAFKsmgCo5u8AQAJZUb78li3cys3xrNJUAs8LACqx1gpTvvwuNAhoN2y4zBm+65rx
9e/61K3KyXwq8CdDQeRU+pmNUJoBKPccAECjlH4fE/SEpJVCOmGQH5tSzm18HYaHb513HqPSLABPg0426kJWg0db16xwyetwifip
rPZ+FgVaQWiIVnmU83SynpC0NtJjS2sBzBBE3UmY4+Ak4sJfCAx9dfC35DmSjCl+D6CZjLHkZTTt3nuEsp6K/9x8ceXYMUHlK/kF
WwDDw8cMn0RkxA9lWLhKkNDFB0GbV+fyQgt+1vqWwd9y96b51xiACUE2fhxbxV8JKP9GSEeZsPCgkx3JE/VLooG4PM9VpgswGP8f
9h8+5UfrT/qdL6T2bAJKXakLAJA03CJNwjiAJTJSO8oa/0dPbf9qIR7PG6bFBkDRqauO5YQQeV6El5QL3qhHXgFalTWGl8JUGuMr
Ow0YzwQc/MG1o9aK25Wb5WQp80Q0ACSAlSScKJi0eWNv5eNZaAaAlX0O4NRT43EAa6W41wR+XsRbHtRxvSkALJcRKp6tf2DF4T9/
sdj/X7jMlg2AwcHiOECU0w+ZqCCEILXcowOAuoqkdngKYPfw8OVBT8+Bst2Aio/59vX1qVHqVkTyEalcngeYdzABAJLAahsGwhj5
Cz6aAwcoKndUlQIgnmt7dvATeSvVp621PjcDACB5rKVIaU+GYf7+fTs+ey9X3kSDywqAUjdARDm524RTo0JK7gZgEh4gaQTP/2si
qe7jpxMOHlxVqYKv2AJgtre3X51BByIS8hapXN7/pGyqAEDDFZ//9ycP56OO27nclhv9L6mYEGxoaCAaHByMfLfzFhNMRpLQCgBI
Ep6iV06GV+9++6kd1x3mKfxqWupVBQB/EPcnpFMYs5Z2Se1gMBAgQYQlaaJARFbs4MOansKvqNoAiB0YHPCtkNeTjXfdxjgAQAIU
a39PmrAwtH/H5+7nyppb7NUcWtUBwB/IH7z33s89FIVTQ9rJ6PJ7pQJAI/Db8Pg/xor+xS7WqzoATrDCSud6a8y4EIpbAWgJADQJ
T/1J5cjIn7pr347PD1Ffn6y29meLntQvriy6NVi/6dp+J9u9zZ8aC4QQidgpCCBljBCSrDVTh6Wz7vl7ePOPAb4EVT+st+gWAE8t
xCOM0ZovhYXxn2g361iLaUGAxhNWKi1tZC55/p6BPPUd4Aq96sLPFh0A3OTnEcY9D1w9YY34VNwVkDJeNNT4CwCQTsWmv5ZRULhr
786b7uKmP1U58DfborsAJbO7Am7Hym2F/GiQlE1DAdqbNVI60phwMm76b6ApGlhc079kKS2AGHcFenv7NXcFgvzoPUo5mlOpvS88
QNNZEorL2URkzd8+f8+2PB1YfNO/ZMktgGkcIObkzf25dSY4LKTK2SjkF6QvOVgAoKyCm+n2/KkXt+2596aBUkt8qddsuQXV8LMB
3AQxRO8XJCLBTwlbfoE0ANSSJQq0m/P8wth2CtZ8abrwL2uXruW2AIp42eHgYHTmhddcpB3v+9YaYU3Eu6UuN2AAoDjCHjhujl/2
sX1P7ux30+D7uRvA5XdZg++1KaCDgxGn0b6dX9gehv7FQkiLlgBAbby08D/5bhrcbytt9VWt2gRAcVAwiENgx033IgQAauPlhb9n
usaff5//xapZAJQLAawZAFiSwolmP9f8tS38rKYBMH8ICNIaC4cAqlZ8AY9xMt3eiT5/7Qt/XQJgbghEQXChIfuAdnLaxrMDeKcX
wEK4tSy1Ez/SGxbGBvaM6/dMD/jRQq/3Wo7azAIs4MS65D519kWv/a5UeosxEZkojIQQ2GIcYEaxYpTKFUR2JIzCD+6798bt0+/1
q9uq25p3AWYr7iHwHUXUY3+9/bMXR9ZuESSOKu3GDwugNQDApcBGQmqhdEbYKLx7avLoaVz4i9t6xYN9y5rqK6euLYA54jnL08+7
Yo3nrfyW1O4WY0IyvI8RWY0XfUPaxAVfkIxrfWuPGiH+ac/dA/fwdVjMrj7L0cgAeMlJrd98/RZJ4ltCOWtMWCBjo5CswNuHoN1Z
3lVbWFLS8QRv5WPCqbsLhdEPPf7Drx2dtUdH3Wr92RoaANNKP9P2XPDx1UplPiaE2Krd3Oq4RRAUrBUUCYrHCJpxfAA1Fy+UE/ya
TaWVkyETxY/v7zTG3Lxn+w07G1nrNzsAiqYfH+Z/PG3zv631Iu8yKeRbhXYulFJTFEwVWwXFFFDoIkCL4S26jSWuz0hLxyP+vQ78
ycNaZ26LouChUsFvdK2fjACIWdHbu00NDQ3MLGhYf9H1FyrlvDUM8pc5Xsda/lscBjyDaK0NePPD6UCY26IAaIaZpnr83kzBO/Jw
X1ZqKR2SShO3bG0Y7DTWPKQs3fbYjs8fnj5QsdSNPGolKU1swW8f4heQlEY8Tz/v2jWuKy+zQnQJay4VUq9VbiYOAhMUZs7/RDAk
5VQgPazgJn1clZElqZy4lo9/J6Nw3JiAt8zbbcLgkcfuuYFf1xXjfTROOumAXczmnfWSuFLDo5+HDvWI2a2Cnt7+Tt0Z/JV2Mm/y
C3lHEl1OQnpExgqhupWbxYwiNBwX+sifHLckQt6ey0TBw4LUw5bC0F2x9hvDd3zyyOyD4oI/u5JLgsQFwAlWbNhwue7sPNnODgPG
geCsJD1RINNB4ZtUxtsYBlOGQzgJFxXSQBJZ408p5zYhJwsrul4lHrn9qtG5Zx6v2T/1mFnKfn2NkOAAeAnR19cn+W2n8wUCQFJw
gS/+jm7jDTEaMpW3HK0SAHPNHHcpGJZzEQCWanj4G+Gs2erEF3gAAAAAAAAAAABImf8Hb5aTtf0Tz2wAAAAASUVORK5CYII=
"""


def nodrosinat_ikonu():
    """Izveido ikona.ico, ja tās nav (vecāki atjauninātāji to neatnes)."""
    try:
        if not IKONA.exists():
            IKONA.write_bytes(base64.b64decode("".join(_IKONA_B64.split())))
    except OSError:
        pass
    return IKONA if IKONA.exists() else None


def pythonw():
    """pythonw.exe (bez melnā loga), ja tāds ir blakus pašreizējam Python."""
    exe = Path(sys.executable)
    w = exe.with_name("pythonw.exe")
    return w if w.exists() else exe


def _powershell(skripts):
    return subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
                           "-Command", skripts], capture_output=True, text=True, timeout=30,
                          creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))


def darbvirsmas_saisne(izveidot=True):
    """Izveido (vai atjauno) saīsni uz darbvirsmas. Atgriež saīsnes ceļu vai None (ne Windows / kļūda)."""
    if os.name != "nt":
        return None
    ikona = nodrosinat_ikonu()
    gui = PROGRAMMAS_MAPE / "arhivs_gui.py"
    def q(x):
        return str(x).replace("'", "''")
    skripts = (
        "$d=[Environment]::GetFolderPath('Desktop');"
        "$p=Join-Path $d 'Arhīva kārtotājs.lnk';"
        "$s=(New-Object -ComObject WScript.Shell).CreateShortcut($p);"
        f"$s.TargetPath='{q(pythonw())}';"
        f"$s.Arguments='\"{q(gui)}\"';"
        f"$s.WorkingDirectory='{q(PROGRAMMAS_MAPE)}';"
        + (f"$s.IconLocation='{q(ikona)},0';" if ikona else "")
        + "$s.Description='Piļu, muižu un vietu arhīva kārtotājs';"
        "$s.Save();Write-Output $p")
    if not izveidot:
        return None
    r = _powershell(skripts)
    out = (r.stdout or "").strip().splitlines()
    return out[-1] if r.returncode == 0 and out else None
