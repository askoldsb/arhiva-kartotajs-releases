@echo off
chcp 65001 >nul
cd /d "%~dp0"
rem Palaiž bez melnā loga (pythonw). Ja pythonw nav, palaiž parasti un kļūdas gadījumā rāda tekstu.
where pythonw >nul 2>nul
if %errorlevel%==0 (
    start "" pythonw "%~dp0arhivs_gui.py"
    exit /b 0
)
python "%~dp0arhivs_gui.py"
if errorlevel 1 pause
