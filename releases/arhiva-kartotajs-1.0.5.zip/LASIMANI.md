# Arhīva kārtotājs – lietošana

Vajadzīgs tikai **Python 3.8+** (Windows: python.org, instalējot atzīmēt "Add to PATH").
Papildu bibliotēkas nav vajadzīgas.

> **Pirms sākt:** pirmo reizi izmēģini uz arhīva **kopijas** (vai vismaz uz viena burta mapes kopijas).

## Grafiskais logs (ieteicamais veids)

Visiem failiem (`arhivs.py`, `arhivs_gui.py`, `Palaist.bat`) jābūt vienā mapē.
Palaišana: dubultklikšķis uz **Palaist.bat**.

1. **Arhīva mape** → *Izvēlēties…* → galvenā mape, kurā ir burtu mapes.
2. **Vietvārdu saraksts** → *Lejupielādēt no interneta* (vienreiz) vai izvēlies savu failu.
   Lejupielāde izveido arī `vietvardi_pilns.txt` (visi Latvijas nosaukumi, arī baznīcas, muižas) –
   no tā tiek ņemti **objektu ieteikumi**. Pēc programmas atjaunināšanas lejupielādē sarakstu vēlreiz.
3. **Skenēt arhīvu.** Kreisajā pusē parādās grupas:
   zaļas – gatavas apvienošanai, dzeltenas – jāpārbauda, zilas – tikai pārdēvēt.
4. Uzklikšķini grupai: augšā redzamas mapes, apakšā – failu salīdzinājums un foto priekšskatījums.
   Dubultklikšķis uz mapes vai faila to atver.
5. Ja vajag, maini lēmumu: izvēlies mapi un spied *Padarīt par mērķi* / *Apvienot mērķī* /
   *Atstāt atsevišķi*. Paliekošo nosaukumu vari izlabot laukā augšā (*Lietot nosaukumu*).
   Tavi lēmumi tiek saglabāti automātiski (arhīva mapē `_ZURNALI\lemumi.json`) un
   paliek spēkā arī pēc jaunas skenēšanas.
6. *Izpildīt šo grupu* vai *Izpildīt visas gatavās grupas*. Dzeltenās grupas netiek aiztiktas,
   kamēr tās neizlem.
7. *Atsaukt pēdējo izpildi* – atgriež visu, kā bija pirms pēdējās izpildes.

Foto priekšskatījumam un bilžu salīdzināšanai: komandrindā vienreiz izpildi `pip install pillow`.

### Kā tiek salīdzinātas bildes

Izvēloties grupu, programma fonā salīdzina visus failus mapēs, kas tiks apvienotas.
Kolonnā **Lēmums** redzams, kas ar katru failu notiks:

| krāsa | nozīme |
|---|---|
| zaļa ✔ | **paliek** |
| sarkana ✖ | **tiks izmests** (dublikāts): saturs identisks vai bilde vizuāli vienāda (atšķiras tikai fails: izmērs, datums, kompresija, izšķirtspēja, arī cits nosaukums). Paliek labākā versija, pārējās → `_DUBLIKATI` |
| dzeltena ? | **jāizlemj tev:** līdzīgas, bet ne vienādas (uzraksts, ūdenszīme, apgriezums, krāsas…) – priekšskatījumā atzīmē **Paturēt** pie vienas vai vairākām versijām |
| zila | tava izvēle (saglabājas `_ZURNALI\lemumi.json`; *Atgriezt automātisko lēmumu* to atceļ) |
| oranža ≠ | dažādas bildes/faili ar vienādu nosaukumu – paliek visi (otrs saņem “(2)”) |

Teksts kolonnā pasaka arī, **kurš** fails paliek, piem. `✖ IZMEST – identisks, paliek «IMG_1.jpg»`
vai `✔ PALIEK · nosauks «Remtes muiža.jpg»`. Iezīmētā rinda saglabā savu krāsu (tikai treknraksts).

Priekšskatījumā pie katras versijas ir poga **Tikai šo** (paturēt šo, pārējās izmest) un paskaidrojums,
ar ko tā atšķiras no 1. versijas (gaišāka, cita izšķirtspēja, citas proporcijas – apgriezta…).

Grupas ar neizlemtām līdzīgām bildēm ir dzeltenas (“? bildes jāizlemj”), un
*Izpildīt visas gatavās grupas* tās izlaiž.

### Kā tiek grupētas mapes

Mapes tiek grupētas pēc **vietas** (un objekta), nevis pēc pilna nosaukuma:

- **Nenozīmīgās piebildes** (lauks logā augšā; noklusējumā `x m svm copy kopija rezerve …`)
  un numuri `2`, `(2)` tiek ignorēti: `Remte`, `Remte x`, `Remte SVM - Copy`, `Remte rezerve` → **Remte**.
- **Objekti** (baznīca, muiža, pils, pilskalns …) veido atsevišķu mapi:
  `Remtes baznica SVM x` → **Remtes baznīca** (blakus mapei Remte).
- **Locījumi** tiek atpazīti tikai tad, ja aiz vietas seko objekts: `Remtes baznīca` → vieta Remte.
  Mapes `Rauna` un `Raunis` vienmēr paliek atsevišķas. Ja vieta nav viennozīmīga, grupa ir jāpārbauda.
- **Pusmuižas**: `pm` → *pusmuiža*. Ja `Rabakas pm` saturs pārklājas ar `Rabakas muiža` vai `Rabaka`
  (≥30% kopīgu failu), tā tiek pievienota tai; ja pārklājas maz – jāpārbauda tev; ja nepārklājas –
  atsevišķa mape **Rabakas pusmuiža**.
- **Mapju koks**: kreisajā pusē grupas redzamas kā koks – tā, kā mapes izskatīsies pēc izpildes. Zem grupas
  (bultiņa ▸) – tās apakšmapes: esošās (melnas), jaunās, piem., datumu mapes (zilas, “＋ jauna apakšmape”), un
  ieliktās grupas (zilas, treknas, “↳ ielikta grupa”). Apvienojamās mapes redzamas labajā pusē kā līdz šim.
  Uzklikšķinot apakšmapei, failu tabulā redzami tikai tās faili. Filtrs *Visas mapes (arī kārtībā)* rāda arī
  mapes, kurās nekas nav jādara (pelēkas) – arī uz tām var uzvilkt grupu.
- **Vairāku mapju apvienošana**: kokā ar **Ctrl+klikšķi** atlasi vairākas grupas/mapes (piem., `Rīga Altona` un
  `Rīga Altonas muiža`), labais klikšķis → *Apvienot atlasītās vienā mapē…*, izvēlies paliekošo nosaukumu.
  Tās kļūst par vienu grupu (dublikātus izmet, tukšo mapi likvidē izpildot). Ar filtru *Visas mapes* var
  atlasīt arī kārtībā esošas mapes. Saglabājas arī pēc jaunas skenēšanas.
- **Labais klikšķis** kokā atver izvēlni: *Atvērt mapi*, *Ielikt mapē…*, *Izpildīt šo grupu*; pie apakšmapes –
  *Izņemt kā atsevišķu vietas mapi* (esoša apakšmape, piem., `Riga 1-x\Ruba-Reņģe 15.07.2017`, tiek uzreiz
  pārvietota uz burta mapi; atsaucams ar *↶ Atsaukt pēdējo izpildi*), *Izņemt no grupas* (ielikta grupa),
  *Nelikt šajā grupā* (jauna apakšmape, piem., datuma mape).
- **Vilkšana ar peli**: grupu sarakstā kreisajā pusē grupu var uzvilkt uz citas grupas – tā kļūst par tās
  apakšmapi (`Raiskuma pagasts\Raiskuma Sarkanās klintis`). Abas grupas kļūst par VIENU: visu mapju faili
  tiek salīdzināti kopā, un tās izpilda kopā. Ķeksītis jautājumā – dublikātiem paturēt apakšmapes versiju.
  Izņemt: ievelc ielikto apakšmapi (vai grupu) tukšā vietā zem saraksta, vai iezīmē to un spied
  *⌂ Ielikt mapē…*. Saglabājas arī pēc jaunas skenēšanas.
- **Ielikt mapē…**: grupas paliekošo mapi var ielikt citā mapē (piem., `Raiskuma Sarkanās klintis` →
  `Raiskuma pagasts\Raiskuma Sarkanās klintis`). Šīs mapes faili tiek salīdzināti ar grupas failiem –
  dublikāti tiek izmesti (identiskiem paliek tas, kas jau ir tajā mapē), tās faili netiek pārdēvēti.
  *Nelikt nekur* – atceļ. Iestatījums saglabājas arī pēc jaunas skenēšanas.
- **Vienāds paliekošais nosaukums**: ja ar *Lietot nosaukumu* divām grupām iedod vienādu nosaukumu
  (vai tādu, kāda mape jau ir), programma brīdina un saliek tās vienā grupā; tas saglabājas arī pēc
  jaunas skenēšanas. Pēc izpildes sakārtotā mape no saraksta pazūd – tai vairs nav, ar ko apvienoties.
- **Vienāds saturs**: mapes ar vienu vietu (pirmo vārdu), kurām ≥80% failu sakrīt (lieliem failiem pietiek
  ar vienādu izmēru – arī ja fails pārdēvēts), tiek apvienotas, piem. `Rīga kopsavilkums jkl` un
  `Rīga kopsavilkums nhg`. Ja kopīgu failu ir mazāk par 3 vai objekti atšķiras – jāpārbauda tev.
- **Muiža / muižiņa**: `Rīga Popova muižiņa PMA` un `Rīga Popova muiža` tiek salīdzinātas pēc satura
  (≥30% kopīgu failu → apvieno zem nosaukuma ar “muiža”; mazāk vai nemaz → jāpārbauda tev).
- **Saīsinājumi** (lauks *Saīsinājumi* logā augšā, vari papildināt): `pm`, `pusm` → pusmuiža,
  `mm`, `mac muiža` → mācītājmuiža, `pilsdr` → pilsdrupas, `dzirn` → dzirnavas,
  `pārvaldn` → pārvaldnieka, `RIG` → Rīga. Formāts: `saīsinājums=pilnais; …`.
- **Vārdnīca** (poga *Vārdnīca…* atver `vardnica.txt`): vārdi, kas nav vietvārdi, bet jāraksta
  ar garumzīmēm – `kestera` → *ķestera*, `parvaldnieka maja` → *pārvaldnieka māja*. Viens vārds rindā.
- **Numuri** (`Rauna 000`, `Raiskums 88`) tiek uzskatīti par piebildi; mapes saturs tiek salīdzināts
  (≥30% kopīgu failu → apvieno, citādi jāpārbauda). Gads (`Remte 1995`) ir kā datums → apakšmape.
- **Drukas kļūdas un līdzīgi nosaukumi** (`Remts` / `Remte`, `parvadn` / `pārvaldn`): ja viens no tiem
  ir zināms vietvārds, mapes tiek salīdzinātas pēc satura un piedāvātas apvienošanai (vai pārbaudei).
- **Objektu ieteikumi**: izvēloties grupu, virs mapju saraksta var parādīties josla **Ieteikums** ar
  pilno oficiālo nosaukumu, piem. `RIG Jēzus` → *Rīgas Jēzus Evaņģēliski luteriskā baznīca*
  (pamatojums: cik reižu vārds “baznīca” atrasts mapes failos). *Pieņemt* – lieto šo nosaukumu.
  Ja ieteikumu ir vairāki, izvēlies sarakstā.
- Garumzīmes, kas jau ir nosaukumā, netiek noņemtas pēc vietvārdu saraksta (`Rauņa` paliek `Rauņa`).
- **Vecā rakstība** `ah`, `eh`, `uh` … = garais patskanis: `Rahmuli` → **Rāmuļi**, `Rahvas muiža` → **Rāvas muiža**.
  Arī atsevišķi vārdi tiek laboti pēc vietvārdu saraksta: `Riga` → **Rīga**.
- **Objekts** ir viss no vietas līdz objekta vārdam: `Riga Berģu muiza` → **Rīga Berģu muiža**
  (atsevišķa mape, nevis „Rīga muiža”).
- **Vienādi nosauktas muižas dažādās vietās** netiek jauktas: ja aiz objekta seko cita vieta,
  tā ir nosaukuma daļa – `Bērzu muiža Tukums` un `Bērzu muiža Cēsis` paliek atsevišķas mapes.
- **Mapes ar datumu vai citām piebildēm** kļūst par apakšmapēm ar sakārtotu nosaukumu:
  `Remte x 14.03.2019` → `Remte\Remte 14.03.2019` (datums vienmēr `dd.mm.gggg`);
  `Rauna 10.07.2019 drons` → `Rauna\Rauna 10.07.2019 drons`.
- Kolonna **Nonāks** rāda, kur katra mape nonāks.

### Divi kārtošanas etapi

Logā augšā izvēlies **Kārtošanas etaps**:

1. **Tikai kopijas** – apvieno tikai vienas un tās pašas mapes variantus (atšķiras ar `x`, `SVM`,
   `copy`, garumzīmēm, `ah`=`ā` u.tml.). Neko nepārkārto: `Remte 14.07.2014`, `Remtes baznīca`,
   pusmuižas paliek, kā ir (tikai sakārtots nosaukums). Ieteicams sākt ar šo.
2. **Vieta un objekti** – datumu un piebilžu mapes kļūst par apakšmapēm (`Remte\Remte 14.07.2014`),
   pusmuižas un objekti bez atrašanās vietas (`Bērzu muiža`) tiek pievienoti pēc satura
   (≥30% kopīgu failu → apvieno; mazāk → jāpārbauda; nemaz → paliek atsevišķi).
   Ķeksītis *objektus likt vietas mapē* ievieto objektus vietas mapē: `Remte\Remtes baznīca`.

Ieteicamā secība: 1. etaps → *Izpildīt* → pārslēdz uz 2. etapu → *Skenēt arhīvu* → *Izpildīt*.

### Darba saglabāšana

- **Saglabāt darbu** saglabā skenēšanas rezultātu, tavus lēmumus, izvēlēto grupu un filtru
  (`_ZURNALI\sesija.json.gz`). Tas notiek arī automātiski pēc skenēšanas, pēc izpildes un
  aizverot programmu.
- Atverot programmu, tā piedāvā **turpināt no tās pašas vietas** bez jaunas skenēšanas
  (vai poga *Turpināt saglabāto*).
- Ja pa to laiku esi mainījis mapes ārpus programmas – skenē no jauna (tavi lēmumi saglabāsies).

### Failu kopijas visā arhīvā

Skenējot (abos etapos) programma pārbauda **visas** mapes un saraksta augšā parāda rindu
**★ Failu kopijas, tukšie, pagaidu**. Tajā ir faili ar nosaukumu `… - Copy`, `… - Copy (2)`,
`… - Copy - Copy`, `… -copy, copy`, `… Kopija`, `Copy of …`, `… (2)` kopā ar oriģinālu tajā pašā mapē.
Atverot rindu, saturs tiek salīdzināts tāpat kā mapju grupās:

| lēmums | kas notiek |
|---|---|
| = saturs identisks | paliek viens fails |
| ≈ vienāds saturs (pārsaglabāta bilde, cits izmērs; dokuments ar to pašu tekstu) | paliek labākais (lielākā izšķirtspēja) |
| ? līdzīgi (ūdenszīme, apgriezums; papildināts teksts) | **izlem tu** ar ķeksīšiem *Paturēt*; ja neizlem – paliek visi |
| ≠ dažādi | paliek visi (ar ķeksīšiem vari izmest) |

Atpazītie kopiju nosaukumi: `Copy of …`, `Copy (2) of …`, `Copy_of_…`, `Copy of Copy of …`, `Kopija no …`,
`… - Copy`, `… - Copy (2)`, `… -copy, copy`, `… kopija`, `… (2)`.

Jebkuru lēmumu var mainīt ar ķeksīšiem. Paliekošais fails vienmēr saņem nosaukumu **bez** “Copy of” /
“- Copy”: ja labākā versija ir kopija (piem., lielāka izšķirtspēja), tā paliek ar oriģināla nosaukumu,
bet sliktākā aiziet uz `_DUBLIKATI`. Arī vientuļām kopijām bez oriģināla tiek atjaunots tīrs nosaukums
(`Copy of tilts.jpg` → `tilts.jpg`). Tukšie un `~$` faili tiek izmesti.
Rindu var izpildīt atsevišķi vai kopā ar pārējām grupām.

### Failu nosaukumu sakārtošana

Ķeksītis **sakārtot failu nosaukumus** (rindā *Papildus*): paliekošie faili tiek pārdēvēti –
pasvītras → atstarpes, saīsinājumi atšifrēti, garumzīmes pēc vietvārdiem un vārdnīcas, paplašinājums
ar maziem burtiem: `Ramas_parvaldn_maja.JPG` → `Ramas pārvaldnieka māja.jpg`.
Kolonnā *Lēmums* redzams `· nosauks «…»`. Starp vairākām vienādām versijām paliek tā ar labāko
nosaukumu (bez “Copy”, ar garumzīmēm, bez nejaušiem piedēkļiem).

### Automātiski izmetamie faili

- Word/Excel pagaidu faili `~$…`, `Thumbs.db`, `desktop.ini`;
- tukši (0 baitu) faili;
- dokumenti bez teksta un bez attēliem (pēc noklusējuma; ja gribi paturēt, atzīmē *Paturēt*).

- **tukšās mapes** – mapes bez neviena faila (arī ar tukšām apakšmapēm vai tikai ar `Thumbs.db`).
  Tās redzamas rindā ★ kā `[mape] …` un netiek rādītas grupās. Burtu mapes un arhīva sakne netiek aiztiktas.
  Izdzēstās mapes atsaukšana izveido atpakaļ.

Poga *Izmest pagaidu un tukšos failus* to izdara visā arhīvā uzreiz (arī tukšās mapes).
Ieteicams to darīt pašā sākumā, 1. etapā – tad grupu sarakstā paliek mazāk darba.

### Dokumenti

- Vienāds teksts (arī ja fails pārsaglabāts) = dublikāts.
- Līdzīgs teksts (papildināts/labots) = jāizlemj tev; priekšskatījumā redzams teksts un
  **atšķirības** (zaļš – tikai otrajā, sarkans – tikai pirmajā).
- Bezvārda dokumenti (`New Microsoft Word Document.docx`) iegūst nosaukumu no pirmās teksta
  rindas, piem. `Remtes muiža.docx`; ja teksta nav – `Remte dokuments 01.docx`.
  Nosaukumu var mainīt ar pogu *Mainīt…*.
- Ja nevienu no versijām nevajag, var noņemt visus ķeksīšus.

## Komandrinda (tas pats bez loga)

Atver komandrindu mapē, kur atrodas `arhivs.py`.

**1. Vietvārdu saraksts pārbaudei** (vienreiz, vajag internetu):

    python arhivs.py vietvardi

Izveido `vietvardi.txt` ar Latvijas vietu nosaukumiem no Wikidata. Šo failu drīkst
papildināt ar roku (viens nosaukums rindā) vai pievienot citus sarakstus ar `--saraksts`.

**2. Skenēšana** (neko nemaina):

    python arhivs.py skenet "D:\Arhivs"

Izveido:
- `grupas.csv` – plāns: kuras mapes ir viena un tā pati vieta un ko ar tām darīt;
- `grupas_lidzigie.csv` – mapes ar to pašu vietu, bet citu objektu (piem., *Jaunpils pils* un
  *Jaunpils muiža*) – tikai informācijai, netiek apvienotas.

**3. Plāna pārskatīšana** Excel. Kolonna `darbība`:

| vērtība | nozīme |
|---|---|
| MĒRĶIS | šī mape paliek, pārējās tiek ielietas tajā |
| PĀRDĒVĒT | tas pats, bet mape tiek pārdēvēta uz `mērķa_nosaukums` |
| APVIENOT | mapes saturu ielej mērķī |
| PĀRBAUDĪT | skripts nav drošs (iespējams, dažādas vietas) – **netiek aiztikta** |

Ja PĀRBAUDĪT gadījumā pārliecinies, ka tā ir tā pati vieta – nomaini uz APVIENOT.
Ja gribi citu nosaukumu – labo `mērķa_nosaukums` rindā ar MĒRĶIS/PĀRDĒVĒT.
Saglabā kā **"CSV UTF-8"**.

**4. Plāna apskate un izpilde:**

    python arhivs.py apvienot "D:\Arhivs"              (tikai parāda)
    python arhivs.py apvienot "D:\Arhivs" --izpildit   (izpilda)

**5. Ja kaut kas nepatīk – atsaukšana:**

    python arhivs.py atsaukt zurnals_20261016_170000.csv

**Papildus:** `python arhivs.py dublikati "D:\Arhivs"` – atskaite `dublikati.csv` par
identiska satura failiem visā arhīvā (arī starp dažādām vietām). Neko nemaina.

## Kā skripts lemj

- **Viena vieta?** Nosaukumus salīdzina bez garumzīmēm, dubultburtiem (`aa`→`ā`),
  burtu savienojumiem (`sh`→`š`, `ch`→`č`, `zh`→`ž`, `nj`→`ņ`...) un ar vienādotām
  atstarpēm/pasvītrām. Grupē visa arhīva mērogā (arī `C` un `Č` burtu mapes kopā).
- **Kurš nosaukums paliek?** Ja nosaukums ir vietvārdu sarakstā – tā rakstība.
  Citādi tā, kurai ir latviešu garumzīmes un nav aizvietojumu.
- **Aizsardzība pret līdzīgām vietām:** ja ir divas atšķirīgas rakstības ar garumzīmēm
  (piem., *Kalņi* un *Kālni*), vai sarakstā ir vairākas atbilstošas vietas, vai mapēm nav
  neviena kopīga faila un vieta nav apstiprināta sarakstā → PĀRBAUDĪT.
- **Faili:** salīdzina nosaukumu, izmēru un saturu (SHA-1). Identisks fails →
  `_DUBLIKATI` mapē (arī ja tam cits nosaukums). Tāds pats nosaukums, cits saturs →
  saglabā abus (`apraksts (2).docx`). Apakšmapes (`foto`/`Foto`) tiek apvienotas.
- **Laiks:** atskaitē rādīts *izmaiņu* datums, jo *izveides* datums, kopējot failus Windows,
  tiek nomainīts uz kopēšanas brīdi un nav ticams kritērijs.
- **Nekas netiek dzēsts.** Dublikāti tiek pārvietoti uz `_DUBLIKATI\<datums>`; kad esi
  pārliecināts, šo mapi vari izdzēst pats.

## Piezīmes

- Faili, kas atrodas tieši burtu mapēs (nevis vietas mapē), netiek aiztikti.
- Ja vietu mapes ir uzreiz arhīva saknē (bez burtiem) – pievieno `--bez-burtiem`.
- Ļoti gari ceļi Windows: ieslēdz "long paths" (Win 10/11 reģistrā `LongPathsEnabled=1`).


## Palaišana

Uz darbvirsmas ir saīsne **Arhīva kārtotājs** (programma to izveido pati pirmajā palaišanā). Programma
strādā bez melnā PowerShell/komandrindas loga. Ja tā neatveras, palaid `python arhivs_gui.py` komandrindā
mapē `C:\ArhivaKartotajs` – tad būs redzama kļūda.

## Atjaunināšana

Programma pati pārbauda, vai GitHub ir jauna versija (pēc palaišanas un ar pogu **vX · Atjauninājumi…**
augšā). Ja ir – loga augšā parādās dzeltena josla: **Atjaunināt tagad** / **Kas jauns?** / **Vēlāk**.

Atjauninot programma saglabā darbu, iepriekšējo versiju noliek mapē `_vecas_versijas`, ieliek jaunos
failus un restartējas (izvēlies *Turpināt saglabāto*). Arhīvs, lēmumi un `vardnica.txt` netiek aiztikti.

Ja kaut kas noiet greizi: no `_vecas_versijas\<versija>` iekopē failus atpakaļ programmas mapē.
