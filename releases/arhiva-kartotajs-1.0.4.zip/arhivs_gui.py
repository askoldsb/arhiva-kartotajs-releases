#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Piļu, muižu un vietu arhīva kārtotājs – grafiskais logs.
Palaišana:  python arhivs_gui.py   (vai dubultklikšķis uz Palaist.bat)
Failam arhivs.py jāatrodas tajā pašā mapē.
"""
import gzip
import json
import os
import queue
import subprocess
import sys
import threading
import traceback
from datetime import datetime
from pathlib import Path

import tkinter as tk
import tkinter.font as tkfont
from tkinter import ttk, filedialog, messagebox, simpledialog
from tkinter.scrolledtext import ScrolledText

sys.path.insert(0, str(Path(__file__).resolve().parent))
import arhivs as A  # noqa: E402
import atjauninatajs as ATJ  # noqa: E402

try:
    from PIL import Image, ImageTk, ImageOps   # nav obligāts – tikai foto priekšskatījumam
    IR_PILLOW = True
except Exception:
    IR_PILLOW = False

IESTATIJUMI = Path.home() / ".arhiva_kartotajs.json"
ZURNALU_MAPE = "_ZURNALI"
TIR = "TIRISANA"          # īpašā grupa: failu kopijas, tukšie un pagaidu faili visā arhīvā
ATTELI = {".jpg", ".jpeg", ".png", ".gif", ".bmp", ".tif", ".tiff", ".webp"}

STAVOKLI = {
    "drosa":     ("✔ gatava apvienošanai", "#dff0d8"),
    "parbaudit": ("? jāpārbauda",          "#fcf3cf"),
    "bildes":    ("? faili jāizlemj",      "#fcf3cf"),
    "pardevet":  ("✎ tikai pārdēvēt",      "#dbe9f7"),
    "nekas":     ("– nekas netiks darīts", "#eeeeee"),
    "izpildita": ("✓ izpildīts",           "#ffffff"),
}
DOK_PAPL = {".docx", ".doc", ".odt", ".rtf", ".txt"}
DARBIBU_TEKSTS = {
    "MĒRĶIS": "★ paliek (mērķis)",
    "PĀRDĒVĒT": "★ paliek, tiks pārdēvēta",
    "APVIENOT": "→ apvienot mērķī",
    "PĀRBAUDĪT": "? jāizlemj (netiks aiztikta)",
    "ATSTĀT": "✋ atstāt atsevišķi",
    "VECĀKS": "⌂ šajā mapē ieliks (salīdzina)",
}
VEC = "VECĀKS"


def atvert_explorer(cels):
    cels = str(cels)
    try:
        if sys.platform.startswith("win"):
            os.startfile(cels)
        elif sys.platform == "darwin":
            subprocess.Popen(["open", cels])
        else:
            subprocess.Popen(["xdg-open", cels])
    except Exception as e:
        messagebox.showerror("Neizdevās atvērt", str(e))


class Logs(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"Piļu, muižu un vietu arhīva kārtotājs – versija {ATJ.VERSIJA}")
        try:
            ik = ATJ.nodrosinat_ikonu()
            if ik and os.name == "nt":
                self.iconbitmap(default=str(ik))
        except Exception:
            pass
        # mērogs: 1.0 pie 100% ekrāna palielinājuma, 1.5 pie 150% utt.
        self.k = max(1.0, self.winfo_fpixels("1i") / 96.0)
        ek_pl, ek_au = self.winfo_screenwidth(), self.winfo_screenheight()
        self.geometry(f"{min(int(1400 * self.k), ek_pl - 40)}x{min(int(860 * self.k), ek_au - 80)}")
        self.minsize(int(1000 * self.k) if 1000 * self.k < ek_pl else 800, 500)
        self.report_callback_exception = self.kluda_logs

        self.q = queue.Queue()
        self.aiznemts = False
        self.sakne = None
        self.grupas = {}          # gid -> {"rindas": [...], "izpildita": bool}
        self.mapes = {}           # rel -> A.Mape
        self.izv_grupa = None
        self.failu_celi = {}      # failu tabulas ieraksts -> [(nr, mape, ceļš, izmērs, mtime), ...]
        self.atteli = []          # priekšskatījuma attēli (jāglabā, citādi Tk tos izdzēš)
        self.analizes = {}        # gid -> {"mapes": (...), "faili": {rel: dict}, "kopas": [...], "pec_rel": {rel: kopa}}
        self.analize_iet = set()  # grupas, kuru analīze notiek fonā
        self.kese = None          # attēlu nospiedumu kešatmiņa
        self.pv_vars = []         # ķeksīšu mainīgie
        self.attels = None

        self.var_arhivs = tk.StringVar()
        self.var_saraksts = tk.StringVar()
        self.var_bez_burtiem = tk.BooleanVar(value=False)
        self.var_troksnis = tk.StringVar(value=A.TROKSNIS_NOKLUSETAIS)
        self.var_sais = tk.StringVar(value=A.SAISINAJUMI_NOKLUSETIE)
        self.var_kartot = tk.BooleanVar(value=False)
        self.objekti = None         # Wikidata objektu indekss ieteikumiem
        self.ieteikumi_gid = None
        self.var_etaps = tk.IntVar(value=1)
        self.var_obj_apaksmapes = tk.BooleanVar(value=False)
        self.var_filtrs = tk.StringVar(value="Visas grupas")
        self.var_meklet = tk.StringVar()
        self.var_merkis = tk.StringVar()
        self.var_statuss = tk.StringVar(value="Izvēlies arhīva mapi un spied “Skenēt arhīvu”.")
        self.var_info = tk.StringVar()

        self.ielasit_iestatijumus()
        self.uzbuvet()
        self.after(100, self.apstradat_rindu)
        self.protocol("WM_DELETE_WINDOW", self.aizvert)
        self.after(400, self.piedavat_turpinat)
        self.after(3000, lambda: self.parbaudit_atjauninajumus(kluss=True))
        self.after(1500, self.nodrosinat_saisni)

    # ------------------------------------------------------------------ UI
    def uzbuvet(self):
        stils = ttk.Style(self)
        if "vista" in stils.theme_names():
            stils.theme_use("vista")
        elif "clam" in stils.theme_names():
            stils.theme_use("clam")
        pamata = tkfont.nametofont("TkDefaultFont")
        self.f_trekns = pamata.copy()
        self.f_trekns.configure(weight="bold")
        self.f_liels = pamata.copy()
        self.f_liels.configure(size=round(pamata.cget("size") * 1.25), weight="bold")
        rinda_aug = max(pamata.metrics("linespace"), self.f_trekns.metrics("linespace")) + int(6 * self.k)
        stils.configure("Treeview", rowheight=rinda_aug, font=pamata)
        stils.configure("Faili.Treeview", rowheight=rinda_aug, font=pamata)
        stils.map("Faili.Treeview", background=[], foreground=[("selected", "#000000")])
        stils.configure("Treeview.Heading", font=pamata)
        stils.configure("Liela.TButton", padding=(10, 6))

        # --- atjauninājuma josla (redzama tikai, ja ir jauna versija)
        self.atj_rame = tk.Frame(self, background="#fff3c4", padx=10, pady=6)
        self.var_atj = tk.StringVar()
        tk.Label(self.atj_rame, textvariable=self.var_atj, background="#fff3c4",
                 font=self.f_trekns).pack(side="left")
        ttk.Button(self.atj_rame, text="Atjaunināt tagad", command=self.atjauninat).pack(side="left", padx=(12, 4))
        ttk.Button(self.atj_rame, text="Kas jauns?", command=self.paradit_jaunumus).pack(side="left", padx=4)
        ttk.Button(self.atj_rame, text="Vēlāk", command=self.atj_rame.pack_forget).pack(side="left", padx=4)
        self.atj_info = None

        # --- augša: mapes un skenēšana
        aug = ttk.Frame(self, padding=(10, 8, 10, 4))
        aug.pack(fill="x")
        self.aug_rame = aug
        ttk.Label(aug, text="Arhīva mape:").grid(row=0, column=0, sticky="w")
        ttk.Entry(aug, textvariable=self.var_arhivs).grid(row=0, column=1, sticky="ew", padx=6)
        ttk.Button(aug, text="Izvēlēties…", command=self.izveleties_arhivu).grid(row=0, column=2)
        ttk.Button(aug, text=f"v{ATJ.VERSIJA} · Atjauninājumi…",
                   command=lambda: self.parbaudit_atjauninajumus(kluss=False)).grid(row=0, column=4, padx=(12, 0), sticky="e")
        ttk.Checkbutton(aug, text="vietu mapes ir uzreiz saknē (bez burtu mapēm)",
                        variable=self.var_bez_burtiem).grid(row=0, column=3, padx=(12, 0), sticky="w")

        ttk.Label(aug, text="Vietvārdu saraksts:").grid(row=1, column=0, sticky="w", pady=(4, 0))
        ttk.Entry(aug, textvariable=self.var_saraksts).grid(row=1, column=1, sticky="ew", padx=6, pady=(4, 0))
        ttk.Button(aug, text="Izvēlēties…", command=self.izveleties_sarakstu).grid(row=1, column=2, pady=(4, 0))
        ttk.Button(aug, text="Lejupielādēt no interneta", command=self.lejupieladet).grid(
            row=1, column=3, padx=(12, 0), pady=(4, 0), sticky="w")
        ttk.Label(aug, text="Nenozīmīgās piebildes:").grid(row=2, column=0, sticky="w", pady=(4, 0))
        ttk.Entry(aug, textvariable=self.var_troksnis).grid(row=2, column=1, sticky="ew", padx=6, pady=(4, 0))
        ttk.Label(aug, text="(vārdi mapju nosaukumos, kurus ignorēt; atdalīti ar atstarpi)",
                  foreground="#666666").grid(row=2, column=2, columnspan=2, sticky="w", pady=(4, 0))
        ttk.Label(aug, text="Saīsinājumi:").grid(row=3, column=0, sticky="w", pady=(4, 0))
        ttk.Entry(aug, textvariable=self.var_sais).grid(row=3, column=1, sticky="ew", padx=6, pady=(4, 0))
        sv = ttk.Frame(aug)
        sv.grid(row=3, column=2, columnspan=2, sticky="w", pady=(4, 0))
        ttk.Label(sv, text="(saīsinājums=pilnais; atdalīti ar ;)", foreground="#666666").pack(side="left")
        ttk.Button(sv, text="Vārdnīca…", command=self.atvert_vardnicu).pack(side="left", padx=(8, 0))
        ttk.Label(aug, text="Kārtošanas etaps:").grid(row=4, column=0, sticky="w", pady=(6, 0))
        et = ttk.Frame(aug)
        et.grid(row=4, column=1, columnspan=3, sticky="w", padx=6, pady=(6, 0))
        ttk.Radiobutton(et, text="1. Tikai kopijas (apvieno vienas mapes variantus, neko nepārkārto)",
                        variable=self.var_etaps, value=1, command=self.mainits_etaps).pack(side="left")
        ttk.Radiobutton(et, text="2. Vieta un objekti (datumi → apakšmapes, pusmuižas u.c. pēc satura)",
                        variable=self.var_etaps, value=2, command=self.mainits_etaps).pack(side="left", padx=(16, 0))
        ttk.Label(aug, text="Papildus:").grid(row=5, column=0, sticky="w", pady=(4, 0))
        pap = ttk.Frame(aug)
        pap.grid(row=5, column=1, columnspan=3, sticky="w", padx=6, pady=(4, 0))
        ttk.Checkbutton(pap, text="sakārtot failu nosaukumus (pasvītras, saīsinājumi, garumzīmes, .JPG → .jpg)",
                        variable=self.var_kartot, command=self.mainits_kartot).pack(side="left")
        self.cb_obj = ttk.Checkbutton(pap, text="2. etapā objektus likt vietas mapē (Remte\\Remtes baznīca)",
                                      variable=self.var_obj_apaksmapes)
        self.cb_obj.pack(side="left", padx=(16, 0))
        self.mainits_etaps()
        aug.columnconfigure(1, weight=1)

        rinda = ttk.Frame(self, padding=(10, 2, 10, 6))
        rinda.pack(fill="x")
        self.btn_skenet = ttk.Button(rinda, text="Skenēt arhīvu", style="Liela.TButton", command=self.skenet)
        self.btn_skenet.pack(side="left")
        self.progress = ttk.Progressbar(rinda, mode="indeterminate", length=180)
        self.progress.pack(side="left", padx=10)
        ttk.Label(rinda, textvariable=self.var_statuss).pack(side="left", fill="x", expand=True)

        # --- vidus: grupas | detaļas
        galv = ttk.PanedWindow(self, orient="horizontal")

        kreisa = ttk.Frame(galv)
        galv.add(kreisa, weight=2)
        filt = ttk.Frame(kreisa)
        filt.pack(fill="x", pady=(0, 4))
        cb = ttk.Combobox(filt, textvariable=self.var_filtrs, state="readonly", width=24,
                          values=["Visas grupas", "Jāpārbauda", "Gatavas apvienošanai",
                                  "Tikai pārdēvēt", "Izpildītās", "Visas mapes (arī kārtībā)"])
        cb.pack(side="left")
        cb.bind("<<ComboboxSelected>>", lambda e: self.paradit_grupas())
        ttk.Label(filt, text="  Meklēt:").pack(side="left")
        e = ttk.Entry(filt, textvariable=self.var_meklet, width=18)
        e.pack(side="left", fill="x", expand=True)
        self.var_meklet.trace_add("write", lambda *a: self.paradit_grupas())

        self.tv_grupas = self.tabula(kreisa, [("sk", "Mapes", 45), ("st", "Stāvoklis", 150)],
                                     koks=("Vieta / mapju koks pēc izpildes", 240))
        self.tv_grupas.bind("<<TreeviewSelect>>", self.izveleta_grupa)
        for k, (_, krasa) in STAVOKLI.items():
            self.tv_grupas.tag_configure(k, background=krasa)
        self.tv_grupas.tag_configure("izpildita", foreground="#888888")
        self.tv_grupas.tag_configure("karti", foreground="#6b6b6b")
        self.tv_grupas.tag_configure("apaks", foreground="#333333")
        self.tv_grupas.tag_configure("jauna", foreground="#1d5fa8")
        self.tv_grupas.tag_configure("ielikta", foreground="#1d5fa8", font=self.f_trekns)
        self.tv_grupas.tag_configure("drop", background="#9cc3ef")
        self._mezgli, self._atverti, self._koki = {}, set(), {}
        self.izv_mezgls, self.failu_filtrs = None, None
        self.tv_grupas.bind("<<TreeviewOpen>>", self._koks_atverts, add="+")
        self.tv_grupas.bind("<Button-3>", self.koka_izvelne, add="+")          # labais klikšķis
        self.tv_grupas.bind("<Button-2>", self.koka_izvelne, add="+")          # (Mac)
        self.tv_grupas.bind("<<TreeviewClose>>", self._koks_aizverts, add="+")
        # vilkšana ar peli: grupu uzvelk uz citas grupas → ieliek tās mapē
        self._vilk = None
        self.tv_grupas.bind("<ButtonPress-1>", self._vilk_sakt, add="+")
        self.tv_grupas.bind("<B1-Motion>", self._vilk_kust, add="+")
        self.tv_grupas.bind("<ButtonRelease-1>", self._vilk_beigt, add="+")

        laba = ttk.PanedWindow(galv, orient="vertical")
        galv.add(laba, weight=4)

        # mapes grupā
        aug2 = ttk.Frame(laba)
        laba.add(aug2, weight=1)
        mr = ttk.Frame(aug2)
        mr.pack(fill="x", pady=(0, 4))
        ttk.Label(mr, text="Paliekošais nosaukums:").pack(side="left")
        self.ent_merkis = ttk.Entry(mr, textvariable=self.var_merkis, font=self.f_liels)
        self.ent_merkis.pack(side="left", fill="x", expand=True, padx=6)
        self.ent_merkis.bind("<Return>", lambda e: self.mainit_nosaukumu())
        ttk.Button(mr, text="Lietot nosaukumu", command=self.mainit_nosaukumu).pack(side="left")
        ttk.Label(aug2, textvariable=self.var_info, foreground="#555555", wraplength=int(900 * self.k)).pack(fill="x")
        self.iet_rame = ttk.Frame(aug2)
        ttk.Label(self.iet_rame, text="Ieteikums:", foreground="#1d4ed8").pack(side="left")
        self.var_iet = tk.StringVar()
        self.cb_iet = ttk.Combobox(self.iet_rame, textvariable=self.var_iet, state="readonly")
        self.cb_iet.pack(side="left", fill="x", expand=True, padx=6)
        ttk.Button(self.iet_rame, text="Pieņemt", command=self.pienemt_ieteikumu).pack(side="left")
        self.lbl_iet = ttk.Label(self.iet_rame, foreground="#555555")
        self.lbl_iet.pack(side="left", padx=6)

        self.tv_mapes = self.tabula(aug2, [
            ("darb", "Darbība", 190), ("mape", "Mape", 240), ("kur", "Nonāks", 200), ("sk", "Faili", 60),
            ("mb", "MB", 60), ("kop", "Kopīgi ar mērķi", 105),
            ("vec", "Vecākais fails", 100), ("jaun", "Jaunākais fails", 100)])
        self.tv_mapes.configure(height=4)   # parasti grupā ir 2–4 mapes; vairāk vietas failiem un bildēm
        self.tv_mapes.bind("<Double-1>", lambda e: self.atvert_mapi())
        self.tv_mapes.tag_configure("merkis", font=self.f_trekns)

        pog = ttk.Frame(aug2)
        pog.pack(side="bottom", fill="x", pady=4, before=self.tv_mapes.master)
        ttk.Button(pog, text="★ Padarīt par mērķi", command=lambda: self.uzstadit("MĒRĶIS")).pack(side="left")
        ttk.Button(pog, text="→ Apvienot mērķī", command=lambda: self.uzstadit("APVIENOT")).pack(side="left", padx=4)
        ttk.Button(pog, text="✋ Atstāt atsevišķi", command=lambda: self.uzstadit("ATSTĀT")).pack(side="left")
        ttk.Button(pog, text="⌂ Ielikt mapē…", command=self.ielikt_mape).pack(side="left", padx=(16, 0))
        ttk.Button(pog, text="Atvērt mapi", command=self.atvert_mapi).pack(side="left", padx=(4, 0))
        self.btn_izp_grupu = ttk.Button(pog, text="▶ Izpildīt šo grupu", style="Liela.TButton",
                                        command=self.izpildit_grupu)
        self.btn_izp_grupu.pack(side="right")

        # failu salīdzinājums + priekšskatījums
        apak = ttk.Frame(laba)
        laba.add(apak, weight=3)
        leg = ttk.Frame(apak)
        leg.pack(fill="x")
        ttk.Label(leg, text="Failu salīdzinājums:  ").pack(side="left")
        for teksts, krasa in (("✔ paliek", "#e2efe2"),
                              ("✖ tiks izmests", "#f6d5d5"),
                              ("? jāizlemj tev", "#fcf3cf"),
                              ("tava izvēle", "#dbe9f7"),
                              ("≠ dažādi – paliek visi", "#f9d9b8")):
            tk.Label(leg, text=" " + teksts + " ", background=krasa, relief="solid", bd=1).pack(side="left", padx=3)
        fr = ttk.PanedWindow(apak, orient="horizontal")
        fr.pack(fill="both", expand=True, pady=(4, 0))
        ff = ttk.Frame(fr)
        fr.add(ff, weight=3)
        self.tv_faili = self.tabula(ff, [("fails", "Fails", 260)])
        self.tv_faili.tag_configure("dup", background="#f6d5d5")
        self.tv_faili.tag_configure("paliek", background="#e2efe2")
        self.tv_faili.tag_configure("izv", font=self.f_trekns)
        self.tv_faili.tag_configure("jaizlemj", background="#fcf3cf")
        self.tv_faili.tag_configure("lietotajs", background="#dbe9f7")
        self.tv_faili.tag_configure("atskiras", background="#f9d9b8")
        self.tv_faili.configure(style="Faili.Treeview")
        self.tv_faili.bind("<<TreeviewSelect>>", self.izvelets_fails)
        self.tv_faili.bind("<Double-1>", lambda e: self.atvert_failu())

        pf = ttk.Frame(fr, width=int(360 * self.k))
        fr.add(pf, weight=2)
        # ritināms priekšskatījums: visas faila versijas vienu zem otras
        self.pv_canvas = tk.Canvas(pf, highlightthickness=0, background=self.cget("background"))
        pv_sy = ttk.Scrollbar(pf, orient="vertical", command=self.pv_canvas.yview)
        self.pv_canvas.configure(yscrollcommand=pv_sy.set)
        pv_sy.pack(side="right", fill="y")
        self.pv_canvas.pack(side="left", fill="both", expand=True)
        self.pv_iek = ttk.Frame(self.pv_canvas)
        self.pv_logs = self.pv_canvas.create_window((0, 0), window=self.pv_iek, anchor="nw")
        self.pv_iek.bind("<Configure>", lambda e: self.pv_canvas.configure(
            scrollregion=self.pv_canvas.bbox("all")))
        self.pv_canvas.bind("<Configure>", lambda e: self.pv_canvas.itemconfigure(self.pv_logs, width=e.width))
        self.pv_canvas.bind_all("<MouseWheel>", self._ritenis_pv, add="+")
        self.notirit_prieksskatu()

        # --- apakša: plāns, izpilde, žurnāls
        apa = ttk.Frame(self, padding=(10, 6, 10, 4))
        ttk.Button(apa, text="Saglabāt darbu", style="Liela.TButton",
                   command=self.saglabat_sesiju).pack(side="left")
        ttk.Button(apa, text="Turpināt saglabāto", command=self.turpinat_saglabato).pack(side="left", padx=(4, 16))
        ttk.Button(apa, text="Saglabāt plānu (CSV)", command=self.saglabat_planu).pack(side="left")
        ttk.Button(apa, text="Ielādēt plānu (CSV)", command=self.ieladet_planu).pack(side="left", padx=4)
        ttk.Button(apa, text="Izmest pagaidu un tukšos failus",
                   command=self.izmest_pagaidu).pack(side="left", padx=(16, 0))
        self.btn_atsaukt = ttk.Button(apa, text="↶ Atsaukt pēdējo izpildi", command=self.atsaukt)
        self.btn_atsaukt.pack(side="right")
        self.btn_atcelt_visu = ttk.Button(apa, text="⟲ Atcelt visu", command=self.atcelt_visu)
        self.btn_atcelt_visu.pack(side="right", padx=(0, 6))
        self.btn_izp_visas = ttk.Button(apa, text="▶▶ Izpildīt visas gatavās grupas",
                                        command=self.izpildit_visas)
        self.btn_izp_visas.pack(side="right", padx=8)

        self.txt_log = ScrolledText(self, height=4, font=tkfont.nametofont("TkFixedFont"), state="disabled")
        # vispirms apakšējās daļas, lai tās vienmēr būtu redzamas; vidus aizņem atlikušo vietu
        self.txt_log.pack(side="bottom", fill="x", padx=10, pady=(0, 8))
        apa.pack(side="bottom", fill="x")
        galv.pack(fill="both", expand=True, padx=10)
        if not IR_PILLOW:
            self.log("Padoms: lai redzētu JPG foto priekšskatījumu, komandrindā izpildi:  pip install pillow")

    def tabula(self, vecaks, kolonnas, koks=None):
        rame = ttk.Frame(vecaks)
        rame.pack(fill="both", expand=True)
        tv = ttk.Treeview(rame, columns=[k for k, _, _ in kolonnas], show="tree headings" if koks else "headings",
                          selectmode="browse")
        if koks:
            tv.heading("#0", text=koks[0])
            tv.column("#0", width=int(koks[1] * self.k), minwidth=int(120 * self.k), stretch=True, anchor="w")
        for k, nos, plat in kolonnas:
            tv.heading(k, text=nos)
            tv.column(k, width=int(plat * self.k), minwidth=int(40 * self.k), anchor="w",
                      stretch=(k in ("nos", "mape", "fails")))
        sy = ttk.Scrollbar(rame, orient="vertical", command=tv.yview)
        sx = ttk.Scrollbar(rame, orient="horizontal", command=tv.xview)
        tv.configure(yscrollcommand=sy.set, xscrollcommand=sx.set)
        tv.grid(row=0, column=0, sticky="nsew")
        sy.grid(row=0, column=1, sticky="ns")
        sx.grid(row=1, column=0, sticky="ew")
        rame.rowconfigure(0, weight=1)
        rame.columnconfigure(0, weight=1)
        return tv

    # ------------------------------------------------------------ palīgi
    def log(self, teksts):
        """Drīkst saukt no jebkura pavediena."""
        self.q.put(("log", teksts))

    def _log(self, teksts):
        self.txt_log.configure(state="normal")
        self.txt_log.insert("end", f"{datetime.now():%H:%M:%S}  {teksts}\n")
        self.txt_log.see("end")
        self.txt_log.configure(state="disabled")

    def apstradat_rindu(self):
        try:
            while True:
                veids, *dati = self.q.get_nowait()
                if veids == "log":
                    self._log(dati[0])
                elif veids == "statuss":
                    self.var_statuss.set(dati[0])
                elif veids == "atj":
                    self._atj_rezultats(*dati[0])
                elif veids == "gatavs":
                    dati[0]()
        except queue.Empty:
            pass
        self.after(100, self.apstradat_rindu)

    def fona(self, darbs, kad_gatavs, statuss):
        """Palaiž ilgu darbu fonā, lai logs neuzkārtos."""
        if self.aiznemts:
            messagebox.showinfo("Uzgaidi", "Iepriekšējais darbs vēl nav pabeigts.")
            return
        self.aiznemts = True
        self.notirit_prieksskatu()                      # lai priekšskatījums neturētu failus atvērtus
        self.progress.start(12)
        self.var_statuss.set(statuss)
        for b in (self.btn_skenet, self.btn_izp_grupu, self.btn_izp_visas, self.btn_atsaukt):
            b.state(["disabled"])

        def izpilde():
            try:
                rez = darbs()
                kluda = None
            except Exception as e:
                rez, kluda = None, e
                self.log("KĻŪDA: " + "".join(traceback.format_exception_only(type(e), e)).strip())

            def beigas():
                self.aiznemts = False
                self.progress.stop()
                for b in (self.btn_skenet, self.btn_izp_grupu, self.btn_izp_visas, self.btn_atsaukt):
                    b.state(["!disabled"])
                if kluda is None:
                    kad_gatavs(rez)
                else:
                    self.var_statuss.set("Radās kļūda – skat. žurnālu loga apakšā.")
                    messagebox.showerror("Kļūda", str(kluda))
            self.q.put(("gatavs", beigas))
        threading.Thread(target=izpilde, daemon=True).start()

    def kluda_logs(self, exc, val, tb):
        self._log("KĻŪDA: " + "".join(traceback.format_exception(exc, val, tb)))
        messagebox.showerror("Kļūda", f"{val}\n\nSīkāk – žurnālā loga apakšā.")

    def ielasit_iestatijumus(self):
        try:
            d = json.loads(IESTATIJUMI.read_text(encoding="utf-8"))
            self.var_arhivs.set(d.get("arhivs", ""))
            self.var_saraksts.set(d.get("saraksts", ""))
            self.var_bez_burtiem.set(d.get("bez_burtiem", False))
            self.var_troksnis.set(d.get("troksnis", A.TROKSNIS_NOKLUSETAIS))
            self.var_sais.set(d.get("saisinajumi", A.SAISINAJUMI_NOKLUSETIE))
            self.var_kartot.set(d.get("kartot_failus", False))
            self.var_etaps.set(d.get("etaps", 1))
            self.var_obj_apaksmapes.set(d.get("obj_apaksmapes", False))
            self.saisne_izveidota = d.get("saisne", False)
        except Exception:
            pass

    def saglabat_iestatijumus(self):
        try:
            IESTATIJUMI.write_text(json.dumps({
                "arhivs": self.var_arhivs.get(), "saraksts": self.var_saraksts.get(),
                "bez_burtiem": self.var_bez_burtiem.get(), "troksnis": self.var_troksnis.get(),
                "saisinajumi": self.var_sais.get(), "kartot_failus": self.var_kartot.get(),
                "etaps": self.var_etaps.get(), "obj_apaksmapes": self.var_obj_apaksmapes.get(),
                "saisne": getattr(self, "saisne_izveidota", False)},
                ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass

    def zurnalu_mape(self):
        p = self.sakne / ZURNALU_MAPE
        p.mkdir(exist_ok=True)
        return p

    # ------------------------------------------------------- mapes izvēle
    def izveleties_arhivu(self):
        p = filedialog.askdirectory(title="Izvēlies arhīva galveno mapi (kurā ir burtu mapes)",
                                    initialdir=self.var_arhivs.get() or None)
        if p:
            self.var_arhivs.set(os.path.normpath(p))

    def izveleties_sarakstu(self):
        p = filedialog.askopenfilename(title="Vietvārdu saraksts",
                                       filetypes=[("Teksta vai CSV", "*.txt *.csv"), ("Visi faili", "*.*")])
        if p:
            self.var_saraksts.set(os.path.normpath(p))

    def lejupieladet(self):
        merkis = self.var_saraksts.get().strip() or str(Path(__file__).resolve().parent / "vietvardi.txt")
        if not messagebox.askyesno("Lejupielāde",
                                   f"Lejupielādēt Latvijas vietvārdu sarakstu no Wikidata?\n"
                                   f"Tas var aizņemt dažas minūtes.\n\nSaglabās: {merkis}"):
            return

        def kad(skaits):
            if skaits:
                self.var_saraksts.set(merkis)
                self.saglabat_iestatijumus()
                self.var_statuss.set(f"Vietvārdu saraksts lejupielādēts ({skaits} nosaukumi).")
            else:
                self.var_statuss.set("Lejupielāde neizdevās – skat. žurnālu.")
        self.fona(lambda: A.lejupieladet_vietvardus(merkis, self.log), kad, "Lejupielādēju vietvārdus…")

    # ----------------------------------------------------------- skenēšana
    def skenet(self):
        p = self.var_arhivs.get().strip()
        if not p or not Path(p).is_dir():
            messagebox.showwarning("Arhīva mape", "Vispirms izvēlies esošu arhīva mapi.")
            return
        self.sakne = Path(p).resolve()
        self.saglabat_iestatijumus()
        saraksts = self.var_saraksts.get().strip()
        bez_burtiem = self.var_bez_burtiem.get()
        troksnis = self.var_troksnis.get()
        etaps = self.var_etaps.get()
        obj_ap = self.var_obj_apaksmapes.get() and etaps == 2
        skaits = [0]

        def prog(nos):
            skaits[0] += 1
            if skaits[0] % 5 == 1:
                self.q.put(("statuss", f"Skenēju ({skaits[0]}): {nos}"))

        sliktie = A.iestatit_saisinajumus(self.var_sais.get())
        if sliktie:
            self.log("Nesaprotami saīsinājumi (jābūt formā saīsinājums=pilnais): " + "; ".join(sliktie))
        A.iestatit_vardnicu(self.vardnicas_fails())
        kartot = self.var_kartot.get()

        def darbs():
            vv = A.ielasit_vietvardus([saraksts] if saraksts else [], self.log)
            A.iestatit_failu_kartosanu(kartot, vv)
            self.objekti = A.ielasit_objektus(saraksts or str(Path(__file__).resolve().parent / "vietvardi.txt"),
                                              self.log)
            rez = A.skenet(self.sakne, vv, bez_burtiem, prog, troksnis=troksnis, etaps=etaps,
                           objekti_apaksmapes=obj_ap)
            self.q.put(("statuss", "Meklēju failu kopijas, tukšos un pagaidu failus…"))
            rez.tirisana = A.atrast_liekos_failus(self.sakne, list(rez.mapes.values()))
            return rez

        self.fona(darbs, self.skenesana_gatava, "Skenēju arhīvu…")

    def skenesana_gatava(self, rez):
        self.mapes = rez.mapes
        self.analizes = {}
        self.analize_iet = set()
        self.atvert_kesi()
        if not A.IR_PILLOW:
            self.log("Uzmanību: Pillow nav uzinstalēts – bildes salīdzinās tikai pēc satura baitiem.")
        self.grupas = {}
        t = getattr(rez, "tirisana", None)
        if t and (t["lieki"] or t["kopiju_grupas"] or t.get("parsaukt_vienas") or t.get("tuksas_mapes")):
            self.grupas[TIR] = {"rindas": [], "izpildita": False, "gid": TIR, "tirisana": t}
            sk = {}
            for x in t["lieki"]:
                sk[x["veids"]] = sk.get(x["veids"], 0) + 1
            self.log(f"Failu kopiju grupas (“- Copy”, “(2)” …): {len(t['kopiju_grupas'])}, tukši faili: "
                     f"{sk.get('tukss', 0)}, pagaidu faili: {sk.get('pagaidu', 0)}, tukšas mapes: "
                     f"{len(t.get('tuksas_mapes', []))}. Saturs tiks salīdzināts, "
                     f"atverot rindu “★ Failu kopijas”.")
        for r in rez.rindas:
            self.grupas.setdefault(r["grupa"], {"rindas": [], "izpildita": False, "gid": r["grupa"]})["rindas"].append(r)
        self.pielietot_ieliksanas()
        pielietots = self.pielietot_lemumus()
        apv = self.apvienot_vienadus_merkus()
        if apv:
            self.log("Apvienotas grupas ar vienādu paliekošo nosaukumu: " +
                     ", ".join(sorted({self.grupas_nosaukums(self.grupas[v]) for v in apv.values()})))
        s = rez.stat
        self.var_statuss.set(
            f"Vietu mapes: {len(rez.mapes)}  •  kārtībā: {s['kārtībā']}  •  grupas: {len(self.grupas)}  "
            f"(gatavas: {self.skaitit('drosa')}, jāpārbauda: {self.skaitit('parbaudit')}, "
            f"pārdēvēt: {self.skaitit('pardevet')})")
        self.log(f"Skenēšana pabeigta: {len(rez.mapes)} vietu mapes, {len(self.grupas)} grupas.")
        if pielietots:
            self.log(f"Pielietoti tavi iepriekšējie lēmumi {pielietots} grupām.")
        if rez.valigi:
            self.log(f"Faili tieši burtu mapēs (netiek aiztikti): {len(rez.valigi)}")
        if rez.lidzigie:
            self.log(f"Līdzīgi nosaukumi (cits objekts tajā pašā vietā, netiek apvienoti): {len(rez.lidzigie)}")
        self.izv_grupa = None
        self.paradit_grupas()
        self.notirit_detalas()
        self.etaps_rezultatam = self.var_etaps.get()
        self.saglabat_sesiju(kluss=True)

    def atvert_kesi(self):
        try:
            if self.kese is None or getattr(self.kese, "_sakne", None) != self.sakne:
                if self.kese:
                    self.kese.aizvert()
                self.kese = A.AttelaKese(self.zurnalu_mape() / "attelu_kese.sqlite")
                self.kese._sakne = self.sakne
        except Exception as e:
            self.kese = None
            self.log(f"Attēlu kešatmiņu neizdevās atvērt ({e}) – salīdzināšana būs lēnāka.")

    def vardnicas_fails(self):
        return Path(__file__).resolve().parent / "vardnica.txt"

    def atvert_vardnicu(self):
        f = self.vardnicas_fails()
        if not f.exists():
            try:
                f.write_text("# Vārdi ar pareizo rakstību (garumzīmes). Viens vai vairāki rindā.\n"
                             "# Programma tos izmanto, labojot nosaukumus (kestera → ķestera).\n"
                             "# Iebūvētie vārdi jau ir zināmi – šeit pievieno savus.\n\n", encoding="utf-8")
            except Exception as e:
                messagebox.showerror("Vārdnīca", str(e))
                return
        atvert_explorer(f)

    def mainits_kartot(self):
        A.iestatit_failu_kartosanu(self.var_kartot.get())
        self.saglabat_iestatijumus()
        for an in self.analizes.values():
            self.parrekinat_nosaukumus(an)
        if self.izv_grupa in self.grupas:
            sel = self.tv_faili.selection()
            self.paradit_failus(self.grupas[self.izv_grupa], paturet_izveli=sel[0] if sel else None)

    def mainits_etaps(self):
        if hasattr(self, "cb_obj"):
            self.cb_obj.state(["!disabled"] if self.var_etaps.get() == 2 else ["disabled"])

    # ------------------------------------------------ darba saglabāšana
    def sesijas_fails(self, sakne=None):
        sakne = sakne or self.sakne
        return (Path(sakne) / ZURNALU_MAPE / "sesija.json.gz") if sakne else None

    def saglabat_sesiju(self, kluss=False):
        if not self.sakne or not self.grupas:
            if not kluss:
                messagebox.showinfo("Saglabāt darbu", "Nav ko saglabāt – vispirms noskenē arhīvu.")
            return False
        d = {"versija": 1, "arhivs": str(self.sakne), "laiks": datetime.now().isoformat(timespec="seconds"),
             "etaps": getattr(self, "etaps_rezultatam", self.var_etaps.get()),
             "obj_apaksmapes": self.var_obj_apaksmapes.get(), "troksnis": self.var_troksnis.get(),
             "saraksts": self.var_saraksts.get(), "bez_burtiem": self.var_bez_burtiem.get(),
             "statuss": self.var_statuss.get(), "izv_grupa": self.izv_grupa, "filtrs": self.var_filtrs.get(),
             "grupas": {gid: {"rindas": g["rindas"], "izpildita": g["izpildita"], "tirisana": g.get("tirisana"),
                              "vecaks_iestatits": g.get("vecaks_iestatits", False),
                              "vecaks_patur_grupas": g.get("vecaks_patur_grupas", False)}
                        for gid, g in self.grupas.items()},
             "mapes": {rel: A.mape_uz_dict(m) for rel, m in self.mapes.items()}}
        try:
            self.zurnalu_mape()
            f = self.sesijas_fails()
            tmp = f.with_suffix(".tmp")
            with gzip.open(tmp, "wt", encoding="utf-8") as fh:
                json.dump(d, fh, ensure_ascii=False)
            os.replace(tmp, f)
        except Exception as e:
            self.log(f"Neizdevās saglabāt darbu: {e}")
            if not kluss:
                messagebox.showerror("Saglabāt darbu", str(e))
            return False
        if not kluss:
            self.log("Darbs saglabāts. Nākamreiz programma piedāvās turpināt no šīs vietas.")
            messagebox.showinfo("Saglabāt darbu", "Darbs saglabāts.\n\nNākamreiz, atverot programmu, tā piedāvās "
                                                  "turpināt no šīs pašas vietas bez jaunas skenēšanas.")
        return True

    def ieladet_sesiju(self, sakne):
        f = self.sesijas_fails(sakne)
        with gzip.open(f, "rt", encoding="utf-8") as fh:
            d = json.load(fh)
        self.sakne = Path(d["arhivs"]).resolve() if Path(d["arhivs"]).exists() else Path(sakne).resolve()
        self.var_arhivs.set(str(self.sakne))
        self.var_etaps.set(d.get("etaps", 1))
        self.etaps_rezultatam = d.get("etaps", 1)
        self.var_obj_apaksmapes.set(d.get("obj_apaksmapes", False))
        self.var_troksnis.set(d.get("troksnis", A.TROKSNIS_NOKLUSETAIS))
        if d.get("saraksts"):
            self.var_saraksts.set(d["saraksts"])
        self.var_bez_burtiem.set(d.get("bez_burtiem", False))
        self.mainits_etaps()
        A.iestatit_saisinajumus(self.var_sais.get())
        A.iestatit_vardnicu(self.vardnicas_fails())
        vv = A.ielasit_vietvardus([self.var_saraksts.get()] if self.var_saraksts.get() else [], lambda *a: None)
        A.iestatit_failu_kartosanu(self.var_kartot.get(), vv)
        self.objekti = A.ielasit_objektus(self.var_saraksts.get() or
                                          str(Path(__file__).resolve().parent / "vietvardi.txt"), self.log)
        self.mapes = {rel: A.mape_no_dict(md, self.sakne) for rel, md in d["mapes"].items()}
        self.grupas = {gid: {"rindas": g["rindas"], "izpildita": g["izpildita"], "gid": gid,
                             "vecaks_iestatits": g.get("vecaks_iestatits", False),
                             "vecaks_patur_grupas": g.get("vecaks_patur_grupas", False)}
                       for gid, g in d["grupas"].items()}
        for gid, g in d["grupas"].items():
            if g.get("tirisana"):
                self.grupas[gid]["tirisana"] = g["tirisana"]
        if self.apvienot_vienadus_merkus():
            self.log("Grupas ar vienādu paliekošo nosaukumu apvienotas.")
        self.analizes, self.analize_iet = {}, set()
        self.atvert_kesi()
        self.var_filtrs.set(d.get("filtrs", "Visas grupas"))
        self.var_statuss.set(d.get("statuss", ""))
        self.izv_grupa = d.get("izv_grupa") if d.get("izv_grupa") in self.grupas else None
        self.paradit_grupas()
        self.notirit_detalas()
        if self.izv_grupa:
            self.paradit_detalas()
        izp = sum(1 for g in self.grupas.values() if g["izpildita"])
        self.log(f"Ielādēts saglabātais darbs ({d.get('laiks', '')[:16].replace('T', ' ')}): "
                 f"{len(self.grupas)} grupas, no tām izpildītas {izp}. {d.get('etaps', 1)}. etaps.")
        self.log("Ja pa to laiku esi mainījis mapes ārpus programmas, skenē arhīvu no jauna.")

    def piedavat_turpinat(self):
        p = self.var_arhivs.get().strip()
        if not p or not Path(p).is_dir():
            return
        f = self.sesijas_fails(Path(p))
        if not f or not f.exists():
            return
        try:
            laiks = datetime.fromtimestamp(f.stat().st_mtime).strftime("%d.%m.%Y %H:%M")
        except OSError:
            laiks = ""
        if messagebox.askyesno("Turpināt darbu?", f"Ir saglabāts iepriekšējais darbs ar šo arhīvu ({laiks}).\n\n"
                               "Turpināt no tās pašas vietas?\n(Nē – sāksi no jauna ar skenēšanu)"):
            try:
                self.ieladet_sesiju(Path(p))
            except Exception as e:
                messagebox.showerror("Turpināt darbu", f"Neizdevās ielādēt saglabāto darbu:\n{e}\n\n"
                                                       "Noskenē arhīvu no jauna.")

    # ------------------------------------------------ atjaunināšana no GitHub
    def parbaudit_atjauninajumus(self, kluss=True):
        def darbs():
            try:
                info = ATJ.iegut_manifestu()
                self.q.put(("atj", (info, kluss, None)))
            except Exception as e:
                self.q.put(("atj", (None, kluss, e)))
        if not kluss:
            self.var_statuss.set("Pārbaudu, vai ir jauna versija…")
        threading.Thread(target=darbs, daemon=True).start()

    def _atj_rezultats(self, info, kluss, kluda):
        if kluda is not None:
            if not kluss:
                self.var_statuss.set("")
                messagebox.showwarning("Atjauninājumi", "Neizdevās pārbaudīt atjauninājumus (vai ir internets?).\n\n"
                                                         f"{kluda}")
            return
        if ATJ.ir_jaunaka(info["version"]):
            self.atj_info = info
            self.var_atj.set(f"Pieejama jauna versija {info['version']} (tev ir {ATJ.VERSIJA}).")
            if not self.atj_rame.winfo_ismapped():
                self.atj_rame.pack(fill="x", before=self.aug_rame)
            if not kluss:
                self.var_statuss.set("")
                self.paradit_jaunumus(piedavat=True)
        elif not kluss:
            self.var_statuss.set("")
            messagebox.showinfo("Atjauninājumi", f"Tev ir jaunākā versija ({ATJ.VERSIJA}).")

    def paradit_jaunumus(self, piedavat=False):
        info = self.atj_info
        if not info:
            return
        j = ATJ.jaunumi(info)
        teksts = f"Versija {info['version']}" + (f" ({info.get('date')})" if info.get("date") else "") + "\n\n"
        teksts += "\n".join("• " + x for x in j) if j else "(apraksta nav)"
        if piedavat:
            if messagebox.askyesno("Jauna versija", teksts + "\n\nAtjaunināt tagad?"):
                self.atjauninat()
        else:
            messagebox.showinfo("Kas jauns", teksts)

    def atjauninat(self):
        info = self.atj_info
        if not info:
            return
        if self.aiznemts:
            messagebox.showinfo("Uzgaidi", "Vispirms jāpabeidz pašreizējais darbs.")
            return
        if not messagebox.askyesno("Atjaunināt", f"Atjaunināt programmu uz versiju {info['version']}?\n\n"
                                   "Tavs darbs tiks saglabāts, iepriekšējā versija – noglabāta mapē "
                                   f"“{ATJ.VECAS_VERSIJAS}”. Arhīvs un tavi lēmumi netiek aiztikti.\n"
                                   "Pēc tam programma restartēsies."):
            return
        if self.grupas:
            self.saglabat_sesiju(kluss=True)

        def darbs():
            return ATJ.uzstadit(info, progress=lambda t: self.q.put(("statuss", t)))

        def kad(v):
            self.atj_rame.pack_forget()
            self.log(f"Programma atjaunināta uz versiju {v}.")
            messagebox.showinfo("Atjaunināts", f"Programma atjaunināta uz versiju {v}.\n"
                                               "Tagad tā restartēsies – izvēlies “Turpināt saglabāto”.")
            self.restartet()
        self.fona(darbs, kad, "Atjauninu programmu…")

    def nodrosinat_saisni(self, piespiedu=False):
        """Vienreiz izveido saīsni uz darbvirsmas (Windows)."""
        if os.name != "nt" or (getattr(self, "saisne_izveidota", False) and not piespiedu):
            return

        def darbs():
            try:
                p = ATJ.darbvirsmas_saisne()
            except Exception as e:
                p = None
                self.log(f"Neizdevās izveidot saīsni uz darbvirsmas: {e}")
            if p:
                self.log("Uz darbvirsmas izveidota saīsne “Arhīva kārtotājs”.")
                self.saisne_izveidota = True
                self.q.put(("gatavs", self.saglabat_iestatijumus))
        threading.Thread(target=darbs, daemon=True).start()

    def restartet(self):
        try:
            if self.kese:
                self.kese.aizvert()
        except Exception:
            pass
        gui = Path(__file__).resolve()
        try:
            subprocess.Popen([sys.executable, str(gui)], cwd=str(gui.parent))
        except Exception as e:
            messagebox.showwarning("Restarts", f"Neizdevās restartēt automātiski: {e}\n"
                                               "Aizver un palaid programmu no jauna.")
            return
        self.destroy()

    def aizvert(self):
        if self.aiznemts and not messagebox.askyesno("Aizvērt", "Darbs vēl notiek. Tiešām aizvērt?"):
            return
        if self.grupas and not self.aiznemts:
            self.saglabat_sesiju(kluss=True)
        try:
            if self.kese:
                self.kese.aizvert()
        except Exception:
            pass
        self.destroy()

    # --------------------------------------------------- grupu attēlošana
    def stavoklis(self, g):
        if g["izpildita"]:
            return "izpildita"
        if "tirisana" in g:
            if self.neizlemtas(g) > 0:
                return "bildes"
            return "drosa" if (g["tirisana"]["lieki"] or g["tirisana"]["kopiju_grupas"] or
                               g["tirisana"].get("parsaukt_vienas") or g["tirisana"].get("tuksas_mapes")) else "nekas"
        darb = [r["darbība"] for r in g["rindas"]]
        if "PĀRBAUDĪT" in darb:
            return "parbaudit"
        if self.neizlemtas(g) > 0:
            return "bildes"
        if "APVIENOT" in darb:
            return "drosa"
        if "PĀRDĒVĒT" in darb:
            return "pardevet"
        return "nekas"

    def skaitit(self, st):
        return sum(1 for g in self.grupas.values() if self.stavoklis(g) == st)

    def grupas_nosaukums(self, g):
        if "tirisana" in g:
            return "★ Failu kopijas, tukšie, pagaidu"
        return g["rindas"][0]["mērķa_nosaukums"]

    def grupas_skaits(self, g):
        if "tirisana" in g:
            return (len(g["tirisana"]["lieki"]) + len(g["tirisana"]["kopiju_grupas"]) +
                    len(g["tirisana"].get("parsaukt_vienas", [])) + len(g["tirisana"].get("tuksas_mapes", [])))
        return sum(1 for r in g["rindas"] if r["darbība"] != VEC)

    # ------------------------------------------------ grupu / mapju koks
    def _merka_rinda(self, g):
        return next((r for r in g["rindas"] if r["darbība"] in ("MĒRĶIS", "PĀRDĒVĒT")), None)

    def _burts(self, rel):
        return rel.split("/")[0] if "/" in rel and not self.var_bez_burtiem.get() else ""

    def _grupas_vieta_koka(self, gid, g):
        """Kur grupa atrodas kokā: ("G", gid2) – citā grupā, ("F", rel) – esošā mapē, vai None (saknē)."""
        m = self._merka_rinda(g)
        v = (m.get("vecāka_mape") or "") if m else ""
        if not v:
            return None
        b = self._burts(m["mape"])
        vk = A.nfc(v).casefold()
        for gid2, g2 in self.grupas.items():
            if gid2 == gid or "tirisana" in g2 or g2["izpildita"]:
                continue
            m2 = self._merka_rinda(g2)
            if (m2 and not m2.get("vecāka_mape") and A.nfc(m2["mērķa_nosaukums"]).casefold() == vk
                    and self._burts(m2["mape"]) == b):
                return ("G", gid2)
        return ("F", f"{b}/{v}" if b else v)

    def _grupas_koks(self, gid):
        """Grupas mapju koks pēc izpildes: {"b": {atsl: mezgls}}, mezgls = {nos, b, jauna, ielikta, rindas}."""
        if gid in self._koki:
            return self._koki[gid]
        g = self.grupas[gid]
        sakne = {"b": {}}

        def bērns(mz, nos, **k):
            atsl = A.nfc(nos).casefold()
            if atsl not in mz["b"]:
                mz["b"][atsl] = {"nos": nos, "b": {}, "jauna": False, "ielikta": None, "rindas": set()}
            x = mz["b"][atsl]
            for kk, vv in k.items():
                if vv:
                    x[kk] = vv
            return x
        for i, r in enumerate(g["rindas"]):
            if r["darbība"] not in ("MĒRĶIS", "PĀRDĒVĒT", "APVIENOT"):
                continue
            mz = sakne
            for d in [x for x in (r.get("apakšmape") or "").split("/") if x]:
                mz = bērns(mz, d, jauna=True, ielikta=r.get("ielikta"))
                mz["rindas"].add(i)
            m = self.mapes.get(r["mape"])
            if m is None:
                continue
            for rel, _, _ in m.faili:
                x = mz
                for d in rel.split("/")[:-1]:
                    x = bērns(x, d)
                    x["rindas"].add(i)
        self._koki[gid] = sakne
        return sakne

    def _mapes_koks(self, rel):
        """Esošas (kārtībā esošas) mapes apakšmapju koks."""
        k = "F:" + rel
        if k in self._koki:
            return self._koki[k]
        sakne = {"b": {}}
        m = self.mapes.get(rel)
        for frel, _, _ in (m.faili if m else []):
            x = sakne
            for d in frel.split("/")[:-1]:
                atsl = A.nfc(d).casefold()
                x = x["b"].setdefault(atsl, {"nos": d, "b": {}, "jauna": False, "ielikta": None, "rindas": set()})
        self._koki[k] = sakne
        return sakne

    def _ievietot_bernus(self, iid):
        """Ievieto mezgla apakšmapes (slinki – tikai atverot)."""
        info = self._mezgli.get(iid)
        if not info or info.get("aizpildits"):
            return
        info["aizpildits"] = True
        tv = self.tv_grupas
        for c in tv.get_children(iid):
            if c.startswith("~"):
                tv.delete(c)
        if info["veids"] == "G":
            mz, ipas = self._grupas_koks(info["gid"]), ("G", info["gid"])
        elif info["veids"] == "F":
            mz, ipas = self._mapes_koks(info["rel"]), ("F", info["rel"])
        else:
            mz, ipas = info["mz"], info["ipas"]
        for atsl, x in sorted(mz["b"].items(), key=lambda kv: A.atslega(kv[1]["nos"])):
            celš = (info.get("celš", "") + "/" if info.get("celš") else "") + x["nos"]
            ciid = f"S|{ipas[0]}|{ipas[1]}|{celš}"
            if tv.exists(ciid):
                continue
            tags = ("ielikta",) if x["ielikta"] else (("jauna",) if x["jauna"] else ("apaks",))
            st = "↳ ielikta grupa" if x["ielikta"] else ("＋ jauna apakšmape" if x["jauna"] else "")
            tv.insert(iid, "end", iid=ciid, text=x["nos"], values=("", st), tags=tags)
            self._mezgli[ciid] = {"veids": "S", "ipas": ipas, "celš": celš, "mz": x,
                                  "gid": ipas[1] if ipas[0] == "G" else None, "ielikta": x["ielikta"]}
            if x["b"]:
                tv.insert(ciid, "end", iid="~" + ciid, text="…")

    # ------------------------------------------------ konteksta izvēlne (labais klikšķis)
    def _apaksmapes_avoti(self, info):
        """Esošas apakšmapes (S mezgla) īstās atrašanās vietas diskā."""
        g = self.grupas.get(info.get("gid"))
        if not g:
            return []
        dalas = info["celš"].split("/")
        rez = []
        for i in sorted(info["mz"].get("rindas") or []):
            if i >= len(g["rindas"]):
                continue
            r = g["rindas"][i]
            am = [x for x in (r.get("apakšmape") or "").split("/") if x]
            if [A.nfc(x).casefold() for x in dalas[:len(am)]] != [A.nfc(x).casefold() for x in am]:
                continue
            ieks = dalas[len(am):]
            if not ieks:
                continue
            p = self.sakne / r["mape"]
            # lielie/mazie burti un garumzīmes diskā var atšķirties – meklējam pa soļiem
            for d in ieks:
                atr = None
                try:
                    atr = next((c for c in p.iterdir() if c.is_dir() and A.nfc(c.name).casefold() ==
                                A.nfc(d).casefold()), None)
                except OSError:
                    pass
                if atr is None:
                    p = None
                    break
                p = atr
            if p is not None and p not in [x for x, _ in rez]:
                rez.append((p, r["mape"]))
        return rez

    def koka_izvelne(self, e):
        tv = self.tv_grupas
        iid = tv.identify_row(e.y)
        if not iid:
            return
        tv.selection_set(iid)
        tv.focus(iid)
        info = self._mezgls(iid) or {}
        m = tk.Menu(self, tearoff=0)
        g = self.grupas.get(info.get("gid")) if info.get("gid") else None
        aktiva = g is not None and not g["izpildita"] and "tirisana" not in g
        if info.get("veids") == "G" and g is not None:
            mr = self._merka_rinda(g) if "tirisana" not in g else None
            if mr:
                m.add_command(label="Atvērt mapi", command=lambda: atvert_explorer(self.sakne / mr["mape"]))
            if aktiva:
                m.add_command(label="⌂ Ielikt mapē…", command=self.ielikt_mape)
                m.add_separator()
                m.add_command(label="▶ Izpildīt šo grupu", command=self.izpildit_grupu)
        elif info.get("veids") == "S":
            avoti = self._apaksmapes_avoti(info) if g is not None else []
            if avoti:
                m.add_command(label="Atvērt mapi", command=lambda: atvert_explorer(avoti[0][0]))
            if aktiva and info.get("ielikta") and info["celš"].count("/") == 0:
                m.add_command(label="Izņemt no grupas (atkal atsevišķa grupa)",
                              command=lambda: self.izņemt_ielikto(info["gid"], info["ielikta"]))
            elif aktiva and info["mz"].get("jauna") and info["celš"].count("/") == 0:
                m.add_command(label="Nelikt šajā grupā (mapes atstāt atsevišķi)",
                              command=lambda: self.atstat_apaksmapi(info))
            elif aktiva and avoti:
                m.add_command(label="Izņemt kā atsevišķu vietas mapi",
                              command=lambda: self.iznemt_apaksmapi(info, avoti))
        elif info.get("veids") == "F":
            m.add_command(label="Atvērt mapi", command=lambda: atvert_explorer(self.sakne / info["rel"]))
        if m.index("end") is None:
            return
        try:
            m.tk_popup(e.x_root, e.y_root)
        finally:
            m.grab_release()

    def atstat_apaksmapi(self, info):
        gid = info["gid"]
        g = self.grupas[gid]
        for i in info["mz"].get("rindas") or []:
            if i < len(g["rindas"]) and g["rindas"][i]["darbība"] == "APVIENOT":
                g["rindas"][i]["darbība"] = "ATSTĀT"
        self.parrekinat_merki(g)
        self.saglabat_lemumu(gid)
        self.log(f"{gid}: “{info['celš']}” mapes atstātas atsevišķi")
        self.izv_mezgls, self.failu_filtrs = gid, None
        self.paradit_grupas()
        self.paradit_detalas()

    def iznemt_apaksmapi(self, info, avoti):
        """Esošu apakšmapi pārvieto uz burta mapi – tā kļūst par atsevišķu vietas mapi (atsaucams)."""
        nos = info["celš"].split("/")[-1]
        darbi = []
        for p, mape in avoti:
            b = self._burts(mape)
            darbi.append((p, self.sakne / b if b else self.sakne, nos))
        teksts = "\n".join(f"• {p.relative_to(self.sakne)}  →  {(d / n).relative_to(self.sakne)}"
                           for p, d, n in darbi)
        if not messagebox.askyesno(
                "Izņemt apakšmapi", f"Pārvietot apakšmapi “{nos}” uz burta mapi, lai tā būtu atsevišķa vietas "
                f"mape?\n\n{teksts}\n\nTas notiek uzreiz (to var atsaukt ar “↶ Atsaukt pēdējo izpildi”). "
                "Pēc tam arhīvs tiks noskenēts no jauna – tavi lēmumi saglabāsies."):
            return
        if self.grupas:
            self.saglabat_sesiju(kluss=True)
        zc = self.zurnalu_mape() / f"zurnals_{datetime.now():%Y%m%d_%H%M%S}.csv"

        def darbs():
            return A.parvietot_mapes(darbi, zc, self.log)

        def kad(rez):
            self.log(f"Apakšmape “{nos}” izņemta ({len(rez)} pārvietošanas). Skenēju no jauna…")
            self.izv_mezgls, self.failu_filtrs = info["gid"], None
            self.skenet()
        self.fona(darbs, kad, f"Pārvietoju “{nos}”…")

    def _koks_atverts(self, _e=None):
        iid = self.tv_grupas.focus()
        if iid:
            self._atverti.add(iid)
            self._ievietot_bernus(iid)

    def _koks_aizverts(self, _e=None):
        self._atverti.discard(self.tv_grupas.focus())

    def _grupas_teksts(self, g):
        return self.grupas_nosaukums(g)

    def paradit_grupas(self):
        tv = self.tv_grupas
        tv.delete(*tv.get_children())
        self._mezgli, self._koki = {}, {}
        filtrs_nos = self.var_filtrs.get()
        filtrs = {"Jāpārbauda": ("parbaudit", "bildes"), "Gatavas apvienošanai": "drosa",
                  "Tikai pārdēvēt": "pardevet", "Izpildītās": "izpildita"}.get(filtrs_nos)
        visas_mapes = filtrs_nos.startswith("Visas mapes")
        mekl = A.atslega(self.var_meklet.get()) if self.var_meklet.get().strip() else ""

        def der(gid, g):
            st = self.stavoklis(g)
            if filtrs and st not in (filtrs if isinstance(filtrs, tuple) else (filtrs,)):
                return False
            if mekl and not any(mekl in A.atslega(r["mape"]) or mekl in A.atslega(r["mērķa_nosaukums"])
                                for r in g["rindas"]):
                return False
            return True
        vietas = {gid: self._grupas_vieta_koka(gid, g) for gid, g in self.grupas.items()
                  if "tirisana" not in g and not g["izpildita"]}
        grupu_mapes = {r["mape"] for g in self.grupas.values() for r in g["rindas"]}

        def ievietot_f(rel):
            iid = "F|" + rel
            if tv.exists(iid):
                return iid
            esosa = (self.sakne / rel).is_dir() if self.sakne else False
            tv.insert("", "end", iid=iid, text=rel.split("/")[-1],
                      values=("", "kārtībā" if esosa else "＋ jauna mape"), tags=("karti",))
            self._mezgli[iid] = {"veids": "F", "rel": rel}
            if self._mapes_koks(rel)["b"]:
                tv.insert(iid, "end", iid="~" + iid, text="…")
            return iid

        def ievietot_g(gid, redz=frozenset()):
            if tv.exists(gid):
                return gid
            g = self.grupas[gid]
            vecaks = ""
            v = vietas.get(gid)
            if v and v[0] == "G" and v[1] not in redz and v[1] in self.grupas:
                vecaks = ievietot_g(v[1], redz | {gid})
            elif v and v[0] == "F":
                vecaks = ievietot_f(v[1])
            st = self.stavoklis(g)
            tags = (st,) + (("izpildita",) if g["izpildita"] else ())
            tv.insert(vecaks, "end", iid=gid, text=self._grupas_teksts(g),
                      values=(self.grupas_skaits(g), STAVOKLI[st][0]), tags=tags)
            self._mezgli[gid] = {"veids": "G", "gid": gid}
            if "tirisana" not in g and self._grupas_koks(gid)["b"]:
                tv.insert(gid, "end", iid="~" + gid, text="…")
            if vecaks:
                tv.item(vecaks, open=True)
            return gid

        def kārt(gid):
            return (0 if "tirisana" in self.grupas[gid] else 1, A.atslega(self.grupas_nosaukums(self.grupas[gid])))
        for gid in sorted(self.grupas, key=kārt):
            if der(gid, self.grupas[gid]):
                ievietot_g(gid)
        if visas_mapes:
            for rel in sorted(self.mapes, key=lambda x: A.atslega(x.split("/")[-1])):
                if rel not in grupu_mapes and (not mekl or mekl in A.atslega(rel)):
                    ievietot_f(rel)
        # augšējā līmeņa secība – pēc nosaukuma (★ pirmā)
        aug = list(tv.get_children(""))
        aug.sort(key=lambda i: (0 if i == TIR else 1, A.atslega(tv.item(i, "text"))))
        for n, i in enumerate(aug):
            tv.move(i, "", n)
        # atvērtie mezgli
        for iid in sorted(self._atverti, key=len):
            if tv.exists(iid):
                self._ievietot_bernus(iid)
                tv.item(iid, open=True)
        sel = self.izv_mezgls if self.izv_mezgls and tv.exists(self.izv_mezgls) else self.izv_grupa
        if sel and tv.exists(sel):
            tv.selection_set(sel)
            tv.see(sel)

    def atjaunot_grupas_rindu(self, gid):
        if self.tv_grupas.exists(gid):
            g = self.grupas[gid]
            st = self.stavoklis(g)
            self.tv_grupas.item(gid, text=self._grupas_teksts(g),
                                values=(self.grupas_skaits(g), STAVOKLI[st][0]),
                                tags=(st,) + (("izpildita",) if g["izpildita"] else ()))

    def notirit_detalas(self):
        self.var_merkis.set("")
        self.var_info.set("")
        self.tv_mapes.delete(*self.tv_mapes.get_children())
        self.tv_faili.delete(*self.tv_faili.get_children())
        self.notirit_prieksskatu()

    def izveleta_grupa(self, _e=None):
        sel = self.tv_grupas.selection()
        if not sel:
            return
        iid = sel[0]
        info = self._mezgli.get(iid, {"veids": "G", "gid": iid})
        self.izv_mezgls = iid
        if info["veids"] == "G":
            self.failu_filtrs = None
            self.izv_grupa = info["gid"]
            self.paradit_detalas()
        elif info["veids"] == "S" and info.get("gid") in self.grupas:
            gid = info["gid"]
            self.failu_filtrs = info["celš"]
            self.izv_grupa = gid
            self.paradit_detalas()
            # mapju tabulā iezīmējam mapes, no kurām nāk šī apakšmape
            rr = sorted(info["mz"].get("rindas") or [])
            if rr and self.tv_mapes.exists(str(rr[0])):
                self.tv_mapes.selection_set(str(rr[0]))
                self.tv_mapes.see(str(rr[0]))
        else:
            self.failu_filtrs = None
            self.izv_grupa = None
            self.notirit_detalas()
            rel = info.get("rel") or info.get("ipas", ("", ""))[1]
            self.var_info.set(f"{rel} – mape ir kārtībā (programma tajā neko nemaina). Uz to var uzvilkt grupu, "
                              "lai ieliktu to šajā mapē.")

    def paradit_detalas(self, saglabat_mapes_izveli=None):
        gid = self.izv_grupa
        if gid not in self.grupas:
            return
        g = self.grupas[gid]
        self.iet_rame.pack_forget()
        if "tirisana" in g:
            self.paradit_tirisanu(g)
            if not g["izpildita"]:
                self.saki_analizi(gid)
            return
        self.var_merkis.set(self.grupas_nosaukums(g))
        if not g["izpildita"]:
            self.meklet_ieteikumus(gid)
        info = g["rindas"][0].get("vietvārdu_pārbaude", "")
        if g["izpildita"]:
            info = "Šī grupa jau ir izpildīta. Lai redzētu pašreizējo stāvokli, skenē arhīvu no jauna."
        self.var_info.set(info)
        if not g["izpildita"]:
            self.saki_analizi(gid)
        tv = self.tv_mapes
        tv.delete(*tv.get_children())
        for i, r in enumerate(g["rindas"]):
            tags = ("merkis",) if r["darbība"] in ("MĒRĶIS", "PĀRDĒVĒT") else ()
            tv.insert("", "end", iid=str(i), tags=tags, values=(
                DARBIBU_TEKSTS.get(r["darbība"], r["darbība"]), r["mape"],
                ((("apakšmapē: " + r["apakšmape"]) if r.get("apakšmape") else "galvenajā mapē") +
                 (f" (vietas mapē “{r['vecāka_mape']}”)" if r.get("vecāka_mape") else ""))
                if r["darbība"] in ("MĒRĶIS", "PĀRDĒVĒT", "APVIENOT") else "—",
                r["failu_skaits"], r["izmērs_MB"],
                f'{r["kopīgi_ar_mērķi_%"]}%' if str(r["kopīgi_ar_mērķi_%"]) != "" else "",
                r["vecākais_fails"], r["jaunākais_fails"]))
        if saglabat_mapes_izveli is not None and tv.exists(saglabat_mapes_izveli):
            tv.selection_set(saglabat_mapes_izveli)
        self.paradit_failus(g)

    def paradit_failus(self, g, paturet_izveli=None):
        if "tirisana" in g:
            self.paradit_tirisanu(g, paturet_izveli)
            return
        tv = self.tv_faili
        tv.delete(*tv.get_children())
        self.failu_celi = {}
        if paturet_izveli is None:
            self.notirit_prieksskatu()
        # tikai mapes, kas tiks apvienotas (mērķis + APVIENOT); "atstāt"/"jāpārbaudīt" mapes netiek salīdzinātas
        pref = dict(self.dalibnieki(g))
        mapes = [self.mapes.get(r["mape"]) if r["mape"] in pref else None for r in g["rindas"]]
        redzamas = [i for i, m in enumerate(mapes) if m is not None]
        kol = ["fails", "lem"] + [f"m{i}" for i in redzamas]
        tv.configure(columns=kol)
        tv.heading("fails", text="Fails (kur nonāks)")
        tv.column("fails", width=int(260 * self.k), minwidth=int(160 * self.k), stretch=True)
        tv.heading("lem", text="Lēmums")
        tv.column("lem", width=int(270 * self.k), minwidth=int(120 * self.k), stretch=False)
        for i in redzamas:
            r = g["rindas"][i]
            tv.heading(f"m{i}", text=f"{i + 1}. {r['mape'].split('/')[-1]}")
            tv.column(f"m{i}", width=int(160 * self.k), stretch=False, anchor="w")
        if g["izpildita"] or not any(mapes):
            return
        an = self.analizes.get(self.izv_grupa) if self.analize_aktuala(self.izv_grupa) else None
        visi = {}
        for i, m in enumerate(mapes):
            if m is None:
                continue
            am = pref.get(g["rindas"][i]["mape"], "")
            for rel, izm, mt in m.faili:
                dest = f"{am}/{rel}" if am else rel
                k = A.faila_atslega(dest)
                if A.ir_bezvarda_dokuments(rel.rsplit("/", 1)[-1]):
                    k += f"\x00{i}"                   # bezvārda dokumenti – katrs atsevišķi
                ieraksts = visi.setdefault(k, {"nos": dest, "kur": {}})
                ieraksts["kur"].setdefault(i, (izm, mt, rel))
        if self.failu_filtrs:
            ff = self.failu_filtrs
            if any(r["darbība"] == VEC for r in g["rindas"]):
                ff = self.grupas_nosaukums(g) + "/" + ff
            ff = A.nfc(ff).casefold() + "/"
            visi = {k: v for k, v in visi.items() if A.nfc(v["nos"]).casefold().startswith(ff)}
        for n, (k, ier) in enumerate(sorted(visi.items())):
            if n >= 5000:
                tv.insert("", "end", values=["… (rāda pirmos 5000 failus)"])
                break
            kur = ier["kur"]
            reli = [f"{g['rindas'][i]['mape']}/{kur[i][2]}" for i in sorted(kur)]
            lem, tag = self.rindas_lemums(an, reli, len(kur))
            vertibas = [ier["nos"], lem]
            for i in redzamas:
                if i in kur:
                    izm, mt, _ = kur[i]
                    vertibas.append(f"{self.izmers(izm)} · {datetime.fromtimestamp(mt):%Y-%m-%d}")
                else:
                    vertibas.append("—")
            iid = "f" + str(n)
            tv.insert("", "end", iid=iid, values=vertibas, tags=(tag,) if tag else ())
            self.failu_celi[iid] = {"reli": reli, "versijas": [
                (i, g["rindas"][i]["mape"].split("/")[-1], self.sakne / g["rindas"][i]["mape"] / kur[i][2],
                 kur[i][0], kur[i][1]) for i in sorted(kur)]}
        if paturet_izveli and tv.exists(paturet_izveli):
            tv.selection_set(paturet_izveli)
            tv.see(paturet_izveli)

    def rindas_lemums(self, an, reli, versiju_sk):
        """Teksts un krāsa failu tabulas kolonnai 'Lēmums' – skaidri: ✔ PALIEK / ✖ IZMEST."""
        if an is None:
            if self.izv_grupa in self.analize_iet:
                return "… salīdzinu", ""
            return "", ""
        jauns = next((an["parsaukt"][r] for r in reli if r in an["parsaukt"]), None)
        piez = f"  · nosauks «{jauns}»" if jauns else ""
        kopa = next((an["pec_rel"][r] for r in reli if r in an["pec_rel"]), None)
        if kopa is None:
            if versiju_sk > 1:
                return "≠ dažādi – paliek visi" + piez, "atskiras"
            return ("✔ PALIEK" + piez.replace("  ·", " ·")) if piez else "", ""
        arpus = sum(1 for r in reli if r not in an["faili"])
        if arpus:
            piez += f"  · +{arpus} mapē, ko neapvieno"
        if kopa.get("rokas") and not kopa["lietotajs"]:
            if versiju_sk - arpus > 1:
                return "≠ dažādi – paliek visi" + piez, "atskiras"
            return ("✔ PALIEK" + piez.replace("  ·", " ·", 1)) if piez else "", ""
        manas = [r for r in reli if r in kopa["versijas"]]
        paliek_seit = [r for r in manas if r in kopa["paturet"]]
        izmet_seit = [r for r in manas if r not in kopa["paturet"]]
        paliek_citur = [r for r in kopa["paturet"] if r not in manas]
        izmet_citur = [r for r in kopa["versijas"] if r not in manas and r not in kopa["paturet"]]
        veids = {"identiski": "identisks", "vienadi": "vienāds saturs", "atskirigi": "dažādi",
                 "jaizlemj": "līdzīgi", "tukss": "tukšs dokuments"}.get(kopa["veids"], "")

        def nr(rel):
            return str(an["faili"][rel]["nr"] + 1)

        def vards(rel):
            return "«" + rel.rsplit("/", 1)[-1] + "»"
        if kopa["veids"] == "jaizlemj" and not kopa["lietotajs"]:
            return "? LĪDZĪGI – izvēlies, ko paturēt", "jaizlemj"
        tag = "lietotajs" if kopa["lietotajs"] else None
        if not paliek_seit:
            if paliek_citur:
                t = f"✖ IZMEST – {veids}, paliek {vards(paliek_citur[0])}"
            else:
                t = "✖ IZMEST" + (" – tukšs dokuments" if kopa["veids"] == "tukss" else " (visas versijas)")
            return t, tag or "dup"
        if len(manas) > 1 and izmet_seit:
            t = f"✔ PALIEK {', '.join(nr(x) + '.' for x in paliek_seit)} · ✖ izmest " \
                f"{', '.join(nr(x) + '.' for x in izmet_seit)} ({veids})"
        elif kopa["veids"] == "atskirigi" and len(manas) > 1:
            return "≠ dažādi – paliek visi" + piez, tag or "atskiras"
        else:
            t = "✔ PALIEK"
            if izmet_citur:
                t += f" · ✖ izmest {', '.join(vards(x) for x in izmet_citur[:2])}" \
                     f"{' …' if len(izmet_citur) > 2 else ''} ({veids})"
        return t + piez, tag or "paliek"

    def paradit_tirisanu(self, g, paturet_izveli=None):
        """Īpašā grupa: failu kopijas (“- Copy”, “(2)” …), tukšie un pagaidu faili visā arhīvā."""
        t = g["tirisana"]
        an = self.analizes.get(TIR) if self.analize_aktuala(TIR) else None
        self.var_merkis.set("")
        sk = {}
        for x in t["lieki"]:
            sk[x["veids"]] = sk.get(x["veids"], 0) + 1
        info = (f"Visā arhīvā: kopiju grupas – {len(t['kopiju_grupas'])}, kopijas bez oriģināla (tikai "
                f"pārdēvēt) – {len(t.get('parsaukt_vienas', []))}, tukši faili – {sk.get('tukss', 0)}, "
                f"pagaidu faili – {sk.get('pagaidu', 0)}, tukšas mapes – {len(t.get('tuksas_mapes', []))}. ")
        if an:
            kv = {}
            for k in an["kopas"]:
                kv[k["veids"]] = kv.get(k["veids"], 0) + 1
            info += (f"Identiskas: {kv.get('identiski', 0)}, vizuāli vienādas: {kv.get('vienadi', 0)} – paliek "
                     f"viena (labākā). Līdzīgas – jāizlemj tev: {kv.get('jaizlemj', 0)}. Dažādas – paliek visas: "
                     f"{kv.get('atskirigi', 0)}. Izvēlies rindu un ar ķeksīšiem “Paturēt” vari mainīt jebkuru lēmumu.")
        elif g["izpildita"]:
            info += "✓ Jau izpildīts."
        else:
            info += "… salīdzinu saturu, uzgaidi."
        self.var_info.set(info)
        self.tv_mapes.delete(*self.tv_mapes.get_children())
        tv = self.tv_faili
        tv.delete(*tv.get_children())
        self.failu_celi = {}
        if paturet_izveli is None:
            self.notirit_prieksskatu()
        tv.configure(columns=["fails", "lem", "mape"])
        tv.heading("fails", text="Fails")
        tv.column("fails", width=int(260 * self.k), minwidth=int(200 * self.k), stretch=True)
        tv.heading("lem", text="Lēmums")
        tv.column("lem", width=int(300 * self.k), stretch=False)
        tv.heading("mape", text="Mape")
        tv.column("mape", width=int(260 * self.k), stretch=False)
        rindas = []
        for kg in t["kopiju_grupas"]:
            lem, tag = self.rindas_lemums(an, kg["versijas"], len(kg["versijas"]))
            if not lem:
                lem = "… salīdzinu"
            rindas.append((kg["pamats"] + f"  (+{len(kg['versijas']) - 1})", lem, tag, kg["mape"], kg["versijas"]))
        for rel, jauns in t.get("parsaukt_vienas", []):
            mape, _, vards = rel.rpartition("/")
            rindas.append((vards, f"✎ kopija bez oriģināla – nosauks «{jauns}»", "", mape, [rel]))
        apr = {"tukss": "✖ tukšs (0 baitu) → izmest", "pagaidu": "✖ pagaidu/sistēmas fails → izmest"}
        for x in t["lieki"]:
            mape, _, vards = x["rel"].rpartition("/")
            rindas.append((vards, apr.get(x["veids"], x["veids"]), "dup", mape, [x["rel"]]))
        for rel in t.get("tuksas_mapes", []):
            mape, _, vards = rel.rpartition("/")
            rindas.append(("[mape] " + vards, "✖ tukša mape → izdzēst", "dup", mape, []))
        for n, (vards, lem, tag, mape, reli) in enumerate(sorted(rindas, key=lambda x: (x[3].casefold(), x[0]))):
            if n >= 5000:
                tv.insert("", "end", values=["… (rāda pirmos 5000)"])
                break
            iid = "t" + str(n)
            tv.insert("", "end", iid=iid, values=[vards, lem, mape], tags=(tag,) if tag else ())
            vers, nos = [], {}
            for i, rr in enumerate(reli):
                p = self.sakne / rr
                try:
                    st = p.stat()
                except OSError:
                    continue
                vers.append((i, p.name, p, st.st_size, st.st_mtime))
                nos[i] = p.name
            self.failu_celi[iid] = {"reli": reli if len(reli) > 1 else [], "versijas": vers, "nosaukumi": nos}
        if paturet_izveli and tv.exists(paturet_izveli):
            tv.selection_set(paturet_izveli)
            tv.see(paturet_izveli)

    @staticmethod
    def izmers(b):
        if b >= 1048576:
            return f"{b / 1048576:.1f} MB".replace(".", ",")
        if b >= 10240:
            return f"{round(b / 1024)} KB"
        if b >= 1024:
            return f"{b / 1024:.1f} KB".replace(".", ",")
        return f"{b} B"

    # ------------------------------------------------- priekšskatījums
    def notirit_prieksskatu(self, teksts="Izvēlies failu, lai redzētu\nvisu mapju versijas"):
        for w in self.pv_iek.winfo_children():
            w.destroy()
        self.atteli = []
        import gc
        gc.collect()                                    # atlaiž atvērtos failus
        ttk.Label(self.pv_iek, text=teksts, justify="center", anchor="center").pack(fill="x", pady=20)
        self.pv_canvas.yview_moveto(0)

    def _ritenis_pv(self, e):
        # ritina priekšskatījumu tikai tad, ja pele ir virs tā
        w = self.winfo_containing(e.x_root, e.y_root)
        while w is not None:
            if w is self.pv_canvas:
                self.pv_canvas.yview_scroll(int(-e.delta / 120) or (-1 if e.delta > 0 else 1), "units")
                return
            w = w.master

    def satura_atsl(self, p, izm):
        """Satura nospiedums salīdzināšanai (ļoti lieliem failiem – neaprēķina)."""
        if izm > 300 * 1048576:
            return None
        try:
            return A.jaucejs(p)
        except OSError:
            return None

    def izcelt_izveleto(self):
        tv = self.tv_faili
        for i in getattr(self, "_izv_rindas", []):
            if tv.exists(i):
                tv.item(i, tags=tuple(t for t in tv.item(i, "tags") if t != "izv"))
        self._izv_rindas = list(tv.selection())
        for i in self._izv_rindas:
            tv.item(i, tags=tuple(tv.item(i, "tags")) + ("izv",))

    def izvelets_fails(self, _e=None):
        self.izcelt_izveleto()
        sel = self.tv_faili.selection()
        if not sel or sel[0] not in self.failu_celi:
            return
        ier = self.failu_celi[sel[0]]
        an = self.analizes.get(self.izv_grupa) if self.analize_aktuala(self.izv_grupa) else None
        kopa = None
        if an:
            kopa = next((an["pec_rel"][r] for r in ier["reli"] if r in an["pec_rel"]), None)
        for w in self.pv_iek.winfo_children():
            w.destroy()
        self.atteli = []
        self.pv_vars = []

        if kopa is not None:
            versijas = []
            for rel in kopa["versijas"]:
                f = an["faili"][rel]
                versijas.append((f["nr"], rel, f["cels"], f["izm"], f["mt"], f["w"], f["h"]))
            # tā paša nosaukuma faili mapēs, kas netiek apvienotas (jāpārbauda / atstāt atsevišķi)
            kopas_celi = {str(v[2]) for v in versijas}
            arpus = [(nr_, None, p_, izm_, mt_, 0, 0) for nr_, _, p_, izm_, mt_ in ier["versijas"]
                     if str(p_) not in kopas_celi and not any(str(p_) == str(an["faili"][x]["cels"])
                                                               for x in an["faili"] if x in ier["reli"])]
            versijas += arpus
            paskaidr = {
                "identiski": ("= Saturs IDENTISKS (baitu līdz baitam). Paliks viens, pārējie → _DUBLIKATI.",
                              "#2e7d32"),
                "vienadi": ("≈ VIENĀDS SATURS – bildes izskatās vienādi / dokumentiem vienāds teksts; atšķiras "
                            "tikai fails (izmērs, datums, kompresija). Automātiski paliek labākais, pārējie → "
                            "_DUBLIKATI.", "#2e7d32"),
                "jaizlemj": ("? LĪDZĪGI, bet ne vienādi (bildēm – uzraksts, ūdenszīme, apgriezums, krāsas; "
                             "dokumentiem – papildināts/labots teksts). Atzīmē, kurus paturēt – vienu vai vairākus.",
                             "#b45309"),
                "atskirigi": ("≠ Tās ir DAŽĀDAS bildes/faili – paliks visi. Ja tomēr gribi kādu izmest, "
                              "noņem ķeksīti.", "#555555"),
                "tukss": ("✖ TUKŠS dokuments (nav ne teksta, ne attēlu) – tiks izmests. Ja tomēr gribi to "
                          "paturēt, atzīmē “Paturēt”.", "#555555"),
            }[kopa["veids"]]
            teksts, krasa = paskaidr
            if kopa.get("rokas") and arpus and len(kopa["versijas"]) == 1:
                teksts = ("Šim failam nav pāra starp apvienojamajām mapēm – tas paliks. Tāda paša nosaukuma fails "
                          "ir mapē, ko NEAPVIENO (dzeltena “jāpārbauda” vai “atstāt atsevišķi”) – tas netiek "
                          "salīdzināts un netiks aiztikts. Ja šo failu nevajag, noņem ķeksīti “Paturēt”.")
            elif kopa.get("rokas"):
                teksts = ("Programma šīs versijas uzskata par DAŽĀDĀM – paliks visas. Ja redzi, ka tās ir vienādas, "
                          "noņem ķeksīti pie liekās vai spied “Tikai šo” pie tās, ko paturēt."
                          if len(kopa["versijas"]) > 1 else
                          "Fails paliks. Ja to nevajag, noņem ķeksīti “Paturēt” – tas aizies uz _DUBLIKATI.")
            if kopa["lietotajs"]:
                teksts = "✔ Tava izvēle saglabāta. " + teksts
            if not kopa["paturet"] and kopa["veids"] != "tukss":
                teksts, krasa = "✖ NEVIENA versija netiks paturēta – visas aizies uz _DUBLIKATI.", "#b91c1c"
            ttk.Label(self.pv_iek, text=teksts, foreground=krasa, wraplength=int(340 * self.k),
                      font=self.f_trekns).pack(fill="x", padx=4, pady=(2, 6))
            if kopa["lietotajs"]:
                ttk.Button(self.pv_iek, text="Atgriezt automātisko lēmumu",
                           command=lambda k=kopa: self.atiestatit_kopu(k)).pack(anchor="w", padx=4)
        else:
            versijas = [(nr, None, p, izm, mt, 0, 0) for nr, _, p, izm, mt in ier["versijas"]]
            if an is None and self.izv_grupa in self.analize_iet:
                ttk.Label(self.pv_iek, text="… salīdzinu bildes, uzgaidi", foreground="#555555").pack(anchor="w", padx=4)

        # bezvārda dokuments – jaunais nosaukums
        if an:
            for rel in ier["reli"]:
                if rel in an["parsaukt"]:
                    rr = ttk.Frame(self.pv_iek)
                    rr.pack(fill="x", padx=4, pady=(0, 4))
                    ttk.Label(rr, text=f"Nosaukums pēc apvienošanas: «{an['parsaukt'][rel]}»",
                              wraplength=int(260 * self.k)).pack(side="left")
                    ttk.Button(rr, text="Mainīt…", command=lambda r_=rel: self.mainit_dok_nosaukumu(r_)).pack(
                        side="right")
        # dokumentiem – teksta atšķirības starp 1. un 2. versiju
        dok_vers = [v for v in versijas if v[2].suffix.lower() in DOK_PAPL]
        if len(dok_vers) >= 2 and kopa is not None and kopa["veids"] in ("jaizlemj", "atskirigi"):
            import difflib
            teksti = [(v, self.dok_teksts(an, v[1], v[2])) for v in dok_vers]
            pirmais = teksti[0]
            otrais = next((x for x in teksti[1:] if A.teksta_atslega(x[1]) != A.teksta_atslega(pirmais[1])),
                          teksti[1])
            dok_vers = [pirmais[0], otrais[0]]
            t1, t2 = pirmais[1], otrais[1]
            dif = [l for l in difflib.unified_diff(t1.split("\n"), t2.split("\n"), lineterm="", n=0)
                   if not l.startswith(("---", "+++", "@@"))][:40]
            if dif:
                ttk.Label(self.pv_iek, text=f"Atšķirības ({dok_vers[0][0] + 1}. → {dok_vers[1][0] + 1}.):  "
                          "− tikai pirmajā,  + tikai otrajā", font=self.f_trekns).pack(anchor="w", padx=4)
                ttk.Label(self.pv_iek, text="Tikai salīdzinājums – dokumenti netiek apvienoti. Kurus failus "
                          "paturēt, izvēlies ar ķeksīšiem zemāk.", foreground="#555555",
                          wraplength=int(340 * self.k)).pack(anchor="w", padx=4)
                tw = tk.Text(self.pv_iek, height=min(10, len(dif) + 1), wrap="word", font=tkfont.nametofont(
                    "TkDefaultFont"), relief="solid", borderwidth=1)
                tw.tag_configure("pl", background="#dff0d8")
                tw.tag_configure("mi", background="#f8d7da")
                for l in dif:
                    tw.insert("end", l + "\n", "pl" if l.startswith("+") else "mi")
                tw.configure(state="disabled")
                tw.pack(fill="x", padx=4, pady=(0, 6))

        # bildes izmērs: lai visas versijas ietilptu redzamajā laukumā viena zem otras
        self.update_idletasks()
        pl = max(int(150 * self.k), self.pv_canvas.winfo_width() - int(30 * self.k))
        au = self.pv_canvas.winfo_height() - int(70 * self.k)
        uz_vienu = au // max(1, len(versijas)) - int(50 * self.k)
        lielums = (pl, max(int(90 * self.k), uz_vienu))
        g = self.grupas[self.izv_grupa]
        for nr, rel, p, izm, mt, w, h in versijas:
            rame = ttk.Frame(self.pv_iek, padding=4, relief="groove")
            rame.pack(fill="x", padx=4, pady=4)
            augsa = ttk.Frame(rame)
            augsa.pack(fill="x")
            if an and rel is not None and rel in an.get("faili", {}) and an["faili"][rel].get("mape"):
                mape = an["faili"][rel]["mape"].split("/")[-1]
            else:
                mape = ier.get("nosaukumi", {}).get(nr) or (
                    g["rindas"][nr]["mape"].split("/")[-1] if nr < len(g["rindas"]) else "?")
            if kopa is not None and rel is None:
                ttk.Label(augsa, text="netiek apvienota –\nnav salīdzināta", foreground="#8a5a00").pack(side="left")
            elif kopa is not None:
                var = tk.BooleanVar(value=rel in kopa["paturet"])
                self.pv_vars.append(var)
                ttk.Checkbutton(augsa, text="Paturēt", variable=var,
                                command=lambda k=kopa, r=rel, v=var: self.mainit_paturet(k, r, v)).pack(side="left")
                if len(kopa["versijas"]) > 1:
                    ttk.Button(augsa, text="Tikai šo", width=8,
                               command=lambda k=kopa, r=rel: self.paturet_tikai(k, r)).pack(side="right")
            apr = f"{nr + 1}. {mape}"
            if rel is not None and rel.rsplit("/", 1)[-1] not in (ier["versijas"][0][2].name, mape):
                apr += f" / {rel.rsplit('/', 1)[-1]}"
            apr += f"  ·  {izm:,} B".replace(",", " ")
            if w and h:
                apr += f"  ·  {w}×{h}"
            apr += f"  ·  {datetime.fromtimestamp(mt):%Y-%m-%d}"
            ttk.Label(augsa, text=apr, font=self.f_trekns, wraplength=int(300 * self.k)).pack(side="left", padx=6)
            lbl = ttk.Label(rame, anchor="center", cursor="hand2")
            lbl.pack(fill="x", pady=(4, 0))
            lbl.bind("<Button-1>", lambda e, p=p: atvert_explorer(p))
            ext = p.suffix.lower()
            if ext in DOK_PAPL:
                lbl.destroy()
                t = self.dok_teksts(an, rel, p)
                tw = tk.Text(rame, height=6, wrap="word", font=tkfont.nametofont("TkDefaultFont"),
                             relief="flat", background="#fbfbf8")
                tw.insert("end", (t[:3000] + (" …" if len(t) > 3000 else "")) if t else "(teksts nav nolasāms "
                          "vai dokuments ir tukšs)")
                tw.configure(state="disabled")
                tw.pack(fill="x", pady=(4, 0))
                ttk.Button(rame, text="Atvērt dokumentu", command=lambda p=p: atvert_explorer(p)).pack(anchor="e")
                continue
            if ext not in ATTELI:
                lbl.configure(text="(nav attēls – klikšķini, lai atvērtu)")
                continue
            try:
                if IR_PILLOW:
                    with Image.open(p) as im0:            # fails tiek aizvērts uzreiz (Windows to citādi bloķē)
                        try:
                            im0.draft("RGB", lielums)
                        except Exception:
                            pass
                        try:
                            im = ImageOps.exif_transpose(im0)
                        except Exception:
                            im = im0
                        im = im.copy()
                    im.thumbnail(lielums)
                    if kopa is not None and len(versijas) > 1:
                        piezime = self.bildes_atskiriba(nr, im, w, h, versijas)
                        if piezime:
                            ttk.Label(rame, text=piezime, foreground="#8a4b00",
                                      wraplength=int(340 * self.k)).pack(anchor="w")
                    foto = ImageTk.PhotoImage(im)
                elif ext in (".png", ".gif"):
                    foto = tk.PhotoImage(file=str(p))
                    f = max(1, -(-foto.width() // lielums[0]), -(-foto.height() // lielums[1]))
                    foto = foto.subsample(f, f)
                else:
                    lbl.configure(text="JPG priekšskatījumam vajag Pillow")
                    continue
                self.atteli.append(foto)
                lbl.configure(image=foto)
            except Exception as e:
                lbl.configure(text=f"Nevar parādīt: {e}")
        self.pv_canvas.yview_moveto(0)

    def dok_teksts(self, an, rel, p):
        if an and rel in an.get("faili", {}):
            f = an["faili"][rel]
            if f.get("teksts") is None:
                f["teksts"] = A.dokumenta_teksts(f["cels"])
            return f["teksts"]
        return A.dokumenta_teksts(p)

    def mainit_dok_nosaukumu(self, rel):
        an = self.analizes.get(self.izv_grupa)
        if not an:
            return
        pas = an["parsaukt"].get(rel, "")
        jauns = simpledialog.askstring("Dokumenta nosaukums", "Nosaukums pēc apvienošanas:", initialvalue=pas,
                                       parent=self)
        if not jauns:
            return
        jauns = A.nfc(jauns.strip())
        ext = Path(rel).suffix
        if not jauns.lower().endswith(ext.lower()):
            jauns += ext
        if not A.derigs_nosaukums(jauns):
            messagebox.showwarning("Nosaukums", 'Nosaukums nedrīkst saturēt zīmes  < > : " / \\ | ? *')
            return
        d = self.ielasit_lemumus()
        d.setdefault("__nosaukumi__", {})[rel] = jauns
        try:
            self.zurnalu_mape()
            self.lemumu_fails().write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
        except Exception as e:
            self.log(f"Neizdevās saglabāt: {e}")
        self.parrekinat_nosaukumus(an)
        self.atjaunot_pec_lemuma()

    # ------------------------------------------------- objektu ieteikumi
    def meklet_ieteikumus(self, gid):
        g = self.grupas[gid]
        nos = self.grupas_nosaukums(g)
        mape = [self.sakne / r["mape"] for r in g["rindas"] if r.get("darbība") != "ATSTĀT"]
        self.ieteikumi_gid = gid

        def darbs():
            try:
                rez = A.objektu_ieteikumi(nos, self.objekti, mape)
            except Exception as e:
                rez = []
                self.log(f"Ieteikumu meklēšanas kļūda ({nos}): {e}")

            def beigas():
                if self.ieteikumi_gid != gid or self.izv_grupa != gid:
                    return
                rez2 = [(n, p) for n, p in rez if A.nfc(n) != A.nfc(self.grupas_nosaukums(self.grupas[gid]))]
                if not rez2:
                    self.iet_rame.pack_forget()
                    return
                self._iet = rez2
                self.cb_iet.configure(values=[n for n, _ in rez2])
                self.cb_iet.current(0)
                self.lbl_iet.configure(text=(rez2[0][1] or "") +
                                       (f"  (vēl {len(rez2) - 1} varianti)" if len(rez2) > 1 else ""))
                self.iet_rame.pack(fill="x", pady=(2, 2), before=self.tv_mapes.master)
            self.q.put(("gatavs", beigas))
        threading.Thread(target=darbs, daemon=True).start()

    def pienemt_ieteikumu(self):
        v = self.var_iet.get().strip()
        if not v:
            return
        self.var_merkis.set(v)
        self.mainit_nosaukumu()
        self.iet_rame.pack_forget()

    def paturet_tikai(self, kopa, rel):
        kopa["paturet"] = {rel}
        kopa["lietotajs"] = True
        self.saglabat_failu_lemumu(kopa)
        if self.analize_aktuala(self.izv_grupa):
            self.parrekinat_nosaukumus(self.analizes[self.izv_grupa])
        self.atjaunot_pec_lemuma()

    def bildes_atskiriba(self, nr, im, w, h, versijas):
        """Īsa norāde, ar ko šī bilde atšķiras no pirmās versijas (gaišums, izmērs, proporcijas)."""
        try:
            from PIL import ImageStat
            if not hasattr(self, "_pv_pirma") or nr == versijas[0][0]:
                self._pv_pirma = (im.convert("L").resize((64, 64)), w, h)
                return ""
            pirma, w0, h0 = self._pv_pirma
            dalas = []
            g0 = ImageStat.Stat(pirma).mean[0]
            g1 = ImageStat.Stat(im.convert("L").resize((64, 64))).mean[0]
            if g0 > 0 and abs(g1 - g0) / g0 > 0.03:
                dalas.append(f"{'gaišāka' if g1 > g0 else 'tumšāka'} par {round(abs(g1 - g0) / g0 * 100)}%")
            if w and h and w0 and h0:
                if abs(w / h - w0 / h0) > 0.01:
                    dalas.append("citas proporcijas (apgriezta?)")
                if (w, h) != (w0, h0):
                    dalas.append(f"izšķirtspēja {w}×{h} pret {w0}×{h0}")
            return ("Salīdzinot ar 1.: " + ", ".join(dalas)) if dalas else ""
        except Exception:
            return ""

    def mainit_paturet(self, kopa, rel, var):
        if var.get():
            kopa["paturet"].add(rel)
        else:
            kopa["paturet"].discard(rel)            # drīkst nepaturēt nevienu
        kopa["lietotajs"] = True
        self.saglabat_failu_lemumu(kopa)
        if self.analize_aktuala(self.izv_grupa):
            self.parrekinat_nosaukumus(self.analizes[self.izv_grupa])
        self.atjaunot_pec_lemuma()

    def atiestatit_kopu(self, kopa):
        kopa["paturet"] = set(kopa["ieteikts"])
        kopa["lietotajs"] = False
        self.saglabat_failu_lemumu(kopa, dzest=True)
        if self.analize_aktuala(self.izv_grupa):
            self.parrekinat_nosaukumus(self.analizes[self.izv_grupa])
        self.atjaunot_pec_lemuma()

    def atjaunot_pec_lemuma(self):
        sel = self.tv_faili.selection()
        g = self.grupas[self.izv_grupa]
        self.paradit_failus(g, paturet_izveli=sel[0] if sel else None)
        self.atjaunot_grupas_rindu(self.izv_grupa)
        if sel:
            self.izvelets_fails()

    # ------------------------------------------------- attēlu analīze
    def dalibnieki(self, g):
        """Mapes, kas piedalās apvienošanā (mērķis + APVIENOT), un to apakšmapes."""
        if "tirisana" in g:
            return ("TIR", len(g["tirisana"]["kopiju_grupas"]))
        rr = [r for r in g["rindas"] if r["darbība"] in ("MĒRĶIS", "PĀRDĒVĒT")]
        rr += [r for r in g["rindas"] if r["darbība"] == "APVIENOT"]
        vec = [r for r in g["rindas"] if r["darbība"] == VEC]
        if not vec or not rr:
            return tuple((r["mape"], r.get("apakšmape") or "") for r in rr)
        # grupa tiks ielikta citā mapē: tās faili nonāks <vecāks>/<nosaukums>/…, salīdzinām arī ar vecāka failiem
        nos = rr[0]["mērķa_nosaukums"]
        return tuple((r["mape"], f"{nos}/{r['apakšmape']}" if r.get("apakšmape") else nos) for r in rr) + \
            ((vec[0]["mape"], ""),)

    def analize_aktuala(self, gid):
        an = self.analizes.get(gid)
        return (an is not None and gid in self.grupas and an["mapes"] == self.dalibnieki(self.grupas[gid])
                and an.get("patur", False) == self.grupas[gid].get("vecaks_patur_grupas", False))

    def neizlemtas(self, g):
        gid = g.get("gid")
        if gid is None or not self.analize_aktuala(gid):
            return 0
        return sum(1 for k in self.analizes[gid]["kopas"] if k["veids"] == "jaizlemj" and not k["lietotajs"])

    def analizet(self, gid, progress=None):
        """Izpilda analīzi (drīkst saukt fonā). Atgriež analīzes vārdnīcu."""
        g = self.grupas[gid]
        dal = self.dalibnieki(g)
        if "tirisana" in g:
            def prog_k(i, n):
                self.q.put(("statuss", f"Salīdzinu failu kopijas {i}/{n}…"))
            r_ = A.analizet_kopijas(self.sakne, g["tirisana"], self.kese, progress or prog_k)
            lem = self.ielasit_lemumus().get("__faili__", {})
            for k in r_["kopas"]:
                s_ = lem.get(k["id"])
                if s_ is not None and set(s_) <= set(k["versijas"]):
                    k["paturet"], k["lietotajs"] = set(s_), True
            an = {"mapes": dal, "faili": r_["faili"], "kopas": r_["kopas"], "tir": True,
                  "pec_rel": {v: k for k in r_["kopas"] for v in k["versijas"]}}
            self.parrekinat_nosaukumus(an)
            return an
        if not dal:
            return {"mapes": dal, "faili": {}, "kopas": [], "pec_rel": {}, "parsaukt": {}, "f_saraksts": []}
        nos = self.grupas_nosaukums(g)
        faili, kopas, _ = A.analizet_grupu(self.sakne, [m for m, _ in dal], self.kese, progress,
                                           apaksmapes=[a for _, a in dal], vietas_nosaukums=nos)
        # faili, ko programma neuzskata par vienādiem/līdzīgiem – arī tos var izmest ar ķeksīti
        ieklauti = {v for k in kopas for v in k["versijas"]}
        rindas = {}
        for f in faili:
            atsl = A.faila_atslega(f["dest"])
            if A.ir_bezvarda_dokuments(f["iek"].rsplit("/", 1)[-1]):
                atsl += f"\x00{f['nr']}"
            rindas.setdefault(atsl, []).append(f["rel"])
        for vers in rindas.values():
            if any(v in ieklauti for v in vers):
                continue
            kopas.append({"id": "R|" + "|".join(sorted(vers)), "veids": "atskirigi", "versijas": vers,
                          "klasteri": [[v] for v in vers], "ieteikts": set(vers), "paturet": set(vers),
                          "lietotajs": False, "rokas": True})
        # ieliktās grupas (apakšmapes), kuru versijas dublikātiem jāpatur
        iekl = self.ielasit_lemumus().get("__ieliktas__", {})
        patur_mapes = {r["mape"] for r in g["rindas"] if r.get("ielikta") and iekl.get(r["ielikta"], {}).get("patur")}
        if patur_mapes:
            for k in kopas:
                if k["veids"] not in ("identiski", "vienadi"):
                    continue
                sava = [v for v in k["versijas"] if v.rsplit("/", 1)[0] in patur_mapes
                        or any(v.startswith(m + "/") for m in patur_mapes)]
                if sava and len(sava) < len(k["versijas"]):
                    lab = next((v for v in sava if v in k["ieteikts"]), sava[0])
                    k["ieteikts"] = {lab}
                    k["paturet"] = {lab}
        # ja grupu ieliek citā mapē: identiskiem failiem paturam to, kas jau ir tajā mapē
        vec = next((r["mape"] for r in g["rindas"] if r["darbība"] == VEC), None)
        if vec:
            patur_grupas = g.get("vecaks_patur_grupas", False)
            for k in kopas:
                jau = [v for v in k["versijas"] if v.startswith(vec + "/")]
                citi = [v for v in k["versijas"] if not v.startswith(vec + "/")]
                if not jau or not citi:
                    continue
                if patur_grupas and k["veids"] in ("identiski", "vienadi"):
                    # paturam versiju no ieliekamās mapes, no augšējās mapes izmetam
                    lab = next((v for v in citi if v in k["ieteikts"]), citi[0])
                    k["ieteikts"] = {lab}
                    k["paturet"] = {lab}
                elif not patur_grupas and k["veids"] == "identiski":
                    k["ieteikts"] = {jau[0]}
                    k["paturet"] = {jau[0]}
        lem = self.ielasit_lemumus()
        saglabatie = lem.get("__faili__", {})
        for k in kopas:
            s_ = saglabatie.get(k["id"])
            if s_ is not None and set(s_) <= set(k["versijas"]):
                k["paturet"] = set(s_)
                k["lietotajs"] = True
        an = {"mapes": dal, "patur": g.get("vecaks_patur_grupas", False),
              "faili": {f["rel"]: f for f in faili}, "f_saraksts": faili, "kopas": kopas,
              "pec_rel": {v: k for k in kopas for v in k["versijas"]}, "nos": nos}
        self.parrekinat_nosaukumus(an)
        return an

    def parrekinat_nosaukumus(self, an):
        if an.get("tir"):
            an["parsaukt"] = A.kopiju_parsaukt(an["faili"], an["kopas"])
            return
        parr = self.ielasit_lemumus().get("__nosaukumi__", {})
        an["parsaukt"] = A.bezvarda_nosaukumi(an["f_saraksts"], an["kopas"], an.get("nos", ""), parr)
        vec = [m for m, a_ in an.get("mapes", ()) if a_ == ""][-1:] if any(
            r["darbība"] == VEC for g in self.grupas.values() for r in g["rindas"]) else []
        # mapē, kurā grupu ieliek, failus nepārdēvējam
        for v in vec:
            if any(r["darbība"] == VEC and r["mape"] == v for g in self.grupas.values() for r in g["rindas"]):
                an["parsaukt"] = {k: n for k, n in an["parsaukt"].items() if not k.startswith(v + "/")}

    def saki_analizi(self, gid):
        if self.analize_aktuala(gid) or gid in self.analize_iet:
            return
        self.analize_iet.add(gid)

        def darbs():
            try:
                rez = self.analizet(gid)
            except Exception as e:
                rez = None
                self.log(f"Neizdevās salīdzināt failus grupā {gid}: {e}")

            def beigas():
                self.analize_iet.discard(gid)
                if rez is not None:
                    self.analizes[gid] = rez
                if (rez is not None and gid in self.grupas and not self.grupas[gid]["izpildita"]
                        and not self.analize_aktuala(gid) and self.izv_grupa == gid):
                    self.saki_analizi(gid)            # pa to laiku mainīts lēmums – salīdzinām no jauna
                    return
                self.atjaunot_grupas_rindu(gid)
                if self.izv_grupa == gid:
                    sel = self.tv_faili.selection()
                    self.paradit_failus(self.grupas[gid], paturet_izveli=sel[0] if sel else None)
                    if sel:
                        self.izvelets_fails()
            self.q.put(("gatavs", beigas))
        threading.Thread(target=darbs, daemon=True).start()

    def saglabat_failu_lemumu(self, kopa, dzest=False):
        d = self.ielasit_lemumus()
        f = d.setdefault("__faili__", {})
        if dzest:
            f.pop(kopa["id"], None)
        else:
            f[kopa["id"]] = sorted(kopa["paturet"])
        try:
            self.zurnalu_mape()
            self.lemumu_fails().write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
        except Exception as e:
            self.log(f"Neizdevās saglabāt lēmumu: {e}")

    def atvert_failu(self):
        sel = self.tv_faili.selection()
        if sel and sel[0] in self.failu_celi:
            atvert_explorer(self.failu_celi[sel[0]]["versijas"][0][2])

    def atvert_mapi(self):
        if not self.izv_grupa or self.izv_grupa not in self.grupas:
            return
        sel = self.tv_mapes.selection()
        if not sel:
            messagebox.showinfo("Atvērt mapi", "Vispirms izvēlies mapi sarakstā.")
            return
        r = self.grupas[self.izv_grupa]["rindas"][int(sel[0])]
        p = self.sakne / r["mape"]
        atvert_explorer(p if p.exists() else p.parent)

    # ----------------------------------------------------------- lēmumi
    def uzstadit(self, darbiba):
        gid = self.izv_grupa
        if not gid or gid not in self.grupas or "tirisana" in self.grupas[gid]:
            return
        g = self.grupas[gid]
        if g["izpildita"]:
            messagebox.showinfo("Izpildīta", "Šī grupa jau ir izpildīta.")
            return
        sel = self.tv_mapes.selection()
        if not sel:
            messagebox.showinfo("Darbība", "Vispirms izvēlies mapi sarakstā.")
            return
        i = int(sel[0])
        rr = g["rindas"]
        if rr[i]["darbība"] == VEC:
            messagebox.showinfo("Mape", "Šī ir mape, kurā grupu ieliks. Lai to mainītu vai noņemtu, "
                                        "spied “⌂ Ielikt mapē…”.")
            return
        if darbiba == "MĒRĶIS":
            for j, r in enumerate(rr):
                if j != i and r["darbība"] in ("MĒRĶIS", "PĀRDĒVĒT"):
                    r["darbība"] = "APVIENOT"
            rr[i]["darbība"] = "MĒRĶIS"
            # mērķa mapi pārvietojam saraksta augšā
            rr.insert(0, rr.pop(i))
            i = 0
        else:
            if rr[i]["darbība"] in ("MĒRĶIS", "PĀRDĒVĒT"):
                messagebox.showinfo("Mērķis", "Šī ir paliekošā mape. Lai to mainītu, izvēlies citu mapi "
                                              "un spied “Padarīt par mērķi”.")
                return
            rr[i]["darbība"] = darbiba
        self.parrekinat_merki(g)
        self.saglabat_lemumu(gid)
        self.atjaunot_grupas_rindu(gid)
        self.paradit_detalas(saglabat_mapes_izveli=str(i))

    def _iestatit_vecaku(self, g, vecaks, vecaka_rel=""):
        """Iestata (vai noņem, ja vecaks == "") mapi, kurā grupas paliekošā mape tiks ielikta."""
        g["rindas"] = [r for r in g["rindas"] if r["darbība"] != VEC]
        for r in g["rindas"]:
            if r["darbība"] in ("MĒRĶIS", "PĀRDĒVĒT"):
                r["vecāka_mape"] = vecaks
        self.parrekinat_merki(g)
        if vecaks and vecaka_rel and vecaka_rel in self.mapes and (self.sakne / vecaka_rel).is_dir():
            m = self.mapes[vecaka_rel]
            g["rindas"].append(A._rinda(g.get("gid", ""), VEC, g["rindas"][0]["mērķa_nosaukums"], m, "", "",
                                        "mape, kurā grupa tiks ielikta (tās faili tiek salīdzināti)"))

    # ------------------------------------------------ vilkšana ar peli
    def _vilkams(self, gid):
        g = self.grupas.get(gid)
        return g is not None and "tirisana" not in g and not g["izpildita"]

    def _mezgls(self, iid):
        if not iid:
            return None
        return self._mezgli.get(iid, {"veids": "G", "gid": iid} if iid in self.grupas else None)

    def _vilk_avots(self, iid):
        """Ko var vilkt: grupu vai ielikto grupu (apakšmapi ar ↳)."""
        info = self._mezgls(iid)
        if not info:
            return None
        if info["veids"] == "G" and self._vilkams(info["gid"]):
            return info
        if info["veids"] == "S" and info.get("ielikta") and self._vilkams(info.get("gid")) \
                and info["celš"].count("/") == 0:
            return info
        return None

    def _pecteci(self, gid):
        """Grupas, kas kokā atrodas zem gid (lai nevarētu ielikt pašu sevī)."""
        tv, rez, st = self.tv_grupas, set(), [gid]
        while st:
            x = st.pop()
            for c in tv.get_children(x) if tv.exists(x) else ():
                if c in self.grupas:
                    rez.add(c)
                st.append(c)
        return rez

    def _vilk_merkis(self, v, iid):
        """Derīgs nomešanas mērķis: ("G", gid) / ("F", rel) / ("SAKNE", None) / None."""
        if not iid:
            return ("SAKNE", None)
        info = self._mezgls(iid)
        if not info:
            return None
        avots = v["avots"]
        no_gid = avots["gid"]
        if info["veids"] == "S":
            if info.get("gid") and self._vilkams(info["gid"]):
                info = {"veids": "G", "gid": info["gid"]}
            elif info["ipas"][0] == "F":
                info = {"veids": "F", "rel": info["ipas"][1]}
            else:
                return None
        if info["veids"] == "G":
            gid = info["gid"]
            if not self._vilkams(gid):
                return None
            if avots["veids"] == "G" and (gid == no_gid or gid in self._pecteci(no_gid)):
                return None
            if avots["veids"] == "S" and gid == no_gid:
                return None
            return ("G", gid)
        if info["veids"] == "F":
            return ("F", info["rel"])
        return None

    def _vilk_sakt(self, e):
        iid = self.tv_grupas.identify_row(e.y)
        if self.tv_grupas.identify_element(e.x, e.y) in ("Treeitem.indicator", "indicator"):
            self._vilk = None
            return
        avots = self._vilk_avots(iid)
        self._vilk = {"no": iid, "avots": avots, "y": e.y, "uz": None, "uz_iid": None, "velk": False,
                      "tagi": None} if avots else None

    def _vilk_noņemt_izcelsmi(self):
        v = self._vilk
        if v and v.get("uz_iid") and self.tv_grupas.exists(v["uz_iid"]) and v.get("tagi") is not None:
            self.tv_grupas.item(v["uz_iid"], tags=v["tagi"])
        if v:
            v["uz_iid"], v["tagi"] = None, None

    def _vilk_kust(self, e):
        v = self._vilk
        if not v:
            return
        if not v["velk"] and abs(e.y - v["y"]) < 8:
            return
        v["velk"] = True
        tv = self.tv_grupas
        iid = tv.identify_row(e.y)
        if iid != v["uz_iid"] or v["uz"] is None:
            self._vilk_noņemt_izcelsmi()
            v["uz"] = self._vilk_merkis(v, iid)
            if v["uz"] and iid:
                v["uz_iid"], v["tagi"] = iid, tuple(tv.item(iid, "tags"))
                tv.item(iid, tags=v["tagi"] + ("drop",))
            self.var_statuss.set(
                "Atlaid, lai ieliktu šeit." if v["uz"] and iid else
                ("Atlaid tukšā vietā, lai izņemtu no mapes." if v["uz"] else "Šeit ielikt nevar."))
        # ritināšana pie malām
        if e.y < 15:
            tv.yview_scroll(-1, "units")
        elif e.y > tv.winfo_height() - 15:
            tv.yview_scroll(1, "units")

    def _vilk_beigt(self, e):
        v = self._vilk
        if not v or not v["velk"]:
            self._vilk = None
            return
        self._vilk_noņemt_izcelsmi()
        self._vilk = None
        self.var_statuss.set("")
        uz, avots = v.get("uz"), v["avots"]
        if not uz:
            return
        veids, kur = uz
        if avots["veids"] == "S":                       # ielikta grupa – vispirms izņemam
            g_ip = avots["gid"]
            if veids == "SAKNE":
                if messagebox.askyesno("Izņemt", f"Izņemt “{avots['celš']}” no grupas "
                                                 f"“{self.grupas_nosaukums(self.grupas[g_ip])}”?\n\n"
                                                 "Tā atkal būs atsevišķa grupa."):
                    self.izņemt_ielikto(g_ip, avots["ielikta"])
                return
            m_ip = self._merka_rinda(self.grupas[g_ip])
            jauns = self.izņemt_ielikto(g_ip, avots["ielikta"])
            if not jauns:
                return
            no = jauns
            atpakal = (g_ip, avots["celš"], avots["ielikta"], m_ip["mape"] if m_ip else None)
        else:
            atpakal = None
            no = avots["gid"]
        ok = False
        if veids == "G":
            ok = self.ielikt_grupu_grupa(no, kur)
        elif veids == "F":
            ok = self.ielikt_esosa_mape(no, kur)
        if not ok and atpakal and no in self.grupas and atpakal[0] in self.grupas:
            self.ielikt_grupu_grupa(no, atpakal[0], jautat=False)     # atcelts – liekam atpakaļ
        elif veids == "SAKNE":
            g = self.grupas[no]
            m = self._merka_rinda(g)
            if m and m.get("vecāka_mape") and messagebox.askyesno(
                    "Izņemt", f"Izņemt “{m['mērķa_nosaukums']}” no mapes “{m['vecāka_mape']}”?"):
                self._iestatit_vecaku(g, "", "")
                g["vecaks_iestatits"] = True
                g["vecaks_patur_grupas"] = False
                self.analizes.pop(no, None)
                self.saglabat_lemumu(no)
                self.log(f"{no}: netiks likta citā mapē")
                self.paradit_grupas()
                self.paradit_detalas()

    def ielikt_esosa_mape(self, gid, rel):
        """Grupu ieliek esošā (kārtībā esošā) mapē."""
        g = self.grupas[gid]
        m = self._merka_rinda(g)
        if not m:
            return
        if self._burts(m["mape"]) != self._burts(rel):
            messagebox.showinfo("Ielikt mapē", "Mapes ir dažādās burtu mapēs – ielikt var tikai mapē, kas ir "
                                               "tajā pašā burtā.")
            return
        vecaks = rel.split("/")[-1]
        ok, patur = self.jautat_ar_kekši(
            "Ielikt mapē", f"Ielikt “{m['mērķa_nosaukums']}” mapē “{vecaks}”?\n\nRezultāts: "
            f"{vecaks}\\{m['mērķa_nosaukums']}\n\nMapes “{vecaks}” faili tiks salīdzināti ar grupas failiem "
            "(dublikātus izmetīs).", "dublikātiem paturēt grupas versiju (no mapes “" + vecaks + "” izmest)")
        if not ok:
            return False
        self._iestatit_vecaku(g, vecaks, rel if rel in self.mapes else "")
        g["vecaks_iestatits"] = True
        g["vecaks_patur_grupas"] = bool(patur)
        self.analizes.pop(gid, None)
        self.saglabat_lemumu(gid)
        self.log(f"{gid}: tiks ielikta mapē “{vecaks}”")
        self.izv_grupa, self.izv_mezgls, self.failu_filtrs = gid, gid, None
        self.paradit_grupas()
        self.paradit_detalas()
        return True

    def ielikt_grupu_grupa(self, no, uz, jautat=True):
        """Grupu `no` ieliek grupā `uz` kā apakšmapi: abu failus salīdzina kopā, izpilda vienu grupu."""
        g, gu = self.grupas[no], self.grupas[uz]
        m_no = next((r for r in g["rindas"] if r["darbība"] in ("MĒRĶIS", "PĀRDĒVĒT")), None)
        m_uz = next((r for r in gu["rindas"] if r["darbība"] in ("MĒRĶIS", "PĀRDĒVĒT")), None)
        if not m_no or not m_uz:
            return False
        nos_no, nos_uz = m_no["mērķa_nosaukums"], m_uz["mērķa_nosaukums"]
        if not A.derigs_nosaukums(nos_no):
            messagebox.showwarning("Ielikt mapē", f"Nederīgs nosaukums: {nos_no}")
            return False
        patur = False
        if jautat:
            ok, patur = self.jautat_ar_kekši(
                "Ielikt mapē", f"Ielikt “{nos_no}” grupā “{nos_uz}” kā apakšmapi?\n\n"
                f"Rezultāts: {nos_uz}\\{nos_no}\n\nAbu grupu faili tiks salīdzināti kopā (dublikātus "
                f"izmetīs, līdzīgos izvēlēsies tu), un tās izpildīs kopā – kā vienu grupu “{nos_uz}”.\n"
                "Izņemt var ar pogu “⌂ Ielikt mapē…”, iezīmējot ielikto mapi.",
                f"dublikātiem paturēt versiju apakšmapē “{nos_no}” (no pārējām mapēm izmest)")
            if not ok:
                return False
        self._pievienot_apaksgrupu(no, uz, nos_no, m_no["mape"])
        d = self.ielasit_lemumus()
        d.setdefault("__ieliktas__", {})[m_no["mape"]] = {"uz": m_uz["mape"], "apaksmape": nos_no,
                                                          "patur": bool(patur)}
        self._rakstit_lemumus(d)
        self.saglabat_lemumu(uz)
        self.analizes.pop(uz, None)
        self.log(f"“{nos_no}” ielikta grupā “{nos_uz}” kā apakšmape")
        self.izv_grupa, self.izv_mezgls, self.failu_filtrs = uz, uz, None
        self._atverti.add(uz)
        self.paradit_grupas()
        if self.tv_grupas.exists(uz):
            self.tv_grupas.selection_set(uz)
            self.tv_grupas.see(uz)
        self.paradit_detalas()
        return True

    def jautat_ar_kekši(self, virsraksts, teksts, kekša_teksts):
        """Jā/Nē jautājums ar vienu ķeksīti. Atgriež (jā?, ķeksītis?)."""
        dl = tk.Toplevel(self)
        dl.title(virsraksts)
        dl.transient(self)
        ttk.Label(dl, text=teksts, justify="left", wraplength=int(520 * self.k)).pack(anchor="w", padx=12, pady=10)
        v = tk.BooleanVar(value=False)
        ttk.Checkbutton(dl, text=kekša_teksts, variable=v).pack(anchor="w", padx=12, pady=(0, 10))
        rez = {"ok": False}
        p_ = ttk.Frame(dl)
        p_.pack(fill="x", padx=12, pady=(0, 12))
        ttk.Button(p_, text="Jā", command=lambda: (rez.update(ok=True), dl.destroy())).pack(side="left")
        ttk.Button(p_, text="Nē", command=dl.destroy).pack(side="left", padx=6)
        dl.grab_set()
        self.wait_window(dl)
        return rez["ok"], v.get()

    def _rakstit_lemumus(self, d):
        try:
            self.zurnalu_mape()
            self.lemumu_fails().write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
        except Exception as e:
            self.log(f"Neizdevās saglabāt lēmumu: {e}")

    def _pievienot_apaksgrupu(self, no, uz, apaksmape, atsl):
        g = self.grupas.pop(no)
        gu = self.grupas[uz]
        nos = next((r["mērķa_nosaukums"] for r in gu["rindas"] if r["darbība"] in ("MĒRĶIS", "PĀRDĒVĒT")),
                   gu["rindas"][0]["mērķa_nosaukums"])
        for r in g["rindas"]:
            if r["darbība"] == VEC:
                continue
            if r["darbība"] in ("MĒRĶIS", "PĀRDĒVĒT"):
                r["darbība"] = "APVIENOT"
            r["apakšmape"] = apaksmape
            r["vecāka_mape"] = ""
            r["grupa"] = uz
            r["mērķa_nosaukums"] = nos
            r["ielikta"] = atsl
            gu["rindas"].append(r)
        self.parrekinat_merki(gu)

    def izņemt_ielikto(self, gid, atsl):
        """Atdala ielikto grupu atpakaļ par atsevišķu grupu."""
        g = self.grupas[gid]
        rr = [r for r in g["rindas"] if r.get("ielikta") == atsl]
        if not rr:
            return
        g["rindas"] = [r for r in g["rindas"] if r.get("ielikta") != atsl]
        n = 1
        while f"{gid}-{n}" in self.grupas:
            n += 1
        jauns = f"{gid}-{n}"
        nos = rr[0].get("apakšmape") or atsl.split("/")[-1]
        for r in rr:
            r.pop("ielikta", None)
            r["apakšmape"] = ""
            r["grupa"] = jauns
            r["mērķa_nosaukums"] = nos
            r["darbība"] = "PĀRDĒVĒT" if r["mape"] == atsl else (
                "APVIENOT" if r["darbība"] == "APVIENOT" else r["darbība"])
        rr.sort(key=lambda r: r["mape"] != atsl)
        self.grupas[jauns] = {"rindas": rr, "izpildita": False, "gid": jauns}
        self.parrekinat_merki(self.grupas[jauns])
        self.parrekinat_merki(g)
        d = self.ielasit_lemumus()
        d.get("__ieliktas__", {}).pop(atsl, None)
        self._rakstit_lemumus(d)
        self.saglabat_lemumu(gid)
        self.saglabat_lemumu(jauns)
        self.analizes.pop(gid, None)
        self.log(f"“{nos}” izņemta no grupas – atkal atsevišķa grupa")
        self.izv_mezgls, self.failu_filtrs = gid, None
        self.paradit_grupas()
        if self.tv_grupas.exists(gid):
            self.tv_grupas.selection_set(gid)
        self.paradit_detalas()
        return jauns

    def pielietot_ieliksanas(self):
        """Pēc skenēšanas atkal saliek grupas, kas ar peli/“Ielikt mapē…” ieliktas citās grupās."""
        iekl = self.ielasit_lemumus().get("__ieliktas__", {})
        for atsl, info in iekl.items():
            def atrast(mape, tikai_merkis=False):
                for gid, g in self.grupas.items():
                    if g.get("izpildita") or "tirisana" in g:
                        continue
                    for r in g["rindas"]:
                        if r["mape"] == mape and r["darbība"] != VEC and not r.get("ielikta") and (
                                not tikai_merkis or r["darbība"] in ("MĒRĶIS", "PĀRDĒVĒT", "APVIENOT")):
                            return gid
                return None
            no, uz = atrast(atsl), atrast(info.get("uz"), True)
            if no and uz and no != uz:
                self._pievienot_apaksgrupu(no, uz, info.get("apaksmape") or atsl.split("/")[-1], atsl)

    def ielikt_mape(self):
        gid = self.izv_grupa
        if not gid or gid not in self.grupas or "tirisana" in self.grupas[gid]:
            return
        g = self.grupas[gid]
        if g["izpildita"]:
            messagebox.showinfo("Izpildīta", "Šī grupa jau ir izpildīta.")
            return
        sel = self.tv_mapes.selection()
        if sel and int(sel[0]) < len(g["rindas"]) and g["rindas"][int(sel[0])].get("ielikta"):
            r0 = g["rindas"][int(sel[0])]
            if messagebox.askyesno("Izņemt", f"Izņemt “{r0.get('apakšmape')}” no šīs grupas?\n\n"
                                             "Tā atkal būs atsevišķa grupa un netiks likta šajā mapē."):
                self.izņemt_ielikto(gid, r0["ielikta"])
            return
        merka = next((r for r in g["rindas"] if r["darbība"] in ("MĒRĶIS", "PĀRDĒVĒT")), None)
        if merka is None:
            return
        burts = merka["mape"].split("/")[0] if "/" in merka["mape"] and not self.var_bez_burtiem.get() else ""
        sava = {r["mape"] for r in g["rindas"] if r["darbība"] != VEC}
        try:
            vietas = sorted((p.name for p in (self.sakne / burts if burts else self.sakne).iterdir()
                             if p.is_dir() and not A.sistemas(p.name)
                             and (f"{burts}/{p.name}" if burts else p.name) not in sava), key=str.casefold)
        except OSError:
            vietas = []
        dl = tk.Toplevel(self)
        dl.title("Ielikt mapē")
        dl.transient(self)
        ttk.Label(dl, text=f"Kurā mapē ielikt “{merka['mērķa_nosaukums']}”?\n"
                           f"(mapes burtā “{burts or 'arhīva sakne'}”; raksti, lai atlasītu)",
                  justify="left").pack(anchor="w", padx=10, pady=(10, 4))
        var = tk.StringVar(value=merka.get("vecāka_mape") or "")
        ent = ttk.Entry(dl, textvariable=var, width=50)
        ent.pack(fill="x", padx=10)
        lb = tk.Listbox(dl, height=14, exportselection=False)
        lb.pack(fill="both", expand=True, padx=10, pady=6)

        def atlasit(*_):
            f = A.atslega(var.get())
            lb.delete(0, "end")
            for v in vietas:
                if not f or f in A.atslega(v):
                    lb.insert("end", v)
        var.trace_add("write", atlasit)
        atlasit()
        lb.bind("<<ListboxSelect>>", lambda e: lb.curselection() and var.set(lb.get(lb.curselection()[0])))
        var_pat = tk.BooleanVar(value=g.get("vecaks_patur_grupas", False))
        ttk.Checkbutton(dl, text="dublikātiem paturēt versiju ieliekamajā mapē (no augšējās mapes izmest)",
                        variable=var_pat).pack(anchor="w", padx=10, pady=(0, 6))
        rez = {}
        pogas = ttk.Frame(dl)
        pogas.pack(fill="x", padx=10, pady=(0, 10))
        def ielikt():
            v = var.get().strip()
            sar = lb.get(0, "end")
            if lb.curselection():
                v = lb.get(lb.curselection()[0])
            elif not any(A.nfc(x).casefold() == A.nfc(v).casefold() for x in vietas):
                if len(sar) == 1:
                    v = sar[0]
                elif sar:
                    messagebox.showinfo("Ielikt mapē", "Izvēlies mapi sarakstā.", parent=dl)
                    return
                elif not v or not messagebox.askyesno("Ielikt mapē", f"Mapes “{v}” vēl nav. Izveidot jaunu?",
                                                      parent=dl):
                    return
            rez.update(v=v)
            dl.destroy()
        ttk.Button(pogas, text="Ielikt", command=ielikt).pack(side="left")
        ttk.Button(pogas, text="Nelikt nekur", command=lambda: (rez.update(v=""), dl.destroy())).pack(
            side="left", padx=6)
        ttk.Button(pogas, text="Atcelt", command=dl.destroy).pack(side="right")
        ent.focus_set()
        dl.grab_set()
        self.wait_window(dl)
        if "v" not in rez:
            return
        vecaks = A.nfc(rez["v"])
        if vecaks and (any(c in A.LOGU_AIZLIEGTAS for c in vecaks) or vecaks.endswith((".", " "))):
            messagebox.showwarning("Mape", 'Nosaukums nedrīkst beigties ar punktu vai saturēt  < > : " / \\ | ? *')
            return
        esosa = next((v for v in vietas if A.nfc(v).casefold() == vecaks.casefold()), None)
        if esosa:
            vecaks = A.nfc(esosa)
        rel = (f"{burts}/{esosa}" if burts else esosa) if esosa else ""
        # ja mape pati ir vēl neizpildītā grupā – ieliekam šo grupu tajā grupā (kā apakšmapi)
        if rel:
            for gid2, g2 in self.grupas.items():
                if gid2 != gid and not g2["izpildita"] and "tirisana" not in g2 and any(
                        r["mape"] == rel and r["darbība"] in ("MĒRĶIS", "PĀRDĒVĒT", "APVIENOT")
                        for r in g2["rindas"]):
                    self._iestatit_vecaku(g, "", "")
                    g["vecaks_iestatits"] = False
                    self.ielikt_grupu_grupa(gid, gid2)
                    return
        self._iestatit_vecaku(g, vecaks, rel)
        g["vecaks_iestatits"] = True
        g["vecaks_patur_grupas"] = bool(var_pat.get()) and bool(vecaks)
        self.analizes.pop(gid, None)            # jāsalīdzina no jauna (cita paturēšanas kārtība)
        self.saglabat_lemumu(gid)
        self.log(f"{gid}: " + (f"tiks ielikta mapē “{vecaks}”" if vecaks else "netiks likta citā mapē"))
        self.atjaunot_grupas_rindu(gid)
        self.paradit_detalas()

    def mainit_nosaukumu(self):
        gid = self.izv_grupa
        if not gid or gid not in self.grupas or self.grupas[gid]["izpildita"] or "tirisana" in self.grupas[gid]:
            return
        jauns = A.nfc(self.var_merkis.get().strip())
        if not jauns or any(c in A.LOGU_AIZLIEGTAS for c in jauns) or jauns.endswith((".", " ")):
            messagebox.showwarning("Nosaukums", 'Nosaukums nedrīkst būt tukšs, beigties ar punktu vai saturēt '
                                                'zīmes  < > : " / \\ | ? *')
            return
        g = self.grupas[gid]
        vecie = {r["mape"]: r["mērķa_nosaukums"] for r in g["rindas"]}
        for r in g["rindas"]:
            r["mērķa_nosaukums"] = jauns
        self.parrekinat_merki(g)
        if not self.apstiprinat_esosu_merki(gid):
            for r in g["rindas"]:
                r["mērķa_nosaukums"] = vecie[r["mape"]]
            self.parrekinat_merki(g)
            self.var_merkis.set(self.grupas_nosaukums(g))
            return
        self.saglabat_lemumu(gid)
        self.log(f"{gid}: paliekošais nosaukums → {jauns}")
        apv = self.apvienot_vienadus_merkus(tikai=gid)
        if apv:
            gid = self.izv_grupa = next(iter(apv.values()))
            self.saglabat_lemumu(gid)
            self.log(f"Apvienots vienā grupā: {self.grupas_nosaukums(self.grupas[gid])}")
            self.paradit_grupas()
            if self.tv_grupas.exists(gid):
                self.tv_grupas.selection_set(gid)
                self.tv_grupas.see(gid)
        else:
            self.atjaunot_grupas_rindu(gid)
        self.paradit_detalas()

    def grupas_merka_cels(self, g):
        """Kur nonāks grupas paliekošā mape (vai None, ja nav nosakāms)."""
        try:
            darbi = A.sagatavot_darbus(self.sakne, [dict(r) for r in g["rindas"]],
                                       self.var_bez_burtiem.get(), log=lambda *a: None)
            return darbi[0].dst if darbi else None
        except Exception:
            return None

    def apstiprinat_esosu_merki(self, gid):
        """Brīdina, ja jaunais nosaukums sakrīt ar citu mapi (esošu vai citas grupas mērķi)."""
        g = self.grupas[gid]
        dst = self.grupas_merka_cels(g)
        if dst is None:
            return True
        def k(p):
            return A.nfc(str(p)).casefold()
        savas = {k(self.sakne / r["mape"]) for r in g["rindas"]}
        if k(dst) in savas:
            return True
        rel = dst.relative_to(self.sakne).as_posix()
        citas = [self.grupas_nosaukums(g2) for gid2, g2 in self.grupas.items()
                 if gid2 != gid and not g2.get("izpildita") and "tirisana" not in g2
                 and (d2 := self.grupas_merka_cels(g2)) is not None and k(d2) == k(dst)]
        try:
            atr = [c for c in dst.parent.iterdir() if c.is_dir() and k(c) == k(dst)] if dst.parent.is_dir() else []
            esosa = bool(atr)
            if atr:
                rel = atr[0].relative_to(self.sakne).as_posix()
        except OSError:
            esosa = dst.exists()
        if not esosa and not citas:
            return True
        teksts = (f"Mape ar šādu nosaukumu jau ir:\n{rel}\n\n" if esosa else
                  f"Šādu pašu nosaukumu jau saņems cita grupa:\n{', '.join(citas)}\n\n")
        teksts += ("Ja turpināsi, mapes tiks saliktas VIENĀ grupā un, izpildot to, apvienosies.\n"
                   "Programma salīdzinās to failus (arī bildes): dublikāti tiks izmesti, "
                   "līdzīgos izvēlēsies tu.\nNekas netiek mainīts, kamēr nespied “Izpildīt”.\n\n"
                   "Turpināt ar šo nosaukumu?")
        ok = messagebox.askyesno("Mapes apvienosies", teksts)
        self.log(f"{gid}: nosaukums sakrīt ar {rel} – " + ("apstiprināts, mapes apvienosies" if ok else "atcelts"))
        return ok

    def apvienot_vienadus_merkus(self, tikai=None):
        """Grupas, kuru paliekošā mape būs viena un tā pati (vai tāda mape jau ir), saliek vienā grupā.
        Atgriež {vecais gid: jaunais gid}."""
        if not self.sakne:
            return {}
        def k(p):
            return A.nfc(str(p)).casefold()
        pec_dst = {}
        for gid, g in self.grupas.items():
            if g.get("izpildita") or "tirisana" in g or not g["rindas"]:
                continue
            d = self.grupas_merka_cels(g)
            if d is not None:
                pec_dst.setdefault(k(d), []).append((gid, d))
        grupu_mapes = {r["mape"] for g in self.grupas.values() for r in g["rindas"]}
        rez = {}
        for kd, saraksts in pec_dst.items():
            gids = sorted(gid for gid, _ in saraksts)
            if tikai and tikai not in gids:
                continue
            dst = saraksts[0][1]
            esosa = None                     # esoša mape šajā vietā, kas nav nevienā grupā
            try:
                if dst.parent.is_dir():
                    for c in dst.parent.iterdir():
                        if c.is_dir() and k(c) == kd:
                            rel = c.relative_to(self.sakne).as_posix()
                            if rel not in grupu_mapes and rel in self.mapes:
                                esosa = rel
                            break
            except OSError:
                pass
            if len(gids) < 2 and not esosa:
                continue
            galv = next((gid for gid in gids for r in self.grupas[gid]["rindas"]
                         if k(self.sakne / r["mape"]) == kd), gids[0])
            nos = esosa.split("/")[-1] if esosa else self.grupas[galv]["rindas"][0]["mērķa_nosaukums"]
            rr = []
            if esosa:
                rr.append(A._rinda(galv, "MĒRĶIS", nos, self.mapes[esosa], "", "",
                                   "mape ar šo nosaukumu jau ir"))
            rr += self.grupas[galv]["rindas"]
            for gid in gids:
                if gid != galv:
                    rr += self.grupas[gid]["rindas"]
                    del self.grupas[gid]
                    rez[gid] = galv
            merkis_ir = False
            for r in rr:
                r["grupa"] = galv
                r["mērķa_nosaukums"] = nos
                if r["darbība"] in ("MĒRĶIS", "PĀRDĒVĒT"):
                    if merkis_ir:
                        r["darbība"] = "APVIENOT"
                        r["apakšmape"] = ""
                    merkis_ir = True
            # mērķa rinda – pirmā
            rr.sort(key=lambda r: r["darbība"] not in ("MĒRĶIS", "PĀRDĒVĒT"))
            self.grupas[galv]["rindas"] = rr
            self.parrekinat_merki(self.grupas[galv])
            rez[galv] = galv
        return rez

    def parrekinat_merki(self, g):
        for r in g["rindas"]:
            if r["darbība"] in ("MĒRĶIS", "PĀRDĒVĒT"):
                pasr = A.nfc(r["mape"].split("/")[-1])
                r["darbība"] = "MĒRĶIS" if pasr == r["mērķa_nosaukums"] else "PĀRDĒVĒT"

    def lemumu_fails(self):
        return (self.sakne / ZURNALU_MAPE / "lemumi.json") if self.sakne else None

    def ielasit_lemumus(self):
        f = self.lemumu_fails()
        try:
            return json.loads(f.read_text(encoding="utf-8")) if f and f.exists() else {}
        except Exception:
            return {}

    def saglabat_lemumu(self, gid):
        g = self.grupas[gid]
        d = self.ielasit_lemumus()
        rr = [r for r in g["rindas"] if r["darbība"] != VEC]
        atsl = "|".join(sorted(r["mape"] for r in rr))
        d.pop(atsl, None)                      # jaunākais lēmums – saraksta beigās
        merka = next((r for r in rr if r["darbība"] in ("MĒRĶIS", "PĀRDĒVĒT")), None)
        d[atsl] = {"merkis": g["rindas"][0]["mērķa_nosaukums"],
                   "darbibas": {r["mape"]: r["darbība"] for r in rr}}
        if g.get("vecaks_iestatits"):            # tikai, ja to izvēlējies lietotājs (“Ielikt mapē…”)
            d[atsl]["vecaks"] = (merka.get("vecāka_mape") or "") if merka else ""
            d[atsl]["vecaka_rel"] = next((r["mape"] for r in g["rindas"] if r["darbība"] == VEC), "")
            d[atsl]["vecaks_patur_grupas"] = g.get("vecaks_patur_grupas", False)
        try:
            self.zurnalu_mape()
            self.lemumu_fails().write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
        except Exception as e:
            self.log(f"Neizdevās saglabāt lēmumu: {e}")

    def pielietot_lemumus(self):
        """Pielieto saglabātos lēmumus hronoloģiskā secībā (jaunākais uzvar).
        Ja grupas sastāvs mainījies, paliekošo nosaukumu pielieto visām grupām, kurās ir lēmuma mapes
        (tā pārsauktās/apvienotās grupas pēc jaunas skenēšanas atkal saliekas kopā)."""
        d = self.ielasit_lemumus()
        if not d:
            return 0
        d = {k: v for k, v in d.items() if not k.startswith("__")}
        pec_mapes = {}
        for gid, g in self.grupas.items():
            if "tirisana" in g:
                continue
            for r in g["rindas"]:
                if r["darbība"] != VEC:
                    pec_mapes[r["mape"]] = gid
        skarts = set()
        for atsl, lem in d.items():
            mapes_lem = atsl.split("|")
            gids = {pec_mapes[m] for m in mapes_lem if m in pec_mapes}
            for gid in gids:
                g = self.grupas[gid]
                if g.get("izpildita"):
                    continue
                if "|".join(sorted(r["mape"] for r in g["rindas"] if r["darbība"] != VEC)) == atsl:
                    for r in g["rindas"]:
                        r["mērķa_nosaukums"] = lem["merkis"]
                        r["darbība"] = lem["darbibas"].get(r["mape"], r["darbība"])
                    g["rindas"].sort(key=lambda r: r["darbība"] not in ("MĒRĶIS", "PĀRDĒVĒT"))
                    if "vecaks" in lem:
                        self._iestatit_vecaku(g, lem.get("vecaks", ""), lem.get("vecaka_rel", ""))
                        g["vecaks_iestatits"] = True
                        g["vecaks_patur_grupas"] = lem.get("vecaks_patur_grupas", False)
                    skarts.add(gid)
                    continue
                # sastāvs mainījies: "atstāt atsevišķi" saglabājam; nosaukumu – ja grupā ir lēmuma
                # mērķa vai apvienojamā mape
                for r in g["rindas"]:
                    if lem["darbibas"].get(r["mape"]) == "ATSTĀT" and r["darbība"] not in ("MĒRĶIS", "PĀRDĒVĒT"):
                        r["darbība"] = "ATSTĀT"
                        skarts.add(gid)
                if len(mapes_lem) > 1 or lem["merkis"] != A.nfc(mapes_lem[0].split("/")[-1]):
                    if any(lem["darbibas"].get(r["mape"]) in ("MĒRĶIS", "PĀRDĒVĒT", "APVIENOT")
                           for r in g["rindas"]):
                        for r in g["rindas"]:
                            r["mērķa_nosaukums"] = lem["merkis"]
                        skarts.add(gid)
        for gid in skarts:
            self.parrekinat_merki(self.grupas[gid])
        return len(skarts)

    # ------------------------------------------------------ plāns (CSV)
    def visas_rindas(self):
        return [r for g in self.grupas.values() if not g["izpildita"] for r in g["rindas"]]

    def saglabat_planu(self):
        if not self.grupas:
            messagebox.showinfo("Plāns", "Vispirms noskenē arhīvu.")
            return
        p = filedialog.asksaveasfilename(title="Saglabāt plānu", defaultextension=".csv",
                                         initialfile="grupas.csv", filetypes=[("CSV", "*.csv")])
        if p:
            A.saglabat_planu(self.visas_rindas(), p)
            self.log(f"Plāns saglabāts: {p}")

    def ieladet_planu(self):
        if not self.var_arhivs.get().strip():
            messagebox.showwarning("Plāns", "Vispirms izvēlies arhīva mapi.")
            return
        p = filedialog.askopenfilename(title="Ielādēt plānu", filetypes=[("CSV", "*.csv")])
        if not p:
            return
        try:
            rindas = A.lasit_planu(p)
        except A.PlanaKluda as e:
            messagebox.showerror("Plāns", str(e))
            return
        self.sakne = Path(self.var_arhivs.get().strip()).resolve()
        self.grupas = {}
        for r in rindas:
            for k in A.LAUKI:
                r.setdefault(k, "")
            r["darbība"] = r["darbība"].strip().upper()
            self.grupas.setdefault(r["grupa"].strip(), {"rindas": [], "izpildita": False,
                                                        "gid": r["grupa"].strip()})["rindas"].append(r)
        self.log(f"Plāns ielādēts: {p} ({len(self.grupas)} grupas). Failu salīdzinājumam noskenē arhīvu.")
        self.paradit_grupas()
        self.notirit_detalas()

    # ------------------------------------------------------------ izpilde
    def izpildit_grupu(self):
        if not self.izv_grupa or self.izv_grupa not in self.grupas:
            messagebox.showinfo("Izpilde", "Vispirms izvēlies grupu sarakstā kreisajā pusē.")
            return
        g = self.grupas[self.izv_grupa]
        if g["izpildita"]:
            messagebox.showinfo("Izpilde", "Šī grupa jau ir izpildīta.")
            return
        self.izpildit([self.izv_grupa])

    def izpildit_visas(self):
        gatavas = [gid for gid, g in self.grupas.items() if self.stavoklis(g) in ("drosa", "pardevet")]
        if not gatavas:
            messagebox.showinfo("Izpilde", "Nav nevienas gatavas grupas.")
            return
        self.izpildit(gatavas, vairakas=True)

    def izpildit(self, gid_saraksts, vairakas=False):
        """1) salīdzina failus grupās, kurām tas vēl nav izdarīts; 2) apstiprināšana; 3) izpilde."""
        trukst = [gid for gid in gid_saraksts if not self.analize_aktuala(gid)]
        if not trukst:
            self._izpildit_turpinat(gid_saraksts, vairakas)
            return

        def darbs():
            rez = {}
            for n, gid in enumerate(trukst, 1):
                self.q.put(("statuss", f"Salīdzinu failus {n}/{len(trukst)}: "
                                       f"{self.grupas_nosaukums(self.grupas[gid])}"))
                rez[gid] = self.analizet(gid)
            return rez

        def kad(rez):
            self.analizes.update(rez)
            for gid in rez:
                self.atjaunot_grupas_rindu(gid)
            self._izpildit_turpinat(gid_saraksts, vairakas)
        self.fona(darbs, kad, "Salīdzinu failus…")

    def _izpildit_turpinat(self, gid_saraksts, vairakas):
        tirisana = None
        if TIR in gid_saraksts:
            if not self.grupas[TIR]["izpildita"]:
                an_t = self.analizes.get(TIR)
                if an_t:
                    for k in an_t["kopas"]:          # neizlemtās līdzīgās kopijas – paliek visas
                        if k["veids"] == "jaizlemj" and not k["lietotajs"]:
                            k["paturet"] = set(k["versijas"])
                tirisana = A.tirisanas_darbibas(self.grupas[TIR]["tirisana"], an_t)
            gid_saraksts = [g for g in gid_saraksts if g != TIR]
        neizl = {gid: self.neizlemtas(self.grupas[gid]) for gid in gid_saraksts}
        neizl = {k: v for k, v in neizl.items() if v}
        if neizl:
            if vairakas:
                gid_saraksts = [g for g in gid_saraksts if g not in neizl]
                self.log(f"{len(neizl)} grupās ir līdzīgi faili, par kuriem jāizlemj tev – tās izlaistas "
                         f"(filtrs “Jāpārbauda”).")
                self.paradit_grupas()
                if not gid_saraksts:
                    messagebox.showinfo("Izpilde", "Visās gatavajās grupās ir līdzīgi faili, par kuriem "
                                                   "jāizlemj tev. Atrodi tās ar filtru “Jāpārbauda”.")
                    return
            else:
                n = sum(neizl.values())
                if not messagebox.askyesno("Līdzīgi faili", f"Šajā grupā ir līdzīgi, bet ne vienādi faili "
                                           f"(bildes vai dokumenti), par kuriem neesi izlēmis: {n}.\n\nVai paturēt "
                                           f"VISAS to versijas?\n(Nē – atgriezties un izvēlēties pašam)"):
                    return
        rindas = [r for gid in gid_saraksts for r in self.grupas[gid]["rindas"]]
        izlaistas = []
        darbi = A.sagatavot_darbus(self.sakne, rindas, self.var_bez_burtiem.get(), log=izlaistas.append)
        for t in izlaistas:
            self.log(t)
        if not darbi and not tirisana:
            messagebox.showinfo("Izpilde", "Nav ko darīt – izvēlētajās grupās neviena mape nav atzīmēta "
                                           "apvienošanai vai pārdēvēšanai.")
            return
        izmest, parsaukt = {}, {}
        skaiti = {"identiski": 0, "vienadi": 0, "lietotajs": 0, "citi": 0}
        for d in darbi:
            gid = d.gid
            an = self.analizes.get(gid)
            if not an:
                continue
            izmest[gid] = A.izmetamie(an["kopas"])
            parsaukt[gid] = [(rel, n) for rel, n in an["parsaukt"].items() if rel not in izmest[gid]]
            for k in an["kopas"]:
                n = len([v for v in k["versijas"] if v not in k["paturet"]])
                if k["lietotajs"]:
                    skaiti["lietotajs"] += n
                elif k["veids"] in ("identiski", "vienadi", "tukss"):
                    skaiti[k["veids"]] = skaiti.get(k["veids"], 0) + n
                else:
                    skaiti["citi"] += n
        # brīdinājums, ja mērķis ir cita, neiekļauta mape
        svesas = []
        for d in darbi:
            visas = {(self.sakne / r["mape"]).resolve() for r in self.grupas[d.gid]["rindas"]}
            if d.dst.exists() and d.dst.resolve() not in visas:
                svesas.append(d.dst.relative_to(self.sakne).as_posix())
        apraksts = []
        for d in darbi[:12]:
            rinda = f"• {d.dst.relative_to(self.sakne).as_posix()}  ← {len(d.soli)} mape(s)"
            apaks = sorted({dest.name for _, dest in d.soli if dest != d.dst})
            if apaks:
                rinda += f", apakšmapes: {', '.join(apaks[:4])}" + (" …" if len(apaks) > 4 else "")
            apraksts.append(rinda)
        if len(darbi) > 12:
            apraksts.append(f"… un vēl {len(darbi) - 12} grupas")
        kopa_izm = sum(skaiti.values())
        tir_teksts = ""
        if tirisana:
            sk = {}
            for x in tirisana["izmest"]:
                sk[x["veids"]] = sk.get(x["veids"], 0) + 1
            tir_teksts = (f"Visā arhīvā uz _DUBLIKATI tiks pārvietotas failu kopijas ({sk.get('kopija', 0)}), "
                          f"tukšie ({sk.get('tukss', 0)}) un pagaidu faili ({sk.get('pagaidu', 0)}).\n"
                          f"Tukšās mapes tiks izdzēstas (atrastas skenējot: "
                          f"{len(self.grupas.get(TIR, {}).get('tirisana', {}).get('tuksas_mapes', []))}).\n\n")
        if not darbi:
            teksts = (tir_teksts + "Faili netiek dzēsti. Visu varēs atsaukt ar pogu “Atsaukt pēdējo izpildi”.")
        else:
            teksts = ""
        teksts = teksts or (tir_teksts + f"Tiks izpildītas {len(darbi)} grupas:\n\n" + "\n".join(apraksts) +
                  f"\n\nUz mapi _DUBLIKATI tiks pārvietoti {kopa_izm} faili:"
                  f"\n   • identiski: {skaiti['identiski']}"
                  f"\n   • vizuāli vienādas bildes: {skaiti['vienadi']}"
                  f"\n   • pēc tavas izvēles: {skaiti['lietotajs']}" +
                  (f"\n   • tukši dokumenti: {skaiti['tukss']}" if skaiti.get("tukss") else "") +
                  (f"\n   • citi: {skaiti['citi']}" if skaiti["citi"] else "") +
                  (f"\n\nFaili, kas tiks pārdēvēti (bezvārda dokumenti, kopijas, sakārtoti nosaukumi): "
                   f"{sum(len(v) for v in parsaukt.values())}"
                   if any(parsaukt.values()) else "") +
                  "\n\nPagaidu faili (~$…, Thumbs.db) un tukšie (0 baitu) faili tiks izmesti." +
                  "\n\nFaili netiek dzēsti. Visu varēs atsaukt ar pogu “Atsaukt pēdējo izpildi”.")
        if svesas:
            teksts += ("\n\n⚠ UZMANĪBU: šādas mērķa mapes jau eksistē un nav šajā grupā – saturs tiks "
                       "ielikts tajās:\n" + "\n".join(svesas[:5]))
        if not messagebox.askyesno("Apstiprināt izpildi", teksts, icon="warning" if svesas else "question"):
            return

        zcels = self.zurnalu_mape() / f"zurnals_{datetime.now():%Y%m%d_%H%M%S}.csv"
        izpildamas = [d.gid for d in darbi] + ([TIR] if tirisana else [])

        def prog(i, n, gid):
            self.q.put(("statuss", f"Izpildu {i}/{n}: {self.grupas_nosaukums(self.grupas[gid])}"))

        def darbs():
            return A.izpildit_darbus(self.sakne, darbi, zcels, self.log, prog, izmest=izmest, parsaukt=parsaukt,
                                     tirisana=tirisana)

        def kad(rez):
            sk, kludas, zc, karantina = rez
            for gid in izpildamas:
                self.grupas[gid]["izpildita"] = True
            self.log("Izpilde pabeigta: " + ", ".join(f"{k.strip()}: {v}" for k, v in sk.items()))
            if kludas:
                self.log(f"Kļūdas: {kludas} – skat. žurnāla failu {zc}")
            n_gr = len([g for g in izpildamas if g != TIR])
            darits = ([f"izpildītas {n_gr} grupas"] if n_gr else []) + (["failu kopijas notīrītas"]
                                                                         if TIR in izpildamas else [])
            self.var_statuss.set(f"{' un '.join(darits).capitalize()}. Kļūdas: {kludas}. "
                                 f"Ieteicams pēc tam skenēt no jauna.")
            self.saglabat_sesiju(kluss=True)
            self.paradit_grupas()
            self.paradit_detalas()
            if kludas:
                messagebox.showwarning("Izpilde", f"Pabeigts, bet ar {kludas} kļūdām. Sīkāk – žurnālā.")
        self.fona(darbs, kad, "Izpildu…")

    def turpinat_saglabato(self):
        p = self.var_arhivs.get().strip()
        f = self.sesijas_fails(Path(p)) if p else None
        if not f or not f.exists():
            messagebox.showinfo("Turpināt saglabāto", "Šim arhīvam nav saglabāta darba.")
            return
        try:
            self.ieladet_sesiju(Path(p))
        except Exception as e:
            messagebox.showerror("Turpināt saglabāto", str(e))

    def izmest_pagaidu(self):
        p = self.var_arhivs.get().strip()
        if not p or not Path(p).is_dir():
            messagebox.showwarning("Arhīva mape", "Vispirms izvēlies esošu arhīva mapi.")
            return
        if not messagebox.askyesno("Pagaidu faili", "Visā arhīvā atrast Word/Excel pagaidu failus (~$…), "
                                   "sistēmas failus (Thumbs.db, desktop.ini) un tukšos (0 baitu) failus un "
                                   "pārvietot tos uz _DUBLIKATI, kā arī izdzēst tukšās mapes?\n\n"
                                   "To varēs atsaukt ar “Atsaukt pēdējo izpildi”."):
            return
        self.sakne = Path(p).resolve()
        zcels = self.zurnalu_mape() / f"zurnals_{datetime.now():%Y%m%d_%H%M%S}.csv"

        def kad(rez):
            n, _, m = rez
            self.var_statuss.set(f"Izmesti {n} pagaidu/sistēmas/tukši faili, izdzēstas {m} tukšās mapes. "
                                 f"Ieteicams skenēt no jauna.")
        self.fona(lambda: A.iztirit_liekos(self.sakne, zcels, self.log), kad, "Meklēju pagaidu failus…")

    def atcelt_visu(self):
        """Atsauc VISAS programmas izpildes (no jaunākās uz vecāko) – arhīvs kā pirms kārtošanas."""
        p = self.var_arhivs.get().strip()
        if not p or not Path(p).is_dir():
            messagebox.showwarning("Atcelt visu", "Vispirms izvēlies arhīva mapi.")
            return
        self.sakne = Path(p).resolve()
        zm = self.sakne / ZURNALU_MAPE
        zurnali = sorted((f for f in zm.glob("zurnals_*.csv") if "_ATSAUKTS" not in f.stem),
                         key=lambda f: f.name) if zm.exists() else []
        lemumi = self.lemumu_fails()
        if not zurnali and not (lemumi and lemumi.exists()):
            messagebox.showinfo("Atcelt visu", "Nav nevienas izpildes un neviena lēmuma – arhīvs jau ir sākotnējā "
                                               "stāvoklī.")
            return

        def laiks(f):
            t = f.stem.replace("zurnals_", "")
            try:
                return datetime.strptime(t, "%Y%m%d_%H%M%S").strftime("%d.%m.%Y %H:%M")
            except ValueError:
                return t
        if not zurnali:
            teksts = (f"Arhīvā {self.sakne} nav nevienas programmas izpildes, ko atcelt – programma šeit vēl neko "
                      "nav mainījusi (vai viss jau ir atsaukts).\n\nVai notīrīt tavus lēmumus un sākt no 0?")
        else:
            teksts = (f"Arhīvā {self.sakne}\natcelt VISAS programmas izpildes ({len(zurnali)}, no "
                      f"{laiks(zurnali[0])} līdz {laiks(zurnali[-1])}) un atgriezt arhīvu stāvoklī, kāds tas bija "
                      "pirms kārtošanas?\n\n"
                      "Visi pārvietotie un pārdēvētie faili un mapes tiks atgriezti, arī no _DUBLIKATI; izdzēstās "
                      "tukšās mapes – izveidotas atpakaļ.\n\n"
                      "Izmaiņas, ko veici ar roku (Windows Explorer), netiek atceltas.")
        ok, dzest = self.jautat_ar_kekši(
            "Atcelt visu", teksts,
            "dzēst arī visus manus lēmumus (nosaukumi, izvēles, ielikšanas) – sākt pilnīgi no 0")
        if not ok or (not zurnali and not dzest):
            return
        if zurnali and not messagebox.askyesno("Atcelt visu", f"Tiešām atcelt {len(zurnali)} izpildes?"):
            return

        def darbs():
            kludas = 0
            for i, z in enumerate(reversed(zurnali), 1):
                self.q.put(("statuss", f"Atsaucu {i}/{len(zurnali)}: {laiks(z)}…"))
                kludas += A.atsaukt(z, self.log)
            if dzest:
                t = datetime.now().strftime("%Y%m%d_%H%M%S")
                for f in (lemumi, self.sesijas_fails()):
                    try:
                        if f and f.exists():
                            f.rename(f.with_name(f.name.split(".")[0] + f"_atcelts_{t}" +
                                                 "".join(f.suffixes)))
                    except OSError as e:
                        self.log(f"Neizdevās pārdēvēt {f}: {e}")
            return kludas

        def kad(kludas):
            self.grupas, self.analizes = {}, {}
            self.log(f"Atceltas visas izpildes ({len(zurnali)}). Kļūdas: {kludas}" +
                     (". Lēmumi notīrīti (rezerves kopija _ZURNALI mapē)." if dzest else "."))
            messagebox.showinfo("Atcelt visu", (f"Gatavs. Atceltas izpildes: {len(zurnali)}, kļūdas: {kludas}."
                                                if zurnali else "Izpildes nebija – faili nav mainīti.")
                                + ("\nTavi lēmumi notīrīti – sāc no 0." if dzest else
                                   "\nTavi lēmumi saglabāti.") + "\n\nTagad arhīvs tiks noskenēts no jauna.")
            self.skenet()
        self.fona(darbs, kad, "Atceļu visas izpildes…")

    def atsaukt(self):
        p = self.var_arhivs.get().strip()
        if not p:
            messagebox.showwarning("Atsaukt", "Vispirms izvēlies arhīva mapi.")
            return
        self.sakne = Path(p).resolve()
        zm = self.sakne / ZURNALU_MAPE
        zurnali = sorted((f for f in zm.glob("zurnals_*.csv") if "_ATSAUKTS" not in f.stem),
                         key=lambda f: f.name) if zm.exists() else []
        if not zurnali:
            messagebox.showinfo("Atsaukt", "Nav nevienas izpildes, ko atsaukt.")
            return
        pedejais = zurnali[-1]
        laiks = pedejais.stem.replace("zurnals_", "")
        try:
            laiks = datetime.strptime(laiks, "%Y%m%d_%H%M%S").strftime("%d.%m.%Y %H:%M:%S")
        except ValueError:
            pass
        if not messagebox.askyesno("Atsaukt", f"Atsaukt pēdējo izpildi ({laiks})?\n\n"
                                              f"Visi faili un mapes tiks atgriezti iepriekšējā vietā."):
            return

        def kad(kludas):
            self.log(f"Atsaukšana pabeigta ({laiks}). Kļūdas: {kludas}")
            messagebox.showinfo("Atsaukt", f"Atsaukts. Kļūdas: {kludas}\n\nTagad arhīvs tiks noskenēts no jauna.")
            self.skenet()
        self.fona(lambda: A.atsaukt(pedejais, self.log), kad, "Atsaucu…")


def main():
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)   # ass teksts uz Windows
    except Exception:
        pass
    Logs().mainloop()


if __name__ == "__main__":
    main()
