#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Piļu, muižu un vietu arhīva kārtotājs.

Komandas:
  vietvardi  – lejupielādē Latvijas vietvārdu sarakstu (no Wikidata) pārbaudei
  skenet     – analizē arhīvu un izveido grupas.csv (NEKO NEMAINA)
  apvienot   – izpilda (rediģēto) grupas.csv; bez --izpildit tikai parāda plānu
  atsaukt    – atceļ apvienošanu pēc žurnāla faila
  dublikati  – atskaite par failiem ar identisku saturu visā arhīvā (NEKO NEMAINA)

Nekas netiek dzēsts: dublikāti tiek pārvietoti uz mapi _DUBLIKATI arhīva saknē,
katra darbība tiek ierakstīta žurnālā, un to var atsaukt.

Nepieciešams tikai Python 3.8+ (bez papildu bibliotēkām).
"""
import argparse
import csv
import hashlib
import json
import os
import re
import shutil
import sys
import unicodedata
import urllib.parse
import urllib.request
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
except Exception:
    pass

# ---------------------------------------------------------------------------
# Iestatījumi
# ---------------------------------------------------------------------------
IGNORET = {"thumbs.db", "desktop.ini", ".ds_store"}   # sistēmas faili
KARANTINA = "_DUBLIKATI"                              # mape arhīva saknē
CSV_ATDALITAJS = ";"                                  # Excel ar LV reģionālajiem iestatījumiem

LV_DIAKR = set("āčēģīķļņšūžōŗĀČĒĢĪĶĻŅŠŪŽŌŖ")
# Burtu savienojumi, ar kuriem kopijās mēdz aizstāt garumzīmes/mīkstinājumus
DIGRAFI = [("sch", "s"), ("sh", "s"), ("ch", "c"), ("zh", "z"),
           ("kj", "k"), ("gj", "g"), ("lj", "l"), ("nj", "n"), ("rj", "r")]

# Vispārīgie vārdi nosaukumos (pareizajā rakstībā)
VISPARIGIE_VARDI = [
    "muiža", "muižas", "muižiņa", "mācītājmuiža", "pilsmuiža", "pusmuiža", "pusmuižas", "pils", "pilis",
    "pilsdrupas", "drupas", "pilskalns", "baznīca", "baznīcas", "kapela", "kapliča",
    "klosteris", "sinagoga", "parks", "dzirnavas", "vējdzirnavas", "ūdensdzirnavas",
    "krogs", "skola", "kapi", "kapsēta", "ezers", "upe", "kalns", "ciems",
    "pagasts", "novads", "kungu", "māja", "ordeņa", "viduslaiku", "medību",
    "staļļi", "klēts", "magazīna", "pārvaldnieka", "vārti", "tornis", "estrāde",
]

LOGU_AIZLIEGTAS = set('<>:"/\\|?*')


# ---------------------------------------------------------------------------
# Teksta normalizēšana
# ---------------------------------------------------------------------------
def nfc(s):
    return unicodedata.normalize("NFC", s)


def bez_diakritikas(s):
    s = unicodedata.normalize("NFD", s)
    s = "".join(c for c in s if not unicodedata.combining(c))
    return nfc(s)


_ATDAL = re.compile(r"[\s_\-\.,;:()\[\]{}]+")


def sepnorm(s):
    """Vienādo atdalītājus (_ - . utt.) uz atstarpēm."""
    return _ATDAL.sub(" ", nfc(s)).strip()


def tokeni(s):
    return [t for t in _ATDAL.split(nfc(s)) if t]


def atslega(nosaukums):
    """Salīdzināšanas atslēga mapju nosaukumiem: bez garumzīmēm, bez dubultburtiem,
    bez digrafiem, bez lielajiem burtiem, ar vienādotiem atdalītājiem."""
    s = bez_diakritikas(sepnorm(nosaukums).casefold())
    s = re.sub(r"['\"`´’]", "", s)
    for a, b in DIGRAFI:
        s = s.replace(a, b)
    s = re.sub(r"([aeiou])h(?![aeiou])", r"\1", s)   # vecā rakstība: Rahmuli = Rāmuļi, Rahvas = Rāvas
    s = re.sub(r"([^\W\d_])\1+", r"\1", s)   # tikai burti, ne cipari
    return re.sub(r"\s+", " ", s).strip()


def faila_atslega(nosaukums):
    """Failu nosaukumiem – saudzīgāka (cipari un dubultburti saglabājas)."""
    return bez_diakritikas(nfc(nosaukums)).casefold()


VISPARIGIE = {atslega(v): v for v in VISPARIGIE_VARDI}
PUSMUIZA_K = atslega("pusmuiža")
OBJ_SINONIMI = {atslega("muižiņa"): atslega("muiža"), atslega("muižiņas"): atslega("muižas")}

# ---------------------------------------------------------------------------
# Autora saīsinājumi (rediģējami logā) un bieži lietoto vārdu vārdnīca
# ---------------------------------------------------------------------------
SAISINAJUMI_NOKLUSETIE = ("pm=pusmuiža; pusm=pusmuiža; mm=mācītājmuiža; mac muiža=mācītājmuiža; "
                          "mac muižas=mācītājmuižas; pilsdr=pilsdrupas; dzirn=dzirnavas; "
                          "pārvaldn=pārvaldnieka; RIG=Rīga")
_SAIS = {}          # atslēgas frāze (tuple) -> pilnais teksts


def iestatit_saisinajumus(teksts=SAISINAJUMI_NOKLUSETIE):
    """'pm=pusmuiža; RIG=Rīga' → iekšējā tabula. Atgriež kļūdainos ierakstus."""
    _SAIS.clear()
    sliktie = []
    for ier in re.split(r"[;\n]+", teksts or ""):
        if not ier.strip():
            continue
        if "=" not in ier:
            sliktie.append(ier.strip())
            continue
        k, v = ier.split("=", 1)
        kt = tuple(atslega(t) for t in tokeni(k))
        if kt and v.strip():
            _SAIS[kt] = nfc(v.strip())
        else:
            sliktie.append(ier.strip())
    return sliktie


def atsifret(nosaukums):
    """Aizstāj autora saīsinājumus ar pilniem vārdiem (Rendas mac muiža → Rendas mācītājmuiža)."""
    if not _SAIS:
        return nfc(nosaukums)
    dalas = re.split(r"([\s_\-.,;:()\[\]{}]+)", nfc(nosaukums))
    vardi = [i for i in range(0, len(dalas), 2) if dalas[i]]
    gar = max(len(k) for k in _SAIS)
    i = 0
    while i < len(vardi):
        for L in range(min(gar, len(vardi) - i), 0, -1):
            idx = vardi[i:i + L]
            kt = tuple(atslega(dalas[j]) for j in idx)
            if kt in _SAIS:
                v = _SAIS[kt]
                pirm = dalas[idx[0]]
                if not v[:1].isupper() and pirm[:1].isupper():
                    v = v[:1].upper() + v[1:]
                dalas[idx[0]] = v
                for j in idx[1:]:
                    dalas[j] = ""
                    dalas[j - 1] = ""                    # atdalītājs pirms aizvāktā vārda
                i += L
                break
        else:
            i += 1
    return re.sub(r"\s{2,}", " ", "".join(dalas)).strip()


iestatit_saisinajumus()

VARDNICA_NOKLUSETA = """ķesteris ķestera ķesterim māja mājas pārvaldnieks pārvaldnieka dzirnavas dzirnavu
vējdzirnavas ūdensdzirnavas kalpu kalpa kalpi rija rijas klēts kūts kūtis staļļi stallis krogs kroga
krodziņš skola skolas baznīca baznīcas kapliča kapela kapi kapsēta parks parka dārzs dārznieka dārznieks
vārti tornis pils pilis muiža muižas muižiņa pusmuiža mācītājmuiža mācītājmuižas mācītāja mācītājs
kungu kunga laukums aleja ezers ezera upe kalns pilskalns drupas pilsdrupas ēka ēkas apbūve
saimniecības saimniecības ēka pagrabs ledus siltumnīca oranžērija dzīvojamā vecā jaunā lielā mazā
svētā svētās brāļu piemineklis ugunsgrēks ugunsgrēka degšanas pēc smēde smēdes magazīna kalte sēta muižnieka barona fon pārvaldnieku
vagara vagars pasts pasta stacija vīna darītava spirta brūzis alus rūpnīca kungu māja""".split()


def ielasit_vardnicu(cels=None):
    vardi = list(VARDNICA_NOKLUSETA)
    if cels and Path(cels).exists():
        try:
            for rinda in lasit_tekstu(cels).splitlines():
                if rinda.strip().startswith("#"):
                    continue
                vardi += [w for w in re.split(r"[\s,;]+", rinda) if w and "=" not in w and "→" not in w]
        except Exception:
            pass
    d = defaultdict(set)
    for w in vardi:
        d[atslega(w)].add(nfc(w))
    return {k: next(iter(v)) for k, v in d.items() if len(v) == 1 and any(c in LV_DIAKR for c in next(iter(v)))}


_VARDNICA = ielasit_vardnicu()


def iestatit_vardnicu(cels=None):
    global _VARDNICA
    _VARDNICA = ielasit_vardnicu(cels)


def ir_troksna_numurs(t):
    """Numurs bez nozīmes (2, 000, 0012) – bet ne gadskaitlis (1900–2100)."""
    return t.isdigit() and not (len(t) == 4 and 1900 <= int(t) <= 2100)


def bazes_atslega(nosaukums):
    """Atslēga bez vispārīgajiem vārdiem (muiža, pils...) – pašas vietas nosaukums."""
    b = [atslega(t) for t in tokeni(nosaukums)]
    b = [t for t in b if t and t not in VISPARIGIE]
    return " ".join(b)


def bazes_rakstiba(nosaukums):
    return " ".join(t for t in tokeni(nosaukums) if atslega(t) not in VISPARIGIE)


def vertejums(nos):
    """Cik 'pareizi latviski' izskatās nosaukums. Lielāks = labāk."""
    n = nfc(nos)
    z = n.casefold()
    v = 0
    if any(c in LV_DIAKR for c in n):
        v += 10 + 0.1 * sum(c in LV_DIAKR for c in n)
    v -= 5 * len(re.findall(r"(aa|ee|ii|uu)", z))
    v -= 3 * len(re.findall(r"(sh|ch|zh|kj|gj|lj|nj)", z))
    v -= 4 * len(re.findall(r"[aeiou]h(?![aeiou])", z))
    v -= 2 * sum(1 for c in z if c in "äöüß")
    v -= 1 * z.count("ŗ")
    v -= 1 * n.count("_")
    if n[:1].isupper():
        v += 1
    if n.isupper() and len(n) > 3:
        v -= 1
    return v


def salikt(nosaukums, bazes_pareizi=None):
    """Saliek nosaukumu: izlabo vispārīgos vārdus (muiza -> muiža), vietas daļu (ja zināma)
    aizstāj ar pareizo rakstību no vietvārdu saraksta. Punkti, domuzīmes, iekavas un cipari
    paliek kā bija; tikai pasvītras kļūst par atstarpēm."""
    s = re.sub(r"\s+", " ", nfc(nosaukums).replace("_", " ")).strip()
    dalas = re.split(r"([\s\-\.,;:()\[\]{}]+)", s)
    rez, aizstats, izlaist = [], False, False
    for i, d in enumerate(dalas):
        if i % 2 == 1 or not d:            # atdalītājs vai tukšums
            rez.append(d)
            continue
        k = atslega(d)
        if k in VISPARIGIE:
            vards = VISPARIGIE[k]
            if d[:1].isupper():
                vards = vards[:1].upper() + vards[1:]
            rez.append(vards)
            izlaist = False
            continue
        if izlaist:                          # pārējie vārdi jau aizstātajā vietas daļā
            if rez and i > 0:
                rez.pop()                    # noņem atdalītāju pirms izlaistā vārda
            continue
        if bazes_pareizi and not aizstats:
            rez.append(bazes_pareizi)
            aizstats = izlaist = True
        else:
            rez.append(d)
    return "".join(rez).strip()


def forma(n):
    s = sepnorm(n).casefold()
    return re.sub(r"([^\W\d_])\1+", r"\1", s)


def domine(a, b):
    """True, ja forma a satur visas b garumzīmes (b ir 'nepilnīgāka' a rakstība)."""
    if len(a) != len(b) or bez_diakritikas(a) != bez_diakritikas(b):
        return False
    return all(ca == cb or cb == bez_diakritikas(cb) for ca, cb in zip(a, b))


def diakritiku_konflikts(nosaukumi):
    """Vai starp nosaukumiem ir divas atšķirīgas rakstības ar garumzīmēm,
    kur neviena nav otras 'pilnīgākā' versija (piem., Kalņi pret Kālni)."""
    formas = {forma(n) for n in nosaukumi if any(c in LV_DIAKR for c in nfc(n))}
    formas = list(formas)
    for i in range(len(formas)):
        for j in range(i + 1, len(formas)):
            a, b = formas[i], formas[j]
            if not (domine(a, b) or domine(b, a)):
                return True
    return False


def unikali(vardi):
    """Unikālie varianti, neņemot vērā lielos/mazos burtus."""
    d = {}
    for v in sorted(vardi):
        d.setdefault(sepnorm(v).casefold(), sepnorm(v))
    return sorted(d.values())


# ---------------------------------------------------------------------------
# Vietvārdu saraksts
# ---------------------------------------------------------------------------
class Vietvardi:
    def __init__(self, vardi):
        self.pilns = defaultdict(set)
        self.bazes = defaultdict(set)
        self.vardi = defaultdict(set)      # atsevišķu vārdu rakstības: atslēga -> {Rīga, …}
        self.skaits = 0
        for v in vardi:
            v = sepnorm(v)
            if not v:
                continue
            self.skaits += 1
            self.pilns[atslega(v)].add(v)
            for t in tokeni(v):
                if len(t) > 2 and t[:1].isupper():
                    self.vardi[atslega(t)].add(t)
            bk = bazes_atslega(v)
            if bk:
                self.bazes[bk].add(bazes_rakstiba(v))


# Vārdi, kas norāda, ka Wikidata ieraksts nav vieta (iela, iestāde, notikums u.tml.)
NE_VIETAS = """iela ielas šķērsiela bulvāris bulvāra laukums laukuma gatve prospekts šoseja ceļš autoceļš maršruts
tramvajs trolejbuss bibliotēka bibliotēkas skola skolas vidusskola vidusskolas sākumskola pamatskola ģimnāzija
tehnikums koledža universitāte bērnudārzs pirmsskolas aptieka slimnīca poliklīnika pārvalde dome domes vēlēšanas
pašvaldība pašvaldības iestāde sia as ltd banka klubs biedrība fonds festivāls muzejs muzeja hes lidlauks lidosta
pienotava kauja gads gadā partija žurnāls avīze laikraksts grupa albums dziesma filma teātris uzņēmums rūpnīca
fabrika veikals viesnīca kafejnīca restorāns stacija pietura dzelzceļa līnija komanda fk ks bk hk sporta stadions
halle centrs centra nodaļa apvienība kultūras pieminekļi pieminekļu saraksts saraksta latvijā vēsture draudze
mežniecība iegula atradne ģeoloģiskais liegums lieguma takas taka elektrostacija apakšstacija katlumāja ostas osta
tilts tunelis arhīvs ēka altāris pulks līdzenums baltic plāksne""".split()


def ir_vietvards(v):
    """Vai Wikidata nosaukums izskatās pēc vietas (nevis ielas, iestādes, notikuma)."""
    v = v.strip()
    if not v or not v[0].isupper() or re.search(r"\d", v):
        return False
    if any(c in v for c in '("«„/'):
        return False
    t = tokeni(v)
    if len(t) > 5 or any(len(x) >= 2 and x.isupper() for x in t):
        return False
    return not any(atslega(x) in _NE_VIETAS for x in t)


_NE_VIETAS = {atslega(w) for w in NE_VIETAS}


def lasit_sarakstus(celi):
    vardi = set()
    for c in celi:
        p = Path(c)
        if not p.exists():
            print(f"  Brīdinājums: saraksts {p} nav atrasts")
            continue
        teksts = lasit_tekstu(p)
        if p.suffix.lower() in (".csv", ".tsv"):
            try:
                dial = csv.Sniffer().sniff(teksts[:5000], delimiters=",;\t")
            except csv.Error:
                dial = csv.excel
            rindas = list(csv.reader(teksts.splitlines(), dial))
            if not rindas:
                continue
            galva = [h.casefold() for h in rindas[0]]
            kol = next((i for i, h in enumerate(galva)
                        if any(k in h for k in ("nosauk", "vietvārd", "vietvard", "name", "label"))), None)
            sak = 1 if kol is not None else 0
            kol = kol or 0
            for r in rindas[sak:]:
                if len(r) > kol and r[kol].strip():
                    vardi.add(nfc(r[kol].strip()))
        else:
            for l in teksts.splitlines():
                if l.strip():
                    vardi.add(nfc(l.strip()))
    return vardi


def lasit_tekstu(p):
    dati = Path(p).read_bytes()
    try:
        return dati.decode("utf-8-sig")
    except UnicodeDecodeError:
        return dati.decode("cp1257", errors="replace")   # Excel "ANSI" Latvijā


def cmd_vietvardi(arg):
    lejupieladet_vietvardus(arg.izeja)


def lejupieladet_vietvardus(izeja, log=print):
    """Lejupielādē no Wikidata. Atgriež saglabāto nosaukumu skaitu (0, ja neizdevās)."""
    vaicajumi = [
        'SELECT DISTINCT ?l WHERE { ?i wdt:P17 wd:Q211 ; rdfs:label ?l . FILTER(LANG(?l)="lv") }',
        'SELECT DISTINCT ?l WHERE { ?i wdt:P17 wd:Q211 ; skos:altLabel ?l . FILTER(LANG(?l)="lv") }',
    ]
    vardi = set()
    for q in vaicajumi:
        url = "https://query.wikidata.org/sparql?" + urllib.parse.urlencode({"query": q, "format": "json"})
        req = urllib.request.Request(url, headers={
            "User-Agent": "arhiva-kartotajs/1.0 (personigs arhiva kartosanas riks)",
            "Accept": "application/sparql-results+json"})
        log("Lejupielādēju vietvārdus no Wikidata (var aizņemt dažas minūtes)...")
        try:
            with urllib.request.urlopen(req, timeout=600) as r:
                dati = json.load(r)
            for b in dati["results"]["bindings"]:
                vardi.add(nfc(b["l"]["value"]))
            log(f"  kopā līdz šim: {len(vardi)}")
        except Exception as e:
            log(f"  Neizdevās: {e}")
    if not vardi:
        log("Neko neizdevās lejupielādēt. Saraksts nav izveidots.")
        return 0
    visi = len(vardi)
    try:
        pilns = Path(izeja).with_name(Path(izeja).stem + "_pilns.txt")
        pilns.write_text("\n".join(sorted(vardi)) + "\n", encoding="utf-8")
        log(f"  pilnais saraksts (objektu ieteikumiem) saglabāts: {pilns.name}")
    except Exception as e:
        log(f"  pilno sarakstu neizdevās saglabāt: {e}")
    vardi = {v for v in vardi if ir_vietvards(v)}
    log(f"  atfiltrēti ne-vietvārdi (ielas, iestādes, notikumi): paliek {len(vardi)} no {visi}")
    Path(izeja).write_text("\n".join(sorted(vardi)) + "\n", encoding="utf-8")
    log(f"Saglabāti {len(vardi)} nosaukumi failā {izeja}")
    return len(vardi)


# ---------------------------------------------------------------------------
# Arhīva skenēšana
# ---------------------------------------------------------------------------
def sistemas(nos):
    return nos.startswith("_") or nos.startswith(".")


class Mape:
    def __init__(self, cels, sakne, burts):
        self.cels = cels
        self.rel = cels.relative_to(sakne).as_posix()
        self.burts = burts
        self.nos = nfc(cels.name)
        self.failu_skaits = 0
        self.izmers = 0
        self.vecakais = None
        self.jaunakais = None
        self.inventars = set()
        self.faili = []          # (relatīvais ceļš mapē, izmērs, mtime)
        self.tuksi = 0           # 0 baitu faili (tiks izmesti)
        self.lieki = []          # pagaidu/sistēmas un tukšie faili: (rel mapē, "pagaidu"/"tukss")
        for dirpath, dirnames, filenames in os.walk(cels):
            dirnames[:] = [d for d in dirnames if not sistemas(d)]
            for f in filenames:
                pilns = os.path.join(dirpath, f)
                if ir_lieks(f):
                    self.lieki.append((Path(pilns).relative_to(cels).as_posix(), "pagaidu"))
                    continue
                try:
                    st = os.stat(pilns)
                except OSError:
                    continue
                if st.st_size == 0:
                    self.tuksi += 1
                    self.lieki.append((Path(pilns).relative_to(cels).as_posix(), "tukss"))
                    continue
                self.faili.append((Path(pilns).relative_to(cels).as_posix(), st.st_size, st.st_mtime))
                self.failu_skaits += 1
                self.izmers += st.st_size
                m = st.st_mtime
                self.vecakais = m if self.vecakais is None else min(self.vecakais, m)
                self.jaunakais = m if self.jaunakais is None else max(self.jaunakais, m)
                self.inventars.add((faila_atslega(f), st.st_size))


def mape_uz_dict(m):
    return {"rel": m.rel, "burts": m.burts, "nos": m.nos, "failu_skaits": m.failu_skaits, "izmers": m.izmers,
            "vecakais": m.vecakais, "jaunakais": m.jaunakais, "tuksi": getattr(m, "tuksi", 0), "faili": m.faili,
            "lieki": getattr(m, "lieki", [])}


def mape_no_dict(d, sakne):
    m = Mape.__new__(Mape)
    m.rel, m.burts, m.nos = d["rel"], d["burts"], d["nos"]
    m.cels = Path(sakne) / d["rel"]
    m.failu_skaits, m.izmers = d["failu_skaits"], d["izmers"]
    m.vecakais, m.jaunakais, m.tuksi = d["vecakais"], d["jaunakais"], d.get("tuksi", 0)
    m.faili = [tuple(x) for x in d["faili"]]
    m.lieki = [tuple(x) for x in d.get("lieki", [])]
    m.inventars = {(faila_atslega(rel.rsplit("/", 1)[-1]), izm) for rel, izm, _ in m.faili}
    return m


def atrast_mapes(sakne, bez_burtiem, progress=None):
    mapes, vaļīgi = [], []
    if bez_burtiem:
        for p in sorted(sakne.iterdir()):
            if p.is_dir() and not sistemas(p.name):
                if progress:
                    progress(p.name)
                mapes.append(Mape(p, sakne, ""))
        return mapes, vaļīgi
    for burts in sorted(sakne.iterdir()):
        if not burts.is_dir() or sistemas(burts.name):
            continue
        for p in sorted(burts.iterdir()):
            if sistemas(p.name):
                continue
            if p.is_dir():
                if progress:
                    progress(f"{burts.name} / {p.name}")
                mapes.append(Mape(p, sakne, nfc(burts.name)))
            elif not ir_lieks(p.name):
                vaļīgi.append(p.relative_to(sakne).as_posix())
    return mapes, vaļīgi


def burtu_mapes(sakne):
    return {nfc(p.name): p for p in sakne.iterdir() if p.is_dir() and not sistemas(p.name)}


def merka_burts(nosaukums, esosais, burti):
    """Burta mape mērķa nosaukumam: ja eksistē mape tieši ar pirmo burtu (piem., Č), to;
    citādi paliek esošajā."""
    if not burti or not nosaukums:
        return esosais
    pirmais = nfc(nosaukums[0]).upper()
    if pirmais in burti:
        return pirmais
    return esosais


def fmt_laiks(t):
    return datetime.fromtimestamp(t).strftime("%Y-%m-%d") if t else ""


# ---------------------------------------------------------------------------
# Mapes nosaukuma sadalīšana: vieta + objekts + datums + citas piebildes
# ---------------------------------------------------------------------------
# Autora piebildes bez nozīmes (var mainīt logā vai ar --troksnis)
TROKSNIS_NOKLUSETAIS = "x m svm copy kopija kopēts rezerve rez backup jauns"

_DATUMI = [
    (re.compile(r"(?<!\d)(\d{1,2})[.\-_/ ](\d{1,2})[.\-_/ ](\d{4})(?!\d)"), "dmy"),
    (re.compile(r"(?<!\d)(\d{4})[.\-_/ ](\d{1,2})[.\-_/ ](\d{1,2})(?!\d)"), "ymd"),
    (re.compile(r"(?<!\d)(\d{4})(\d{2})(\d{2})(?!\d)"), "ymd"),
    (re.compile(r"(?<!\d)(\d{2})(\d{2})(\d{4})(?!\d)"), "dmy"),
]


def atrast_datumu(s):
    """Atrod datumu nosaukumā. Atgriež (sākums, beigas, 'dd.mm.gggg') vai None."""
    for rx, kartiba in _DATUMI:
        for m in rx.finditer(s):
            a, b, c = (int(x) for x in m.groups())
            d, mn, g = (a, b, c) if kartiba == "dmy" else (c, b, a)
            if 1 <= d <= 31 and 1 <= mn <= 12 and 1900 <= g <= 2100:
                return m.start(), m.end(), f"{d:02d}.{mn:02d}.{g}"
    return None


def troksna_atslegas(troksnis):
    if isinstance(troksnis, str):
        troksnis = troksnis.replace(",", " ").split()
    return {atslega(t) for t in troksnis if t.strip()}


class Nosaukums:
    """Mapes nosaukums, sadalīts daļās."""
    def __init__(self, nos, troksna_k):
        self.orig = nfc(nos)
        s = atsifret(self.orig)
        self.datums = None
        d = atrast_datumu(s)
        if d:
            self.datums = d[2]
            s = s[:d[0]] + " " + s[d[1]:]
        else:
            g = re.search(r"(?<![\d.])(19\d\d|20\d\d)(?![\d.])", s)     # tikai gadskaitlis
            if g and re.fullmatch(r"\d{4}", g.group(0)):
                self.datums = g.group(0)
                s = s[:g.start()] + " " + s[g.end():]
        s = re.sub(r"\(\s*\d{1,3}\s*\)", " ", s)          # (2)
        self.tokeni = []                                  # [(teksts, veids)] veids: v/o/c
        self.troksnis = []
        for t in tokeni(s):
            k = atslega(t)
            if k in troksna_k or ir_troksna_numurs(t):
                self.troksnis.append(t)
                continue
            self.tokeni.append([t, "o" if k in VISPARIGIE else "?"])
        self.vieta = []      # vietas vārdi (kā rakstīts)
        self.objekti = []    # muiža, baznīca …
        self.citi = []       # citas piebildes (drons, km …)
        self.vietas_k = ""   # vietas atslēga nominatīvā (pēc vietas noteikšanas)

    def sakuma_vardi(self):
        """Vārdi līdz pirmajam objektam."""
        rez = []
        for t, v in self.tokeni:
            if v == "o":
                break
            rez.append(t)
        return rez


def _varianti(tok_k):
    """Iespējamās nominatīva formas vienam vārdam (Remtes → Remte, Kalna → Kalns, Rāmuļu → Rāmuļi)."""
    v = {tok_k}
    if len(tok_k) > 3:
        if tok_k.endswith("s"):
            v.add(tok_k[:-1])
        if tok_k.endswith("a"):
            v.add(tok_k[:-1] + "s")
            v.add(tok_k[:-1] + "is")
        if tok_k.endswith("u"):
            v.add(tok_k[:-1] + "i")
            v.add(tok_k[:-1] + "a")
            v.add(tok_k[:-1] + "e")
    return v


def frazes_varianti(vardi):
    """Visas nominatīva variantu kombinācijas frāzei (līdz 3 vārdiem)."""
    kom = [""]
    for t in vardi[:3]:
        kom = [(a + " " + b).strip() for a in kom for b in _varianti(atslega(t))]
    if len(vardi) > 3:
        kom = [k + " " + " ".join(atslega(t) for t in vardi[3:]) for k in kom]
    return kom


def noteikt_vietas(nosaukumi, vv):
    """Katram Nosaukums nosaka vietas vārdus, objektus un citas piebildes.
    Vietu atpazīst pēc vietvārdu saraksta un pēc citām arhīva mapēm.
    Locījumu (Remtes → Remte) min TIKAI tad, ja aiz vietas seko objekts (muiža, baznīca, pm…),
    un tikai tad, ja precīzā forma nav zināma vieta. Ja der vairākas vietas – n.neskaidrs."""
    zinamas_vv = set()
    if vv is not None:
        for k, vardi in vv.pilns.items():
            if not any(atslega(t) in VISPARIGIE for v in vardi for t in tokeni(v)):
                zinamas_vv.add(k)
    zinamas_mapes = set()
    for n in nosaukumi:
        sv = n.sakuma_vardi()
        if sv and not any(v == "o" for _, v in n.tokeni):
            zinamas_mapes.add(" ".join(atslega(t) for t in sv))
    zinamas = zinamas_vv | zinamas_mapes

    for n in nosaukumi:
        sv = n.sakuma_vardi()
        ir_objekts = any(v == "o" for _, v in n.tokeni)
        n.neskaidrs = []
        garums, atsl = None, None

        def atrast(vardi, kopa):
            preciza = " ".join(atslega(t) for t in vardi)
            if not ir_objekts:
                return [preciza] if preciza in kopa else []
            # aiz vietas seko objekts → vieta parasti ir ģenitīvā (Remtes, Rauņa, Rāmuļu)
            kand = sorted({k for k in frazes_varianti(vardi) if k in kopa})
            if len(kand) > 1:
                # ja kāds kandidāts ir visu pārējo locījuma forma, tā ir pamatforma (Raunas → Rauna)
                pamat = [c for c in kand if all(c in frazes_varianti(o.split()) for o in kand if o != c)]
                if len(pamat) == 1:
                    kand = pamat
            return kand

        # 1) garākais sākums, kas ir vietvārdu sarakstā; 2) īsākais, kas sakrīt ar citu mapi
        for L in list(range(len(sv), 0, -1)):
            tr = atrast(sv[:L], zinamas_vv)
            if tr:
                garums, atsl = L, tr
                break
        if garums is None:
            for L in range(1, len(sv) + 1):
                tr = atrast(sv[:L], zinamas_mapes)
                if tr:
                    garums, atsl = L, tr
                    break
        if garums is None:
            garums, atsl = len(sv), [" ".join(atslega(t) for t in sv)]
        if len(atsl) > 1:
            n.neskaidrs = atsl
            atsl = [" ".join(atslega(t) for t in sv[:garums])]   # nesapludinām ne ar vienu
        n.vieta = sv[:garums]
        n.vietas_k = atsl[0]
        # Objekts = vārdi no vietas līdz PIRMAJAM objekta vārdam (Rīga | Berģu muiža).
        # Pārējie vārdi: ja tajos ir cita vieta vai objekts (Bērzu muiža | Tukums) – tie ir daļa
        # no nosaukuma (citādi vienādi nosauktas muižas sajuktu); citādi – piebilde (apakšmapei).
        rest = [t for t, v in n.tokeni[garums:]]
        tipi = [v for t, v in n.tokeni[garums:]]
        j = tipi.index("o") if "o" in tipi else -1
        objekts = rest[:j + 1] if j >= 0 else []
        aiz = rest[j + 1:] if j >= 0 else rest

        def zinama(t):
            k = atslega(t)
            return k in zinamas or k in VISPARIGIE or any(x in zinamas for x in _varianti(k))
        n.obj_pamats = objekts
        if aiz and any(zinama(t) for t in aiz):
            n.objekti, n.citi, n.obj_vieta = objekts + aiz, [], aiz
        else:
            n.objekti, n.citi, n.obj_vieta = objekts, aiz, []
    return zinamas


def tirit_nosaukumu(orig, troksna_k):
    """1. etapam: noņem nenozīmīgās piebildes un numurus, datumu pārraksta dd.mm.gggg,
    vārdu secību nemaina (Remte SVM - Copy → Remte; Remte x 2019-03-14 → Remte 14.03.2019)."""
    s = atsifret(orig)
    d = atrast_datumu(s)
    viet = "\x00"
    if d:
        s = s[:d[0]] + viet + s[d[1]:]
    s = re.sub(r"\(\s*\d{1,3}\s*\)", " ", s)
    dalas = re.split(r"(\s+|_)", s)
    tiras = []
    for t in dalas:
        if t is None:
            continue
        if t == "_":
            tiras.append(" ")
            continue
        if t.strip() and viet not in t and (atslega(t) in troksna_k or ir_troksna_numurs(t)):
            continue
        tiras.append(t)
    s = re.sub(r"\s+", " ", "".join(tiras)).strip()
    s = re.sub(r"(\s+-)+(?=\s+-|\s*$)", "", s)
    s = re.sub(r"^(-\s*)+", "", s).strip(" -")
    if d:
        s = s.replace(viet, d[2])
    return re.sub(r"\s+", " ", s).strip()


def kopigais_saturs(a_mapes, b_mapes):
    ia = set().union(*(m.inventars for m in a_mapes)) if a_mapes else set()
    ib = set().union(*(m.inventars for m in b_mapes)) if b_mapes else set()
    return len(ia & ib), len(ia)


def _lev(a, b, robeza=2):
    """Levenšteina attālums (ar agru pārtraukšanu)."""
    if abs(len(a) - len(b)) > robeza:
        return robeza + 1
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        if min(cur) > robeza:
            return robeza + 1
        prev = cur
    return prev[-1]


def lidzigi_nosaukumi(grupas, zinamas, etaps):
    """Atrod grupu pārus ar līdzīgiem nosaukumiem un pievieno mazāko lielākajai PĒC SATURA:
      – drukas kļūda: viens vārds atšķiras ar 1–2 burtiem (Remts ↔ Remtes), vārds garāks par 4 burtiem,
        un tie nav divi dažādi zināmi vietvārdi (Rauna ↔ Rauda);
      – (1. etapā) nosaukums = cits nosaukums + nezināmi papildu vārdi (Rauna jaunās ↔ Rauna)."""
    def kanon(t):
        return atslega(VISPARIGIE.get(atslega(t), t))
    wk = {}
    for key, gm in grupas.items():
        if key[0].startswith("#"):
            continue
        wk[key] = {tuple(kanon(t) for t, _ in m.n.tokeni) + ((m.n.datums,) if m.n.datums else ())
                   for m in gm if m.n.tokeni}

    def faili(k):
        return sum(m.failu_skaits for m in grupas[k])
    pari = []
    # drukas kļūdas: maskējam vienu pozīciju
    maska = defaultdict(list)
    for key, kopa in wk.items():
        for w in kopa:
            for i, t in enumerate(w):
                if len(t) > 4 and not t.isdigit():
                    maska[(len(w), i, w[:i] + w[i + 1:])].append((key, t))
    for (_, i, _), saraksts in maska.items():
        if len(saraksts) < 2:
            continue
        for x in range(len(saraksts)):
            for y in range(x + 1, len(saraksts)):
                (k1, t1), (k2, t2) = saraksts[x], saraksts[y]
                if k1 == k2 or t1 == t2:
                    continue
                if t1 in zinamas and t2 in zinamas:
                    continue                                   # divas dažādas zināmas vietas
                if _lev(t1, t2) <= 2:
                    # pareizā rakstība = tā, kas zināma (vietvārdu sarakstā / citās mapēs)
                    z1 = t1 in zinamas or bool(_varianti(t1) & zinamas)
                    z2 = t2 in zinamas or bool(_varianti(t2) & zinamas)
                    merkis = k1 if z1 and not z2 else (k2 if z2 and not z1 else None)
                    pari.append((k1, k2, "iespējama drukas kļūda", merkis))
    # papildu nezināmi vārdi (tikai 1. etapā – 2. etapā tie jau kļūst par apakšmapēm)
    if etaps == 1:
        indekss = defaultdict(set)
        for key, kopa in wk.items():
            for w in kopa:
                indekss[w].add(key)
        for key, kopa in wk.items():
            for w in kopa:
                for p in range(1, len(w)):
                    papild = w[p:]
                    if any(t in zinamas or t in VISPARIGIE or t.isdigit() for t in papild):
                        continue
                    for k2 in indekss.get(w[:p], ()):
                        if k2 != key:
                            pari.append((key, k2, "līdzīgs nosaukums", k2))
    # muiža ↔ muižiņa (Rīga Popova muiža ↔ Rīga Popova muižiņa PMA): bieži viens un tas pats objekts
    pamatforma = defaultdict(set)
    for key, gm in grupas.items():
        if key[0].startswith("#"):
            continue
        for m in gm:
            fr = [atslega(t) for t in m.n.vieta + m.n.objekti]
            if fr:
                pamatforma[tuple(OBJ_SINONIMI.get(t, t) for t in fr)].add(key)
    for fr, keys in pamatforma.items():
        if len(keys) < 2:
            continue
        if not any(t in OBJ_SINONIMI.values() for t in fr):
            continue
        ar_sin = [k for k in keys if any(t in OBJ_SINONIMI for t in (k[0] + " " + k[1]).split())]
        pamata = [k for k in keys if k not in ar_sin]
        if not ar_sin:
            continue
        for k in ar_sin:
            for k2 in (pamata or [kk for kk in ar_sin if kk != k][:1]):
                if k != k2:
                    pari.append((k, k2, "muiža / muižiņa", k2))
    apstradats = set()
    for k1, k2, iemesls, merkis in sorted(pari, key=lambda x: (x[2], x[0], x[1])):
        if k1 not in grupas or k2 not in grupas or k1 in apstradats or k2 in apstradats:
            continue
        if merkis is not None:
            liels = merkis
            mazs = k2 if merkis == k1 else k1
        else:
            mazs, liels = (k1, k2) if faili(k1) <= faili(k2) else (k2, k1)
        if pievienot_pec_satura(grupas, mazs, [liels], iemesls, bez_kopigiem=(iemesls == "muiža / muižiņa")):
            apstradats.update({k1, k2})


def vienads_saturs(grupas):
    """Mapes ar gandrīz vienādu saturu (≥80% kopīgu failu), kuru nosaukumi atšķiras tikai ar piebildēm:
    `Rīga kopsavilkums jkl` ↔ `Rīga kopsavilkums nhg`. Jābūt tai pašai vietai (pirmajam vārdam)."""
    inv = {}
    for key, gm in grupas.items():
        if key[0].startswith("#"):
            continue
        # lieliem failiem pietiek ar vienādu izmēru baitos (arī ja fails pārdēvēts)
        s_ = {("", izm) if izm >= 50_000 else (nos, izm) for m in gm for nos, izm in m.inventars}
        if s_:
            inv[key] = s_
    idx = defaultdict(set)
    for key, s_ in inv.items():
        for f in s_:
            idx[f].add(key)
    pari = {}
    for key, s_ in inv.items():
        skaits = Counter()
        for f in s_:
            if len(idx[f]) <= 30:                 # ļoti izplatīti faili (logo u.tml.) neko nenozīmē
                for k2 in idx[f]:
                    if k2 != key:
                        skaits[k2] += 1
        for k2, kop in skaits.items():
            jac = kop / len(s_ | inv[k2])
            if jac >= 0.8:
                pari[tuple(sorted((key, k2)))] = (jac, kop)

    def pirmais(key):
        return key[0].split()[0] if key[0] else ""

    def obj(key):
        return {t for t in (key[0] + " " + key[1]).split() if t in VISPARIGIE}
    apstradats = set()
    for (k1, k2), (jac, kop) in sorted(pari.items(), key=lambda x: -x[1][0]):
        if k1 in apstradats or k2 in apstradats or k1 not in grupas or k2 not in grupas:
            continue
        if not (_varianti(pirmais(k1)) & _varianti(pirmais(k2))):
            continue                                  # dažādas vietas – neapvienojam
        f1 = sum(m.failu_skaits for m in grupas[k1])
        f2 = sum(m.failu_skaits for m in grupas[k2])
        mazs, liels = (k1, k2) if f1 < f2 or (f1 == f2 and k1 > k2) else (k2, k1)
        cits_obj = obj(k1) != obj(k2)
        m0 = max(grupas[liels], key=lambda x: vertejums(x.nos))
        merka_nos = salikt(" ".join(m0.n.vieta + m0.n.objekti)) or m0.nos
        drosi = kop >= 3 and not cits_obj
        for m in grupas[mazs]:
            m.pm_darb = "APVIENOT" if drosi else "PĀRBAUDĪT"
            m.pm_piez = (f"vienāds saturs: {kop} faili sakrīt ar “{m0.nos}” ({round(100 * jac)}% no abu mapju "
                         f"failiem)" + (" – apvienota" if drosi else " – pārbaudi, vai tā ir tā pati vieta"))
        grupas[liels].extend(grupas[mazs])
        del grupas[mazs]
        apstradats.update({k1, k2})


def pievienot_pec_satura(grupas, key, kandidati, ko_pievieno, bez_kopigiem=False):
    """Pievieno grupu `key` tai kandidātgrupai, ar kuru tai ir visvairāk kopīgu failu.
    ≥30% → APVIENOT, mazāk → PĀRBAUDĪT, nemaz → nepievieno (ja bez_kopigiem – PĀRBAUDĪT).
    Atgriež True, ja pievienoja."""
    gm = grupas[key]
    labaka, lab_kop, visi = None, 0, 0
    for k2 in kandidati:
        kop, visi = kopigais_saturs(gm, grupas[k2])
        if kop > lab_kop:
            labaka, lab_kop = k2, kop
    if labaka is None and bez_kopigiem and kandidati:
        labaka = kandidati[0]
        visi = visi or 1
    if labaka is None or not visi:
        return False
    dala = lab_kop / visi
    m0 = max(grupas[labaka], key=lambda x: vertejums(x.nos))
    merka_nos = salikt(" ".join(m0.n.vieta + m0.n.objekti)) or labaka[0]
    for m in gm:
        m.pm_darb = "APVIENOT" if dala >= 0.3 else "PĀRBAUDĪT"
        m.pm_piez = (f"{ko_pievieno}: {lab_kop} no {visi} failiem ({round(100 * dala)}%) sakrīt ar "
                     f"“{merka_nos}”" + (" – apvienota" if m.pm_darb == "APVIENOT" else
                                        " – pārbaudi, vai tā ir tā pati vieta"))
    grupas[labaka].extend(gm)
    del grupas[key]
    return True


def labot_vardus(nosaukums, vv):
    """Izlabo atsevišķu vārdu rakstību pēc vietvārdu saraksta (Riga → Rīga, Rahmuli → Rāmuļi).
    Vārdu maina tikai tad, ja sarakstā NAV tieši tādas rakstības un ir tieši viena pareizā."""
    dalas = re.split(r"(\s+)", nosaukums)
    for i, t in enumerate(dalas):
        if not t.strip() or len(t) < 3 or atslega(t) in VISPARIGIE or re.search(r"\d", t):
            continue
        # vispirms – vietas nosaukums pats par sevi (Rīga), tikai tad – vārdi no citiem ierakstiem
        vietas = {f for f in vv.pilns.get(atslega(t), ()) if " " not in f} if vv is not None else set()
        formas = vietas if vietas else (vv.vardi.get(atslega(t)) if vv is not None else None)
        if not formas and atslega(t) in _VARDNICA:
            formas = {_VARDNICA[atslega(t)]}
        if not formas or any(f.casefold() == t.casefold() for f in formas):
            continue
        der = {f.casefold(): f for f in formas
               if any(c in LV_DIAKR for c in f) and (
                   not any(c in LV_DIAKR for c in t) or domine(forma(f), forma(t)))}
        if len(der) == 1:
            jauns = next(iter(der.values()))
            dalas[i] = (jauns[:1].upper() if t[:1].isupper() else jauns[:1].lower()) + jauns[1:]
    return "".join(dalas)


def ierosinat_nosaukumu(kandidati, vv):
    """kandidati – [(nosaukums, svars)]. Izvēlas pareizāko rakstību, pārbauda vietvārdu sarakstā.
    Atgriež (nosaukums, statuss, neskaidrs, apstiprināts)."""
    labakais = max(kandidati, key=lambda x: (vertejums(x[0]), x[1]))[0]
    key = atslega(labakais)
    statuss, merkis, neskaidrs, apstiprinats = "", None, False, False

    def nezaude_garumzimes(no_saraksta, musu):
        """Saraksta rakstība drīkst tikai PIEVIENOT garumzīmes, nevis tās mainīt/noņemt."""
        a, b = forma(no_saraksta), forma(musu)
        return a == b or domine(a, b) or not any(c in LV_DIAKR for c in nfc(musu))

    if vv is not None:
        cands = [c for c in unikali(vv.pilns.get(key, ())) if nezaude_garumzimes(c, labakais)]
        if len(cands) == 1:
            merkis, apstiprinats = cands[0], True
            statuss = "atrasts vietvārdu sarakstā"
        elif len(cands) > 1:
            neskaidrs = True
            atbilst = [k for k, _ in kandidati if sepnorm(k).casefold() in {c.casefold() for c in cands}]
            merkis = max(atbilst, key=vertejums) if atbilst else labakais
            statuss = "sarakstā vairākas vietas: " + " | ".join(cands)
        else:
            bk = bazes_atslega(labakais)
            bc = [c for c in (unikali(vv.bazes.get(bk, ())) if bk else [])
                  if nezaude_garumzimes(c, bazes_rakstiba(labakais))]
            if len(bc) == 1:
                merkis, apstiprinats = salikt(labakais, bc[0]), True
                statuss = f"vieta '{bc[0]}' atrasta vietvārdu sarakstā"
            elif len(bc) > 1:
                neskaidrs = True
                statuss = "sarakstā vairākas vietas: " + " | ".join(bc)
            else:
                statuss = "nav atrasts vietvārdu sarakstā"
    else:
        statuss = "vietvārdu saraksts nav norādīts"
    if merkis is None:
        merkis = salikt(labakais)
    merkis = labot_vardus(merkis, vv)
    return merkis, statuss, neskaidrs, apstiprinats


LAUKI = ["grupa", "darbība", "mērķa_nosaukums", "vecāka_mape", "mape", "apakšmape", "failu_skaits", "izmērs_MB",
         "kopīgi_ar_mērķi_%", "vecākais_fails", "jaunākais_fails", "vietvārdu_pārbaude"]


class ObjektuIndekss:
    """Wikidata objektu nosaukumi (Rīgas Svētā Mārtiņa evaņģēliski luteriskā baznīca …)
    meklēšanai pēc vietas un nosaukuma fragmentiem (RIG Mārtiņa, RIG Vecā Gertr)."""
    def __init__(self, nosaukumi):
        self.pec_vietas = defaultdict(list)
        self.skaits = 0
        for n in nosaukumi:
            n = sepnorm(n) if False else nfc(n.strip())
            t = tokeni(n)
            if len(t) < 2 or not any(atslega(x) in VISPARIGIE for x in t):
                continue
            if re.search(r"\b(iela|ielas|vēlēšanas|bibliotēka|gads)\b", n, re.I):
                continue
            self.skaits += 1
            for k in _varianti(atslega(t[0])):
                self.pec_vietas[k].append((n, [atslega(x) for x in t[1:]]))

    def meklet(self, vietas_atsl, fragmenti, max_sk=8):
        """vietas_atsl – 'riga'; fragmenti – ['marti'], ['veca', 'gertr'] → piemērotie nosaukumi."""
        frag = [atslega(f) for f in fragmenti if len(atslega(f)) >= 3 and atslega(f) not in VISPARIGIE]
        obj = [atslega(f) for f in fragmenti if atslega(f) in VISPARIGIE]
        if not frag:
            return []
        rez = []
        for nos, vardi in self.pec_vietas.get(vietas_atsl, []):
            if all(any(v.startswith(f) for v in vardi) for f in frag) and \
                    all(any(v.startswith(o[:5]) for v in vardi) for o in obj):
                rez.append(nos)
        neskaitit = {"sveta", "svetas", "sv", "un"} | set(frag)

        def lieki(n):
            # nesaskaņotie īpašvārdi (Pētera … Pāvila → “Pētera” lieks, ja meklēja tikai “Pāvila”)
            return sum(1 for x in tokeni(n)[1:] if x[:1].isupper() and atslega(x) not in VISPARIGIE
                       and atslega(x) not in neskaitit and not any(atslega(x).startswith(f) for f in frag))
        rez = sorted(set(rez), key=lambda x: (lieki(x), len(x), x))
        return rez[:max_sk]


def ielasit_objektus(saraksta_cels, log=print):
    """Ielādē pilno sarakstu (vietvardi_pilns.txt) blakus vietvārdu sarakstam."""
    if not saraksta_cels:
        return None
    p = Path(saraksta_cels)
    kandidati = [p.with_name(p.stem + "_pilns.txt"), p.with_name("vietvardi_pilns.txt"),
                 Path(__file__).resolve().parent / "vietvardi_pilns.txt"]
    pilns = next((c for c in kandidati if c.exists()), None)
    if pilns is None:
        log("Objektu ieteikumiem nav atrasts vietvardi_pilns.txt (meklēju: " +
            "; ".join(str(c) for c in kandidati) + "). Spied “Lejupielādēt no interneta”.")
        return None
    try:
        idx = ObjektuIndekss(l for l in lasit_tekstu(pilns).splitlines() if l.strip())
        log(f"Objektu sarakstā (ieteikumiem): {idx.skaits} nosaukumi – {pilns}")
        return idx
    except Exception as e:
        log(f"Objektu sarakstu neizdevās ielādēt: {e}")
        return None


def _mapes_faili(mapes_celi, robeza=600):
    for c in mapes_celi:
        try:
            for i, f in enumerate(Path(c).rglob("*")):
                if i > robeza:
                    break
                yield f
        except Exception:
            pass


def objekts_no_failiem(mapes_nosaukums, mapes_celi):
    """Mape 'Rīga Pētera', faili 'Rīga Pētera baznīca (2).jpg' → ('Rīga Pētera baznīca', skaits, kopā).
    Ieteikums tikai, ja mapes nosaukumā vēl nav objekta vārda."""
    mt = [x for x in tokeni(atsifret(mapes_nosaukums)) if not x.isdigit()]
    mk = [atslega(x) for x in mt]
    if len(mk) < 2 or any(k in VISPARIGIE for k in mk):   # tikai vieta (Rauna) – objektu nepiedāvā
        return None
    skaits, kopa, rakstiba = Counter(), 0, {}
    for f in _mapes_faili(mapes_celi):
        if not f.is_file():
            continue
        kopa += 1
        ft = tokeni(atsifret(f.stem))
        fk = [atslega(x) for x in ft]
        # faila nosaukuma sākumā jābūt mapes vārdiem (vietai drīkst būt cits locījums)
        if len(fk) <= len(mk) or fk[1:len(mk)] != mk[1:] or not (_varianti(mk[0]) & _varianti(fk[0])):
            continue
        for j in range(len(mk), min(len(fk), len(mk) + 3)):
            if fk[j] in VISPARIGIE:
                fr = mt + ft[len(mk):j + 1]
                k = " ".join(atslega(x) for x in fr)
                skaits[k] += 1
                rakstiba.setdefault(k, Counter())[" ".join(fr)] += 1
                break
    if not skaits:
        return None
    k, n = skaits.most_common(1)[0]
    if n < 2 and n < kopa:
        return None
    # rakstība ar visvairāk garumzīmēm
    nos = max(rakstiba[k], key=lambda r: (sum(ord(c) > 127 for c in r), rakstiba[k][r]))
    nos = labot_vardus(salikt(nos), _VV_AKT)
    return nos, n, kopa


def objektu_ieteikumi(mapes_nosaukums, idx, mapes_cels=None):
    """'RIG Mārtiņa' → [(pilnais nosaukums, pamatojums)]; meklē pēc vietas + pārējiem vārdiem.
    mapes_cels var būt viens ceļš vai saraksts (visas grupas mapes)."""
    celi = [] if mapes_cels is None else ([mapes_cels] if isinstance(mapes_cels, (str, Path)) else list(mapes_cels))
    no_failiem = objekts_no_failiem(mapes_nosaukums, celi) if celi else None
    t = tokeni(atsifret(mapes_nosaukums))
    t = [x for x in t if not x.isdigit()]
    kand = []
    if idx is not None and len(t) >= 2:
        vieta = atslega(t[0])
        for v in sorted(_varianti(vieta)):
            kand += idx.meklet(v, t[1:])
        kand = list(dict.fromkeys(kand))
        # ja failos atrasts objekts (baznīca), oficiālos nosaukumus ar šo objektu liek pirmos
        if no_failiem:
            obj_k = atslega(tokeni(no_failiem[0])[-1])
            kand.sort(key=lambda k: obj_k not in [atslega(x) for x in tokeni(k)])
    if not kand and not no_failiem:
        return []
    mapes_cels = celi[0] if celi else None
    # pamatojums no mapes satura: objekta vārds dokumentos/failu nosaukumos
    rez = []
    for k in kand:
        obj = [x for x in tokeni(k) if atslega(x) in VISPARIGIE]
        piez = ""
        if celi and obj:
            sakne_v = atslega(obj[-1])[:5]
            reizes = 0
            try:
                for f in _mapes_faili(celi, 400):
                    if sakne_v in atslega(f.stem):
                        reizes += 1
                    elif f.suffix.lower() in DOKUMENTI and f.stat().st_size < 5_000_000:
                        reizes += atslega(dokumenta_teksts(f, 50000)).count(sakne_v)
            except Exception:
                pass
            if reizes:
                piez = f"mapē vārds “{obj[-1]}” atrasts {reizes}×"
        rez.append((k, piez))
    if no_failiem:
        nos, n, kopa = no_failiem
        if all(nfc(nos) != nfc(k) for k, _ in rez):
            rez.append((nos, f"tā nosaukti {n} no {kopa} failiem mapē"))
    return rez


def ielasit_vietvardus(saraksti, log=print):
    if not saraksti:
        log("Vietvārdu saraksts nav norādīts – pārbaude pēc saraksta netiks veikta.")
        return None
    vv = Vietvardi(lasit_sarakstus(saraksti))
    log(f"Vietvārdu sarakstā: {vv.skaits} nosaukumi")
    return vv


class Skenejums:
    """Skenēšanas rezultāts: plāna rindas, mapju dati, statistika."""
    def __init__(self):
        self.rindas = []            # plāna rindas (dict ar LAUKI)
        self.mapes = {}             # rel ceļš -> Mape
        self.stat = defaultdict(int)
        self.valigi = []
        self.lidzigie = []          # (vieta, [rel, ...])


def skenet(sakne, vv, bez_burtiem=False, progress=None, troksnis=TROKSNIS_NOKLUSETAIS, etaps=2,
           objekti_apaksmapes=False):
    """Sagrupē mapes.
    1. etaps – tikai vienas un tās pašas mapes kopijas (nosaukumi atšķiras ar nenozīmīgām
       piebildēm, garumzīmēm, rakstību); apakšmapes netiek veidotas.
    2. etaps – pēc vietas (+ objekta): datumu/piebilžu mapes kļūst par apakšmapēm, pusmuižas un
       objekti bez atrašanās vietas tiek pievienoti pēc satura; pēc izvēles objekti tiek likti
       vietas mapē kā apakšmapes."""
    global _VV_AKT
    _VV_AKT = vv
    sakne = Path(sakne).resolve()
    rez = Skenejums()
    mapes, rez.valigi = atrast_mapes(sakne, bez_burtiem, progress)
    burti = {} if bez_burtiem else burtu_mapes(sakne)
    tk = troksna_atslegas(troksnis)
    for m in mapes:
        rez.mapes[m.rel] = m
        m.n = Nosaukums(m.nos, tk)
    zinamas = noteikt_vietas([m.n for m in mapes], vv)

    def kanon(t):
        return atslega(VISPARIGIE.get(atslega(t), t))

    grupas = defaultdict(list)
    for m in mapes:
        if m.failu_skaits == 0:
            rez.stat["tukšas mapes (tiks izdzēstas rindā ★)"] += 1
            continue                      # tukšas mapes negrupē – tās izmet ★ rinda
        if etaps == 1:
            m.tirs = tirit_nosaukumu(m.nos, tk)
            vardi = [t for t, _ in m.n.tokeni]
            if not vardi:
                grupas[("#" + m.rel, "")].append(m)
                continue
            grupas[(" ".join(kanon(t) for t in vardi), m.n.datums or "")].append(m)
            continue
        if not m.n.vietas_k:                     # nosaukumā tikai datums/piebildes – atstājam
            grupas[("#" + m.rel, "")].append(m)
            continue
        grupas[(m.n.vietas_k, " ".join(kanon(o) for o in m.n.objekti))].append(m)

    if etaps == 2:
        # Objekts bez atrašanās vietas (Bērzu muiža) → tai pašai muižai ar vietu (… Tukums / … Cēsis)
        for key in sorted(grupas, key=lambda k: -len(k[1])):
            if key not in grupas or not key[1] or key[0].startswith("#"):
                continue
            ok = key[1].split()
            kand = [k2 for k2 in grupas if k2 != key and k2[0] == key[0]
                    and k2[1].split()[:len(ok)] == ok and len(k2[1].split()) > len(ok)]
            if kand:
                pievienot_pec_satura(grupas, key, kand, "objekts bez atrašanās vietas")
        # Pusmuižas → tās pašas vietas muiža / vieta
        for key in [k for k in grupas if PUSMUIZA_K in k[1].split()]:
            if key not in grupas:
                continue
            kand = [k2 for k2 in grupas if k2 != key and k2[0] == key[0] and PUSMUIZA_K not in k2[1].split()]
            pievienot_pec_satura(grupas, key, kand, "pusmuiža")

    lidzigi_nosaukumi(grupas, zinamas, etaps)
    vienads_saturs(grupas)

    rindas, stat = rez.rindas, rez.stat
    gnr = 0
    vietu_nos = {}           # vietas atslēga -> galvenās mapes nosaukums (objektiem kā apakšmapēm)
    # vispirms vietas (bez objekta), tad objekti – lai objekti zinātu vecāka mapes nosaukumu
    for (vk, ok) in sorted(grupas, key=lambda k: (bool(k[1]), k)):
        gm = grupas[(vk, ok)]
        if vk.startswith("#"):
            stat["kārtībā"] += 1
            continue
        pamata = [m for m in gm if not hasattr(m, "pm_darb")]
        # --- galvenās mapes nosaukums
        if etaps == 1:
            kand = [(re.sub(r"\s*(\d{2}\.\d{2}\.\d{4}|(?<![\d.])(19|20)\d\d(?![\d.]))\s*", " ", m.tirs).strip()
                     or m.tirs, m.failu_skaits) for m in pamata]
        elif ok:
            kand = [(salikt(" ".join(m.n.vieta + m.n.objekti)), m.failu_skaits) for m in pamata]
        else:
            kand = [(" ".join(m.n.vieta), m.failu_skaits) for m in pamata
                    if " ".join(atslega(t) for t in m.n.vieta) == vk]
            if not kand and vv is not None and len(unikali(vv.pilns.get(vk, ()))) == 1:
                kand = [(unikali(vv.pilns[vk])[0], 1)]
            if not kand:
                kand = [(" ".join(m.n.vieta), m.failu_skaits) for m in gm]
        pamat, statuss, neskaidrs, apstiprinats = ierosinat_nosaukumu(kand, vv)
        if etaps == 1:
            konflikts = diakritiku_konflikts([re.sub(r"[\d.]+", "", m.tirs) for m in pamata])
        else:
            konflikts = diakritiku_konflikts([" ".join(m.n.vieta) for m in pamata])
        if konflikts:
            statuss += "; atšķirīgas garumzīmju rakstības – iespējams, dažādas vietas"
        parbaudit = neskaidrs or konflikts
        if etaps == 1 and ok:                    # datums/gads paliek tā vietā, kur bija
            m0 = max(pamata, key=lambda m: vertejums(m.nos))
            pamat = m0.tirs if ok in m0.tirs else f"{m0.tirs} {ok}"
            pamat = labot_vardus(salikt(pamat), vv)
        if etaps == 2 and not ok:
            vietu_nos[vk] = pamat
        vecaks = ""
        if etaps == 2 and objekti_apaksmapes and ok:
            vecaks = vietu_nos.get(vk) or (unikali(vv.pilns.get(vk, ()))[0]
                                           if vv is not None and len(unikali(vv.pilns.get(vk, ()))) == 1 else "")

        def apaksmape(m):
            if etaps == 1 or hasattr(m, "pm_darb"):
                return ""
            if not m.n.datums and not m.n.citi:
                return ""
            dalas = [pamat] + ([m.n.datums] if m.n.datums else []) + m.n.citi
            return " ".join(dalas)

        def gala_rel(nos, burts):
            dal = [x for x in (burts, vecaks, nos) if x]
            return "/".join(dal)

        tiras = [m for m in pamata if not apaksmape(m)]
        if len(gm) == 1:
            m = gm[0]
            jauns = apaksmape(m) or pamat
            burts = merka_burts(vecaks or jauns, m.burts, burti)
            if nfc(gala_rel(jauns, burts)) == nfc(m.rel):
                stat["kārtībā"] += 1
                continue
            gnr += 1
            gid = f"G{gnr:04d}"
            stat["pārdēvējamas"] += 1
            st = statuss
            neparsaukt = parbaudit and not apstiprinats
            if not neparsaukt:
                st += "; pārdēvēšanas iemesls: " + parsaukt_iemesls(m, jauns, burts)
            if vecaks:
                st += f"; tiks ievietota vietas mapē “{vecaks}”"
            rindas.append(_rinda(gid, "MĒRĶIS" if neparsaukt and not vecaks else "PĀRDĒVĒT",
                                 m.nos if neparsaukt else jauns, m, "", "", st, vecaks))
            continue

        gnr += 1
        gid = f"G{gnr:04d}"
        stat["grupas ar variantiem"] += 1
        if tiras:
            labakais = max(tiras, key=lambda m: (not any(t.isdigit() for t in m.n.troksnis), vertejums(m.nos),
                                                  -len(m.n.troksnis), m.failu_skaits, -len(m.rel)))
        else:
            labakais = max(pamata, key=lambda m: (m.failu_skaits, vertejums(m.nos)))
        if parbaudit and not apstiprinats and not apaksmape(labakais):
            pamat = labakais.nos                   # neskaidros gadījumos nepārdēvējam
        burts = merka_burts(vecaks or pamat, labakais.burts, burti)
        merka_rel = gala_rel(pamat, burts)
        if vecaks:
            statuss += f"; tiks ievietota vietas mapē “{vecaks}”"
        sakartotas = [labakais] + sorted([m for m in gm if m is not labakais],
                                         key=lambda m: (bool(apaksmape(m)), m.rel))
        for m in sakartotas:
            am = apaksmape(m)
            st = statuss
            if m is labakais:
                darb = "MĒRĶIS" if (not am and nfc(merka_rel) == nfc(m.rel)) else "PĀRDĒVĒT"
                if darb == "PĀRDĒVĒT" and not am:
                    st += "; pārdēvēšanas iemesls: " + parsaukt_iemesls(m, pamat, burts)
                kop = ""
            else:
                kop_skaits = len(m.inventars & labakais.inventars)
                kop = round(100 * kop_skaits / len(m.inventars)) if m.inventars else ""
                if hasattr(m, "pm_darb"):
                    darb = "PĀRBAUDĪT" if parbaudit else m.pm_darb
                    st += "; " + m.pm_piez
                elif any(t.isdigit() and len(t) >= 3 for t in m.n.troksnis) and not am:
                    # “Rauna 000” – numurs bez nozīmes: apvieno tikai, ja saturs pārklājas
                    darb = "APVIENOT" if (kop != "" and kop >= 30) else "PĀRBAUDĪT"
                    st += f"; nosaukumā numurs bez nozīmes – kopīgi faili {kop or 0}%"
                elif parbaudit:
                    darb = "PĀRBAUDĪT"
                elif am or apstiprinats:
                    darb = "APVIENOT"
                elif m.inventars and labakais.inventars and kop_skaits == 0 and not apaksmape(labakais):
                    darb = "PĀRBAUDĪT"
                else:
                    darb = "APVIENOT"
                stat[darb] += 1
            if m.n.troksnis:
                st += "; nenozīmīgas piebildes: " + ", ".join(m.n.troksnis)
            rindas.append(_rinda(gid, darb, pamat, m, am, kop, st, vecaks))

    # Līdzīgi nosaukumi (tā pati vieta, cits objekts) – tikai informācijai
    pec_vietas = defaultdict(list)
    for (vk, ok), gm in grupas.items():
        if not vk.startswith("#"):
            pec_vietas[gm[0].n.vietas_k or vk].append(gm)
    for vk, gg in sorted(pec_vietas.items()):
        if len(gg) > 1:
            rez.lidzigie.append((vk, [m.rel for gm in gg for m in gm]))
    rindas.sort(key=lambda r: r["grupa"])
    return rez


def _rinda(gid, darb, merkis, m, apaksmape, kop, statuss, vecaks=""):
    return {
        "grupa": gid, "darbība": darb, "mērķa_nosaukums": merkis, "vecāka_mape": vecaks, "mape": m.rel,
        "apakšmape": apaksmape, "failu_skaits": m.failu_skaits,
        "izmērs_MB": f"{m.izmers / 1048576:.1f}".replace(".", ","),
        "kopīgi_ar_mērķi_%": kop,
        "vecākais_fails": fmt_laiks(m.vecakais), "jaunākais_fails": fmt_laiks(m.jaunakais),
        "vietvārdu_pārbaude": statuss,
    }


def parsaukt_iemesls(m, merkis, burts):
    """Cilvēkam saprotams paskaidrojums, kāpēc mapi ierosināts pārdēvēt."""
    vecais = nfc(m.nos)
    iemesli = []
    if burts and nfc(burts) != nfc(m.burts):
        iemesli.append(f"pārvietot uz burta mapi '{burts}'")
    n = getattr(m, "n", None)
    if n is not None and (n.troksnis or (n.datums and n.datums not in vecais)):
        if n.troksnis:
            iemesli.append("noņemtas piebildes: " + ", ".join(n.troksnis))
        if n.datums and n.datums not in vecais:
            iemesli.append("datums formātā dd.mm.gggg")
        return ", ".join(iemesli)
    if "_" in vecais:
        iemesli.append("pasvītras → atstarpes")
    if re.search(r"[^\S ]", vecais):
        iemesli.append("neredzamas/nestandarta atstarpes")
    if "  " in vecais or vecais != vecais.strip():
        iemesli.append("liekas atstarpes")
    tirs = re.sub(r"\s+", " ", vecais.replace("_", " ")).strip()
    if tirs != merkis:
        if bez_diakritikas(tirs).casefold() == bez_diakritikas(merkis).casefold():
            iemesli.append("garumzīmes")
        else:
            iemesli.append("rakstība")
    return ", ".join(iemesli) or "?"


def saglabat_planu(rindas, cels):
    with open(cels, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=LAUKI, delimiter=CSV_ATDALITAJS, extrasaction="ignore")
        w.writeheader()
        w.writerows(rindas)


def cmd_skenet(arg):
    sakne = Path(arg.arhivs).resolve()
    if not sakne.is_dir():
        sys.exit(f"Arhīva mape nav atrasta: {sakne}")
    saraksti = list(arg.saraksts or [])
    if not saraksti and Path("vietvardi.txt").exists():
        saraksti = ["vietvardi.txt"]
    vv = ielasit_vietvardus(saraksti)
    print(f"Skenēju {sakne} ...")
    rez = skenet(sakne, vv, arg.bez_burtiem, troksnis=arg.troksnis, etaps=arg.etaps,
                 objekti_apaksmapes=arg.objekti_apaksmapes)
    print(f"  atrastas {len(rez.mapes)} vietu mapes")

    izeja = Path(arg.izeja)
    saglabat_planu(rez.rindas, izeja)
    lidz = Path(izeja.with_name(izeja.stem + "_lidzigie.csv"))
    with open(lidz, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f, delimiter=CSV_ATDALITAJS)
        w.writerow(["vieta", "mapes ar šo vietu nosaukumā (netiek apvienotas)"])
        for bk, rels in rez.lidzigie:
            w.writerow([bk, " | ".join(rels)])

    stat = rez.stat
    print()
    print(f"Mapes, kurām viss kārtībā: {stat['kārtībā']}")
    print(f"Grupas ar vairākiem variantiem: {stat['grupas ar variantiem']}")
    print(f"Atsevišķas mapes pārdēvēšanai: {stat['pārdēvējamas']}")
    print(f"Ieteikts APVIENOT: {stat['APVIENOT']} mapes,  PĀRBAUDĪT manuāli: {stat['PĀRBAUDĪT']} mapes")
    if rez.valigi:
        print(f"Faili tieši burtu mapēs (ne vietu mapēs), netiek aiztikti: {len(rez.valigi)}")
    print(f"\nPlāns saglabāts: {izeja}")
    print(f"Līdzīgo nosaukumu atskaite: {lidz}")
    print("Atver plānu Excel, pārskati kolonnas 'darbība' un 'mērķa_nosaukums', saglabā kā 'CSV UTF-8'.")


# ---------------------------------------------------------------------------
# Apvienošana
# ---------------------------------------------------------------------------
class Zurnals:
    def __init__(self, cels):
        self.cels = Path(cels)
        self.f = open(self.cels, "w", encoding="utf-8-sig", newline="")
        self.w = csv.writer(self.f, delimiter=CSV_ATDALITAJS)
        self.w.writerow(["laiks", "darbība", "no", "uz"])
        self.f.flush()

    def raksti(self, darb, no, uz=""):
        self.w.writerow([datetime.now().isoformat(timespec="seconds"), darb, str(no), str(uz)])
        self.f.flush()

    def aizvert(self):
        self.f.close()


def parvietot(a, b):
    """Droša pārvietošana: nekad nepārraksta un neieliek mapi esošā mapē."""
    a, b = Path(a), Path(b)
    if b.exists():
        if os.path.samefile(a, b):           # tikai lielo/mazo burtu maiņa
            os.rename(a, b)
            return
        raise FileExistsError(f"Mērķis jau eksistē: {b}")
    b.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(a), str(b))


_hash_kese = {}


def jaucejs(p):
    p = Path(p)
    st = p.stat()
    k = (str(p), st.st_size, st.st_mtime_ns)
    if k not in _hash_kese:
        h = hashlib.sha1()
        with open(p, "rb") as f:
            for gab in iter(lambda: f.read(1 << 20), b""):
                h.update(gab)
        _hash_kese[k] = h.hexdigest()
    return _hash_kese[k]


def unikals_vards(mape, vards):
    p = Path(vards)
    n = 2
    while True:
        kand = mape / f"{p.stem} ({n}){p.suffix}"
        if not kand.exists():
            return kand
        n += 1


class Apvienotajs:
    def __init__(self, sakne, zurnals, karantina, izpildit):
        self.sakne = sakne
        self.z = zurnals
        self.karantina = karantina
        self.izpildit = izpildit
        self.sk = defaultdict(int)

    def uz_karantinu(self, fails):
        rel = Path(fails).relative_to(self.sakne)
        merkis = self.karantina / rel
        if merkis.exists():
            merkis = unikals_vards(merkis.parent, merkis.name)
        parvietot(fails, merkis)
        self.z.raksti("KARANTĪNA", fails, merkis)
        self.sk["dublikāti uz karantīnu"] += 1

    def indekss(self, mape):
        idx = defaultdict(list)
        for dirpath, _, filenames in os.walk(mape):
            for f in filenames:
                p = Path(dirpath) / f
                try:
                    idx[p.stat().st_size].append(p)
                except OSError:
                    pass
        return idx

    def apvienot(self, src, dst, idx):
        """Ielej mapes src saturu mapē dst (dst jau eksistē)."""
        dst_faili = {faila_atslega(p.name): p for p in dst.iterdir() if p.is_file()}
        dst_mapes = {atslega(p.name): p for p in dst.iterdir() if p.is_dir()}
        for e in sorted(src.iterdir()):
            if e.is_dir():
                mt = dst_mapes.get(atslega(e.name))
                if mt is None:
                    mt = dst / nfc(e.name)
                    mt.mkdir()
                    self.z.raksti("IZVEIDOTA_MAPE", "", mt)
                    dst_mapes[atslega(e.name)] = mt
                elif (vertejums(e.name) - vertejums(mt.name) >= 3      # tikai būtiski labāka rakstība,
                      and nfc(e.name) != nfc(mt.name)):                # ne lielais burts
                    jauns = dst / nfc(e.name)
                    parvietot(mt, jauns)
                    self.z.raksti("PĀRVIETOTS", mt, jauns)
                    idx.clear()
                    idx.update(self.indekss(dst))
                    mt = jauns
                    dst_mapes[atslega(e.name)] = mt
                self.apvienot(e, mt, idx)
                continue
            if ir_lieks(e.name):
                self.uz_karantinu(e)
                continue
            izm = e.stat().st_size
            tas_pats = dst_faili.get(faila_atslega(e.name))
            if tas_pats is not None:
                if tas_pats.stat().st_size == izm and jaucejs(tas_pats) == jaucejs(e):
                    self.uz_karantinu(e)
                    continue
                jauns = unikals_vards(dst, e.name)
                parvietot(e, jauns)
                self.z.raksti("PĀRVIETOTS", e, jauns)
                self.sk["faili ar tādu pašu nosaukumu, bet citu saturu (pārdēvēti)"] += 1
                idx[izm].append(jauns)
                dst_faili[faila_atslega(jauns.name)] = jauns
                continue
            if any(jaucejs(c) == jaucejs(e) for c in idx.get(izm, []) if c.exists()):
                self.uz_karantinu(e)
                self.sk["  no tiem ar citu nosaukumu/vietu"] += 1
                continue
            jauns = dst / e.name
            parvietot(e, jauns)
            self.z.raksti("PĀRVIETOTS", e, jauns)
            self.sk["pārvietoti faili"] += 1
            idx[izm].append(jauns)
            dst_faili[faila_atslega(e.name)] = jauns
        if not any(src.iterdir()):
            src.rmdir()
            self.z.raksti("DZĒSTA_TUKŠA_MAPE", src, "")


class PlanaKluda(Exception):
    pass


def lasit_planu(cels):
    teksts = lasit_tekstu(cels)
    pirma = teksts.splitlines()[0] if teksts else ""
    atd = ";" if pirma.count(";") >= pirma.count(",") else ","
    lasitajs = csv.DictReader(teksts.splitlines(), delimiter=atd)
    rindas = list(lasitajs)
    trukst = [l for l in ("grupa", "darbība", "mērķa_nosaukums", "mape") if l not in (lasitajs.fieldnames or [])]
    if trukst:
        raise PlanaKluda(f"Plānā trūkst kolonnu: {', '.join(trukst)}. Vai fails saglabāts kā 'CSV UTF-8'?")
    return rindas


class Darbs:
    """Vienas grupas izpildes plāns: soļi (no_mapes, uz_mapi) – kā mapes ielej galvenajā
    mapē vai tās apakšmapēs."""
    def __init__(self, gid, dst, soli):
        self.gid, self.dst, self.soli = gid, dst, soli

    @property
    def mapes_rel(self):
        return [s.relative_to(self.sakne).as_posix() for s, _ in self.soli]

    def apaksmapes(self):
        return ["" if d == self.dst else d.relative_to(self.dst).as_posix() for _, d in self.soli]


def sagatavot_darbus(sakne, rindas, bez_burtiem=False, log=print):
    """No plāna rindām sagatavo darbu sarakstu (Darbs objekti)."""
    sakne = Path(sakne).resolve()
    grupas = defaultdict(list)
    for r in rindas:
        grupas[str(r["grupa"]).strip()].append(r)
    burti = {} if bez_burtiem else burtu_mapes(sakne)

    darbi = []
    for gid, rr in sorted(grupas.items()):
        merka_r = [r for r in rr if r["darbība"].strip().upper() in ("MĒRĶIS", "PĀRDĒVĒT")]
        avotu_r = [r for r in rr if r["darbība"].strip().upper() == "APVIENOT"]
        if len(merka_r) != 1:
            if avotu_r or merka_r:
                log(f"  {gid}: jābūt tieši vienai mapei ar MĒRĶIS vai PĀRDĒVĒT – grupa izlaista")
            continue
        mr = merka_r[0]
        nosaukums = nfc(str(mr["mērķa_nosaukums"]).strip())
        if not derigs_nosaukums(nosaukums):
            log(f"  {gid}: nederīgs mērķa nosaukums '{nosaukums}' – grupa izlaista")
            continue
        src_merkis = sakne / mr["mape"]
        if not src_merkis.is_dir():
            log(f"  {gid}: mape '{mr['mape']}' nav atrasta – grupa izlaista")
            continue
        esosais_burts = mr["mape"].split("/")[0] if "/" in mr["mape"] else ""
        am_m = nfc(str(mr.get("apakšmape") or "").strip())
        vecaks = nfc(str(mr.get("vecāka_mape") or "").strip())
        if vecaks and not derigs_nosaukums(vecaks):
            log(f"  {gid}: nederīgs vecāka mapes nosaukums '{vecaks}' – grupa izlaista")
            continue
        if mr["darbība"].strip().upper() == "MĒRĶIS" and not am_m and not vecaks \
                and nosaukums == nfc(src_merkis.name):
            dst = src_merkis
        else:
            burts = esosais_burts if bez_burtiem else merka_burts(vecaks or nosaukums, esosais_burts, burti)
            dst = sakne.joinpath(*[x for x in (burts, vecaks, nosaukums) if x])
        soli = []
        for r in [mr] + avotu_r:
            p = sakne / r["mape"]
            if not p.is_dir():
                log(f"  {gid}: mape '{r['mape']}' nav atrasta – izlaista")
                continue
            am = nfc(str(r.get("apakšmape") or "").strip())
            if am and not derigs_nosaukums(am):
                log(f"  {gid}: nederīgs apakšmapes nosaukums '{am}' – mape izlaista")
                continue
            soli.append((p, dst / am if am else dst))
        if not soli or (len(soli) == 1 and soli[0][0] == soli[0][1]):
            continue
        d = Darbs(gid, dst, soli)
        d.sakne = sakne
        darbi.append(d)
    return darbi


def derigs_nosaukums(n):
    return bool(n) and not any(c in LOGU_AIZLIEGTAS for c in n) and not n.endswith((".", " "))


_KOPIJAS_PRIEKSA = re.compile(r"^(?:copy(?:[\s_]*\(\d+\))?[\s_]*of|kopija[\s_]+no|kopija)[\s_]+(.+)$", re.I)
_KOPIJAS_BEIGAS = re.compile(r"^(.+?)(?:[\s_\-,]*(?:-|,|_|\s)\s*(?:copy|kopija|kopēt|kopēts|kopie)"
                             r"(?:\s*\(\d+\)|\s+\d+)?)+$", re.I)
_NUMURS_BEIGAS = re.compile(r"^(.+?)\s*\(\d{1,2}\)$")


def kopijas_pamats(vards):
    """'foto - Copy (2).jpg' → ('foto.jpg', True); 'foto.jpg' → ('foto.jpg', False)."""
    p = Path(vards)
    stem, ext = p.stem, p.suffix
    sak = stem
    while True:
        jauns = stem
        for rx in (_KOPIJAS_BEIGAS, _KOPIJAS_PRIEKSA, _NUMURS_BEIGAS):
            m = rx.match(jauns.strip())
            if m and m.group(1).strip():
                jauns = m.group(1).strip()
        if jauns == stem:
            break
        stem = jauns
    return stem + ext, stem != sak


def atrast_liekos_failus(sakne, mapes, progress=None):
    """Visā arhīvā atrod (ātri, bez satura salīdzināšanas):
      lieki          – tukšie (0 baitu) un pagaidu faili: [{rel, veids}]
      kopiju_grupas  – faili vienā mapē ar vienu pamatnosaukumu, no kuriem vismaz viens ir kopija
                       (“- Copy”, “(2)” …): [{mape, pamats, versijas: [rel], kopijas: [rel]}].
    Saturu salīdzina analizet_kopijas()."""
    lieki, kgrupas, vienas = [], [], []
    for n, m in enumerate(mapes):
        if progress and n % 50 == 0:
            progress(f"meklēju failu kopijas: {m.rel}")
        for rel, veids in getattr(m, "lieki", []):
            lieki.append({"rel": f"{m.rel}/{rel}", "veids": veids})
        grupas = defaultdict(list)
        for rel, izm, mt in m.faili:
            d, _, vards = rel.rpartition("/")
            pamats, ir_kop = kopijas_pamats(vards)
            grupas[(d, faila_atslega(pamats))].append((rel, vards, pamats, ir_kop))
        for (d, _), gr in grupas.items():
            if len(gr) == 1 and gr[0][3] and derigs_nosaukums(gr[0][2]):
                # vientuļa kopija bez oriģināla – tikai tīrs nosaukums
                vienas.append((f"{m.rel}/{gr[0][0]}", gr[0][2]))
                continue
            if len(gr) < 2 or not any(x[3] for x in gr):
                continue
            gr.sort(key=lambda x: (x[3], len(x[1]), x[1]))          # oriģināls pirmais
            pamats = next((x[1] for x in gr if not x[3]), gr[0][2])
            kgrupas.append({"mape": f"{m.rel}/{d}" if d else m.rel, "pamats": pamats,
                            "versijas": [f"{m.rel}/{x[0]}" for x in gr],
                            "kopijas": [f"{m.rel}/{x[0]}" for x in gr if x[3]]})
    if progress:
        progress("meklēju tukšās mapes…")
    try:
        tuksas = atrast_tuksas_mapes(sakne, {x["rel"] for x in lieki})
    except Exception:
        tuksas = []
    return {"lieki": lieki, "kopiju_grupas": kgrupas, "parsaukt_vienas": vienas, "tuksas_mapes": tuksas}


def analizet_kopijas(sakne, t, kese=None, progress=None):
    """Salīdzina failu kopiju grupu saturu (baiti, bildes vizuāli, dokumenti pēc teksta).
    Atgriež analīzi tādā pašā formā kā analizet_grupu: {faili{rel: dict}, kopas[...]}."""
    sakne = Path(sakne)
    faili, kopas = {}, []
    kg = t.get("kopiju_grupas", [])
    for gi, g in enumerate(kg):
        if progress and gi % 10 == 0:
            progress(gi, len(kg))
        fl = []
        for nr, rel in enumerate(g["versijas"]):
            p = sakne / rel
            try:
                st = p.stat()
            except OSError:
                continue
            f = {"rel": rel, "nr": nr, "cels": p, "izm": st.st_size, "mt": st.st_mtime, "w": 0, "h": 0,
                 "attels": IR_PILLOW and p.suffix.lower() in ATTELU_PAPL, "dok": p.suffix.lower() in DOKUMENTI,
                 "teksts": None, "kopija": rel in g["kopijas"], "pamats": g["pamats"], "mape_d": g["mape"],
                 "dest": rel, "iek": rel}
            fl.append(f)
            faili[rel] = f
        if len(fl) < 2:
            continue
        n = len(fl)
        uf = _UF(n)
        # 1) baiti
        hashi = {}
        for i, f in enumerate(fl):
            try:
                hashi[i] = (f["izm"], jaucejs(f["cels"]))
            except OSError:
                pass
        for i in range(n):
            for j in range(i + 1, n):
                if i in hashi and hashi.get(i) == hashi.get(j):
                    uf.u(i, j)
        baitu_kl = {uf.f(i) for i in range(n)}
        # 2) bildes / dokumenti
        att = {}

        def iel(i):
            if i not in att:
                try:
                    att[i] = atvert_attelu(fl[i]["cels"])
                except Exception:
                    att[i] = None
                if att[i]:
                    fl[i]["w"], fl[i]["h"] = att[i][0], att[i][1]
            return att[i]
        zim = {}
        for i, f in enumerate(fl):
            if f["dok"]:
                f["teksts"] = dokumenta_teksts(f["cels"])
                if len(f["teksts"]) >= 20:
                    zim[i] = teksta_zimes(f["teksts"])
        lidz = set()
        rep = sorted({uf.f(i) for i in range(n)})
        for x in range(len(rep)):
            for y in range(x + 1, len(rep)):
                i, j = rep[x], rep[y]
                if uf.f(i) == uf.f(j):
                    continue
                if fl[i]["attels"] and fl[j]["attels"]:
                    a, b = iel(i), iel(j)
                    rr = salidzinat_attelus(a, b) if (a and b) else "atskirigi"
                    if rr == "vienadi" and not detalizeti_vienadi(fl[i]["cels"], fl[j]["cels"]):
                        rr = "lidzigi"
                elif i in zim and j in zim:
                    if teksta_atslega(fl[i]["teksts"]) == teksta_atslega(fl[j]["teksts"]):
                        rr = "vienadi"
                    else:
                        rr = "lidzigi" if teksta_lidziba(zim[i], zim[j]) >= 0.5 else "atskirigi"
                else:
                    rr = "atskirigi"
                if rr == "vienadi":
                    uf.u(i, j)
                elif rr == "lidzigi":
                    lidz.add((i, j))
        for i in range(n):
            if fl[i]["attels"] and not fl[i]["w"]:
                iel(i)
        kl = defaultdict(list)
        for i in range(n):
            kl[uf.f(i)].append(i)
        klasteri = sorted(kl.values(), key=min)

        def labakais(c):
            return max(c, key=lambda i: (fl[i]["w"] * fl[i]["h"], fl[i]["izm"], not fl[i]["kopija"],
                                         nosaukuma_kvalitate(fl[i]["cels"].name, [fl[j]["cels"].name for j in c]),
                                         -len(fl[i]["rel"]), -fl[i]["mt"]))
        if len(klasteri) == 1:
            veids = "identiski" if len(baitu_kl) == 1 else "vienadi"
        else:
            kl_id = {i: k for k, c in enumerate(klasteri) for i in c}
            veids = "jaizlemj" if any(kl_id[i] != kl_id[j] for i, j in lidz) else "atskirigi"
        ieteikts = {fl[labakais(c)]["rel"] for c in klasteri}
        vers = [f["rel"] for f in fl]
        kopas.append({"id": "K|" + "|".join(sorted(vers)), "veids": veids, "versijas": vers,
                      "klasteri": [[fl[i]["rel"] for i in c] for c in klasteri],
                      "ieteikts": ieteikts, "paturet": set(ieteikts), "lietotajs": False})
    if kese:
        with kese.lock:
            kese.db.commit()
    return {"faili": faili, "kopas": kopas}


def kopiju_parsaukt(faili, kopas):
    """Kopiju rindai: paliekošo failu nosaukumi (labākais no vienādiem, bez “Copy”)."""
    return paliekoso_nosaukumi(list(faili.values()), kopas)


def tirisanas_darbibas(t, an):
    """Izpildei: {izmest: [{rel, veids}], parsaukt: [(rel, jauns)]}."""
    izm = [dict(x) for x in t.get("lieki", [])]
    if an:
        izm += [{"rel": r, "veids": "kopija"} for r in izmetamie(an["kopas"])]
        pars = list(kopiju_parsaukt(an["faili"], an["kopas"]).items())
    else:
        pars = []
    for rel, jauns in t.get("parsaukt_vienas", []):
        pars.append((rel, sakartot_faila_nosaukumu(jauns) if _KARTOT_FAILUS else jauns))
    return {"izmest": izm, "parsaukt": pars}


def atrast_tuksas_mapes(sakne, lieki_rel=()):
    """Mapes, kurās nav neviena faila (neskaitot pagaidu/tukšos, kas tiks izmesti) – arī ar tukšām
    apakšmapēm. Atgriež augstākās šādas mapes (rel). Arhīva sakne un burtu mapes netiek aiztiktas."""
    sakne = Path(sakne).resolve()
    lieki = set(lieki_rel)
    tuksa = {}
    for dirpath, dirnames, filenames in os.walk(sakne, topdown=False):
        p = Path(dirpath)
        dalas = p.relative_to(sakne).parts
        if any(sistemas(x) for x in dalas):
            continue
        rel = "/".join(dalas)
        faili = [f for f in filenames
                 if not (ir_lieks(f) or (f"{rel}/{f}" if rel else f) in lieki)]
        tuksa[p] = not faili and all(tuksa.get(p / d, False) for d in dirnames)
    rez = []
    for p, t in tuksa.items():
        dalas = p.relative_to(sakne).parts
        if t and len(dalas) >= 2 and not (len(dalas) > 2 and tuksa.get(p.parent, False)):
            rez.append("/".join(dalas))
    return sorted(rez, key=str.casefold)


def dzest_tuksas_mapes(sakne, z, log=print):
    """Izdzēš tukšās mapes (no apakšas uz augšu), katru ierakstot žurnālā (atsaucams).
    Sakne, burtu mapes un _ZURNALI/_DUBLIKATI netiek aiztiktas. Atgriež izdzēsto skaitu."""
    sakne = Path(sakne).resolve()
    n = 0
    for dirpath, dirnames, filenames in os.walk(sakne, topdown=False):
        p = Path(dirpath)
        dalas = p.relative_to(sakne).parts
        if len(dalas) < 2 or any(sistemas(x) for x in dalas):
            continue
        try:
            if not any(p.iterdir()):
                p.rmdir()
                z.raksti("DZĒSTA_TUKŠA_MAPE", p, "")
                n += 1
        except OSError as e:
            log(f"  Neizdevās izdzēst tukšo mapi {p}: {e}")
    return n


def ir_tukss(p):
    try:
        return Path(p).is_file() and Path(p).stat().st_size == 0
    except OSError:
        return False


def ir_lieks(nos):
    """Sistēmas un pagaidu faili, kas vienmēr jāizmet (Thumbs.db, ~$Word pagaidu faili)."""
    return nos.casefold() in IGNORET or nos.startswith("~$")


# ---------------------------------------------------------------------------
# Attēlu vizuālā salīdzināšana un grupas analīze
# ---------------------------------------------------------------------------
try:
    from PIL import Image, ImageOps, ImageChops, ImageStat, ImageFilter
    Image.MAX_IMAGE_PIXELS = None          # lieli skenējumi nav "uzbrukums"
    IR_PILLOW = True
except Exception:
    IR_PILLOW = False

ATTELU_PAPL = {".jpg", ".jpeg", ".png", ".gif", ".bmp", ".tif", ".tiff", ".webp"}

VEIDI = {
    "identiski": "= saturs identisks",
    "vienadi": "≈ vienāds saturs",
    "jaizlemj": "? līdzīgi – jāizlemj",
    "atskirigi": "≠ dažādi",
    "tukss": "✖ tukšs dokuments",
}


class AttelaKese:
    """Attēlu nospiedumu kešatmiņa (lai otrreiz nav jāatver tās pašas bildes)."""
    def __init__(self, cels):
        import sqlite3
        import threading
        self.lock = threading.Lock()
        self.db = sqlite3.connect(str(cels), check_same_thread=False)
        self.db.execute("CREATE TABLE IF NOT EXISTS n (k TEXT PRIMARY KEY, w INT, h INT, d TEXT)")
        self.jauni = 0

    def get(self, k):
        with self.lock:
            r = self.db.execute("SELECT w, h, d FROM n WHERE k=?", (k,)).fetchone()
        return (r[0], r[1], int(r[2], 16)) if r else None

    def put(self, k, w, h, d):
        with self.lock:
            self.db.execute("INSERT OR REPLACE INTO n VALUES (?,?,?,?)", (k, w, h, format(d, "x")))
            self.jauni += 1
            if self.jauni % 200 == 0:
                self.db.commit()

    def aizvert(self):
        with self.lock:
            self.db.commit()
            self.db.close()


def atvert_attelu(p, mazs=(320, 320)):
    """Atver attēlu samazinātu (ātri). Atgriež (platums, augstums, RGB attēls)."""
    im = Image.open(p)
    w, h = im.size
    try:
        if im.getexif().get(0x0112, 1) in (5, 6, 7, 8):
            w, h = h, w
    except Exception:
        pass
    try:
        im.draft("RGB", mazs)
    except Exception:
        pass
    try:
        im = ImageOps.exif_transpose(im)
    except Exception:
        pass
    if getattr(im, "n_frames", 1) > 1:
        im.seek(0)
    im = im.convert("RGB")
    im.thumbnail((mazs[0] * 2, mazs[1] * 2))
    return w, h, im


def dhash(im):
    g = im.convert("L").resize((9, 8), Image.LANCZOS)
    px = list(g.tobytes())
    v = 0
    for r in range(8):
        for c in range(8):
            v = (v << 1) | (px[r * 9 + c] > px[r * 9 + c + 1])
    return v


def salidzinat_attelus(a, b):
    """a, b = (w, h, im). Atgriež 'vienadi', 'lidzigi' vai 'atskirigi'.
    'vienadi' – tikai tad, ja bildes pēc samazināšanas līdz 256 px sakrīt praktiski pikseli
    pikselī (atšķiras tikai fails: kompresija, apraksts, izšķirtspēja). Jebkurš uzraksts,
    ūdenszīme, apgriešana vai krāsu maiņa → 'lidzigi' (jāizlemj tev)."""
    (w1, h1, i1), (w2, h2, i2) = a, b
    if not (w1 and h1 and w2 and h2):
        return "atskirigi"
    r1, r2 = w1 / h1, w2 / h2
    if abs(r1 - r2) / max(r1, r2) < 0.01:
        izm = (256, max(1, round(256 / r1)))
        x1 = i1.resize(izm, Image.LANCZOS)
        x2 = i2.resize(izm, Image.LANCZOS)
        d = ImageChops.difference(x1, x2)
        vid = sum(ImageStat.Stat(d).mean) / 3
        hist = d.convert("L").histogram()
        visi = izm[0] * izm[1]
        lielas = sum(hist[20:])          # pikseļi ar redzamu atšķirību
        if vid < 2.0 and lielas <= max(2, visi // 20000):
            return "vienadi"
        if vid < 15:
            return "lidzigi"
    ham = bin(dhash(i1) ^ dhash(i2)).count("1")
    return "lidzigi" if ham <= 12 else "atskirigi"


def detalizeti_vienadi(p1, p2):
    """Otrā, rūpīgākā pārbaude. True tikai tad, ja bildes atšķiras vien ar kompresiju,
    aprakstu vai izšķirtspēju – nevis ar uzrakstu, ūdenszīmi, apgriešanu u.tml."""
    try:
        w1, h1, a = atvert_attelu(p1, (2400, 2400))
        w2, h2, b = atvert_attelu(p2, (2400, 2400))
    except Exception:
        return False
    if abs(w1 - w2) <= 2 and abs(h1 - h2) <= 2:
        # vienāds izmērs – salīdzinām pilnā (līdz 2400 px) izšķirtspējā
        W = min(a.width, b.width, 2400)
        robeza, slieksnis = 4, 24
    else:
        # dažāda izšķirtspēja – salīdzinām mazākās bildes izmērā
        W = min(a.width, b.width, 1600)
        robeza, slieksnis = 10, 32
    izm = (W, max(1, round(W * a.height / a.width)))
    x1 = (a if a.size == izm else a.resize(izm, Image.LANCZOS)).filter(ImageFilter.GaussianBlur(0.7))
    x2 = (b if b.size == izm else b.resize(izm, Image.LANCZOS)).filter(ImageFilter.GaussianBlur(0.7))
    h = ImageChops.difference(x1, x2).convert("L").histogram()
    if robeza == 4:
        merogs = max(1.0, izm[0] * izm[1] / 960000)
    else:
        merogs = max(1.0, izm[0] * izm[1] / 240000)
    return sum(h[slieksnis:]) <= robeza * merogs


# ---------------------------------------------------------------------------
# Dokumentu teksts, salīdzināšana un nosaukumi
# ---------------------------------------------------------------------------
DOKUMENTI = {".docx", ".doc", ".odt", ".rtf", ".txt"}

_GENERISKS = re.compile(
    r"^(new |jauns |jauna )?(microsoft )?(office )?(word |excel )?"
    r"(document|dokuments|doc|text document|teksta dokuments|rich text document|"
    r"opendocument text|dokuments bez nosaukuma|untitled)"
    r"\s*(\(\d+\)|\d+)?(\s*-\s*(copy|kopija)(\s*\(\d+\))?)?$", re.I)


def ir_bezvarda_dokuments(nos):
    p = Path(nos)
    return p.suffix.lower() in DOKUMENTI and bool(_GENERISKS.match(p.stem.strip()))


def dokumenta_teksts(p, max_burti=200000):
    """Nolasa dokumenta tekstu (docx, odt, doc, rtf, txt). Neizdodas → ''."""
    import html
    import zipfile
    p = Path(p)
    ext = p.suffix.lower()
    try:
        if ext in (".docx", ".odt"):
            with zipfile.ZipFile(p) as z:
                xml = z.read("word/document.xml" if ext == ".docx" else "content.xml").decode("utf-8", "replace")
            xml = re.sub(r"</w:p>|</text:p>|</text:h>|<w:br[^>]*/>|<w:tab/>|<text:line-break/>", "\n", xml)
            t = html.unescape(re.sub(r"<[^>]+>", "", xml))
        elif ext == ".doc":
            b = p.read_bytes()[:8_000_000]
            # Word 97–2003: teksts ir UTF-16LE vai 8 bitu kodējumā
            u16 = re.findall(rb"(?:(?:[\x20-\x7e]|[\x0d\x09])\x00|[\x00-\xff][\x01\x04\x20]){12,}", b)
            t16 = "\n".join(x.decode("utf-16-le", "ignore") for x in u16)
            b8 = re.findall(rb"[\x20-\x7e\xc0-\xfe\x0d\x09]{20,}", b)
            t8 = "\n".join(x.decode("cp1257", "ignore") for x in b8)
            t = t16 if len(t16) >= len(t8) * 0.5 else t8
        elif ext == ".rtf":
            r = p.read_bytes()[:8_000_000].decode("latin-1", "ignore")
            r = re.sub(r"\\'([0-9a-fA-F]{2})", lambda m: bytes([int(m.group(1), 16)]).decode("cp1257", "ignore"), r)
            r = re.sub(r"\\u(-?\d+)\??", lambda m: chr(int(m.group(1)) % 65536), r)
            r = re.sub(r"\{\\\*[^{}]*\}", "", r)
            r = re.sub(r"\\par[d]?\b", "\n", r)
            t = re.sub(r"\\[a-zA-Z]+-?\d* ?|[{}]", "", r)
        else:
            t = lasit_tekstu(p)
    except Exception:
        return ""
    t = t[:max_burti]
    t = re.sub(r"[ \t\u00a0]+", " ", t)
    t = re.sub(r"\s*\n\s*", "\n", t).strip()
    return t


def tukss_dokuments(p, teksts):
    """Dokuments bez teksta un bez attēliem (docx/odt/txt, kur teksta nolasīšana ir droša)."""
    import zipfile
    p = Path(p)
    ext = p.suffix.lower()
    if teksts.strip() or ext not in (".docx", ".odt", ".txt"):
        return False
    if ext == ".txt":
        return True
    try:
        with zipfile.ZipFile(p) as z:
            return not any(n.startswith(("word/media/", "Pictures/", "word/embeddings/")) for n in z.namelist())
    except Exception:
        return False


def teksta_atslega(t):
    return re.sub(r"\s+", " ", t).strip().casefold()


def teksta_zimes(t):
    """Vārdu trijnieku kopa līdzības novērtēšanai."""
    v = re.findall(r"\w+", t.casefold())[:4000]
    return {hash((v[i], v[i + 1], v[i + 2])) for i in range(len(v) - 2)} or {hash(tuple(v))}


def teksta_lidziba(a, b):
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def nosaukums_no_teksta(t, max_g=60):
    for rinda in t.split("\n"):
        r = re.sub(r"\s+", " ", rinda).strip(" .,:;-–—\t")
        if sum(ch.isalpha() for ch in r) >= 3:
            r = "".join(c for c in r if c not in LOGU_AIZLIEGTAS and ord(c) >= 32)
            if len(r) > max_g:
                r = r[:max_g].rsplit(" ", 1)[0]
            return r.strip(" .")
    return ""


class _UF:
    def __init__(self, n):
        self.p = list(range(n))

    def f(self, x):
        while self.p[x] != x:
            self.p[x] = self.p[self.p[x]]
            x = self.p[x]
        return x

    def u(self, a, b):
        a, b = self.f(a), self.f(b)
        if a != b:
            self.p[max(a, b)] = min(a, b)


def analizet_grupu(sakne, mapes_rel, kese=None, progress=None, apaksmapes=None, vietas_nosaukums=""):
    """Salīdzina visus failus grupas mapēs (mapes_rel[0] = mērķis).
    apaksmapes – katrai mapei: apakšmape, kurā tā nonāks ('' = galvenajā mapē).
    Atgriež (faili, kopas, parsaukt):
      faili    – saraksts ar dict(rel, nr, mape, iek, dest, cels, izm, mt, w, h, attels, dok)
      kopas    – saraksts ar dict(id, veids, versijas[rel], klasteri[[rel]], paturet{rel}, ieteikts{rel})
      parsaukt – {rel: jaunais nosaukums} bezvārda dokumentiem."""
    sakne = Path(sakne)
    apaksmapes = list(apaksmapes or [""] * len(mapes_rel))
    faili = []
    for nr, mrel in enumerate(mapes_rel):
        am = apaksmapes[nr] if nr < len(apaksmapes) else ""
        bazes = sakne / mrel
        for dirpath, dirnames, filenames in os.walk(bazes):
            dirnames[:] = [d for d in dirnames if not sistemas(d)]
            for f in filenames:
                if ir_lieks(f):
                    continue
                p = Path(dirpath) / f
                try:
                    st = p.stat()
                except OSError:
                    continue
                if st.st_size == 0:
                    continue                      # tukšs fails – tiks izmests automātiski
                iek = p.relative_to(bazes).as_posix()
                faili.append({"rel": f"{mrel}/{iek}", "nr": nr, "mape": mrel, "iek": iek,
                              "dest": f"{am}/{iek}" if am else iek, "cels": p,
                              "izm": st.st_size, "mt": st.st_mtime, "mt_ns": st.st_mtime_ns,
                              "w": 0, "h": 0, "dh": None,
                              "attels": IR_PILLOW and p.suffix.lower() in ATTELU_PAPL,
                              "dok": p.suffix.lower() in DOKUMENTI, "teksts": None})
    n = len(faili)
    uf_visi, uf_sat = _UF(n), _UF(n)

    # 1) vienāds nosaukums dažādās mapēs
    pec_vards = defaultdict(list)
    for i, f in enumerate(faili):
        if not ir_bezvarda_dokuments(f["iek"].rsplit("/", 1)[-1]):
            pec_vards[faila_atslega(f["dest"])].append(i)
    for idx in pec_vards.values():
        for j in idx[1:]:
            uf_visi.u(idx[0], j)

    # 2) identisks saturs (baiti)
    pec_izm = defaultdict(list)
    for i, f in enumerate(faili):
        if f["izm"] > 0:
            pec_izm[f["izm"]].append(i)
    hashi = {}
    for idx in pec_izm.values():
        if len(idx) < 2:
            continue
        pec_h = defaultdict(list)
        for i in idx:
            try:
                h = jaucejs(faili[i]["cels"])
            except OSError:
                continue
            hashi[i] = h
            pec_h[h].append(i)
        for grupa in pec_h.values():
            for j in grupa[1:]:
                uf_visi.u(grupa[0], j)
                uf_sat.u(grupa[0], j)

    # 3) attēlu nospiedumi un vizuāli vienādi faili
    atteli_mem = {}

    def iel(i):
        if i not in atteli_mem:
            if len(atteli_mem) > 400:
                atteli_mem.clear()
            try:
                atteli_mem[i] = atvert_attelu(faili[i]["cels"])
            except Exception:
                atteli_mem[i] = None
        return atteli_mem[i]

    attelu_idx = [i for i, f in enumerate(faili) if f["attels"]]
    for k, i in enumerate(attelu_idx):
        f = faili[i]
        if progress and k % 20 == 0:
            progress(k, len(attelu_idx))
        kk = f"{f['cels']}|{f['izm']}|{f['mt_ns']}"
        r = kese.get(kk) if kese else None
        if r is None:
            a = iel(i)
            if a is None:
                f["attels"] = False
                continue
            r = (a[0], a[1], dhash(a[2]))
            if kese:
                kese.put(kk, *r)
        f["w"], f["h"], f["dh"] = r

    salidz = {}

    def sal(i, j):
        k = (min(i, j), max(i, j))
        if k not in salidz:
            a, b = iel(i), iel(j)
            r = salidzinat_attelus(a, b) if (a and b) else "atskirigi"
            if r == "vienadi" and not detalizeti_vienadi(faili[i]["cels"], faili[j]["cels"]):
                r = "lidzigi"
            salidz[k] = r
        return salidz[k]

    pec_dh = defaultdict(list)
    for i in attelu_idx:
        if faili[i]["dh"] is not None:
            pec_dh[faili[i]["dh"]].append(i)
    for idx in pec_dh.values():
        for x in range(len(idx)):
            for y in range(x + 1, len(idx)):
                i, j = idx[x], idx[y]
                if uf_sat.f(i) == uf_sat.f(j):
                    continue
                if sal(i, j) == "vienadi":
                    uf_visi.u(i, j)
                    uf_sat.u(i, j)
    # vienāda nosaukuma attēli ar atšķirīgu dHash – arī pārbaudām
    for idx in pec_vards.values():
        att = [i for i in idx if faili[i]["attels"] and faili[i]["dh"] is not None]
        for x in range(len(att)):
            for y in range(x + 1, len(att)):
                i, j = att[x], att[y]
                if uf_sat.f(i) != uf_sat.f(j) and sal(i, j) == "vienadi":
                    uf_sat.u(i, j)

    # 4) dokumenti: vienāds teksts = dublikāts, līdzīgs teksts = jāizlemj
    dok_idx = [i for i, f in enumerate(faili) if f["dok"]]
    zimes = {}
    for i in dok_idx:
        t = dokumenta_teksts(faili[i]["cels"])
        faili[i]["teksts"] = t
        if len(t) >= 20:
            zimes[i] = teksta_zimes(t)
    pec_teksta = defaultdict(list)
    for i in zimes:
        pec_teksta[teksta_atslega(faili[i]["teksts"])].append(i)
    for grupa in pec_teksta.values():
        for j in grupa[1:]:
            uf_visi.u(grupa[0], j)
            uf_sat.u(grupa[0], j)
    dok_lidz = {}
    zl = list(zimes)
    if len(zl) <= 600:
        for x in range(len(zl)):
            for y in range(x + 1, len(zl)):
                i, j = zl[x], zl[y]
                if uf_sat.f(i) == uf_sat.f(j):
                    continue
                l = teksta_lidziba(zimes[i], zimes[j])
                if l >= 0.5:
                    dok_lidz[(min(i, j), max(i, j))] = l
                    uf_visi.u(i, j)

    def lidzigi(i, j):
        if faili[i]["attels"] and faili[j]["attels"]:
            return sal(i, j) == "lidzigi"
        if i in zimes and j in zimes:
            return teksta_lidziba(zimes[i], zimes[j]) >= 0.5
        return False

    # 5) kopas
    def labakais(idx):
        return max(idx, key=lambda i: (faili[i]["w"] * faili[i]["h"],
                                       faili[i]["cels"].suffix.lower() == ".docx", faili[i]["izm"],
                                       not kopijas_pamats(faili[i]["cels"].name)[1],
                                       nosaukuma_kvalitate(faili[i]["cels"].name,
                                                           [faili[j]["cels"].name for j in idx]),
                                       faili[i]["nr"] == 0, -faili[i]["mt"]))

    komp = defaultdict(list)
    for i in range(n):
        komp[uf_visi.f(i)].append(i)
    kopas = []
    for idx in komp.values():
        if len(idx) < 2:
            continue
        kl = defaultdict(list)
        for i in idx:
            kl[uf_sat.f(i)].append(i)
        klasteri = sorted(kl.values(), key=lambda c: min(c))
        if len(klasteri) == 1:
            c = klasteri[0]
            veids = "identiski" if len({hashi.get(i) for i in c}) == 1 and None not in {hashi.get(i) for i in c} \
                else "vienadi"
        else:
            veids = "atskirigi"
            labie = [labakais(c) for c in klasteri]
            for x in range(len(labie)):
                for y in range(x + 1, len(labie)):
                    i, j = labie[x], labie[y]
                    if lidzigi(i, j):
                        veids = "jaizlemj"
        ieteikts = {faili[labakais(c)]["rel"] for c in klasteri}
        versijas = [faili[i]["rel"] for i in sorted(idx, key=lambda i: (faili[i]["nr"], faili[i]["iek"]))]
        kopas.append({"id": "|".join(sorted(versijas)), "veids": veids, "versijas": versijas,
                      "klasteri": [[faili[i]["rel"] for i in c] for c in klasteri],
                      "ieteikts": ieteikts, "paturet": set(ieteikts), "lietotajs": False})
    if kese:
        with kese.lock:
            kese.db.commit()

    # 6) tukši dokumenti (bez teksta un attēliem) – izmest, ja tie nav jau kādā kopā
    kopas_faili = {v for k in kopas for v in k["versijas"]}
    for f in faili:
        if f["dok"] and f["rel"] not in kopas_faili and tukss_dokuments(f["cels"], f["teksts"] or ""):
            kopas.append({"id": f["rel"], "veids": "tukss", "versijas": [f["rel"]],
                          "klasteri": [[f["rel"]]], "ieteikts": set(), "paturet": set(), "lietotajs": False})
    parsaukt = bezvarda_nosaukumi(faili, kopas, vietas_nosaukums)
    return faili, kopas, parsaukt


_VV_AKT = None            # pēdējais ielādētais vietvārdu saraksts (nosaukumu labošanai)
_KARTOT_FAILUS = False   # vai sakārtot paliekošo failu nosaukumus


def iestatit_failu_kartosanu(ieslegts, vv=None):
    global _KARTOT_FAILUS, _VV_AKT
    _KARTOT_FAILUS = bool(ieslegts)
    if vv is not None:
        _VV_AKT = vv


def sakartot_faila_nosaukumu(vards):
    """Ramas_krogs_(Katlakalns).JPG → Ramas krogs (Katlakalns).jpg; parvaldn → pārvaldnieka; muiza → muiža."""
    p = Path(vards)
    stem = atsifret(p.stem).replace("_", " ")
    stem = re.sub(r"\s+", " ", stem).strip(" .")
    stem = labot_vardus(salikt(stem), _VV_AKT) if stem else p.stem
    stem = "".join(c for c in stem if c not in LOGU_AIZLIEGTAS).strip(" .") or p.stem
    return stem + p.suffix.lower()


def nosaukuma_kvalitate(vards, citi=()):
    """Cik labs ir faila nosaukums: bez “Copy”, ar garumzīmēm, ar zināmiem vārdiem, bez nejaušiem
    piedēkļiem (Raiskums 88h ↔ Raiskums 88, …_p5 ↔ …_p, (Katlakalns)gg ↔ (Katlakalns))."""
    stem = Path(vards).stem
    v = vertejums(stem)
    if kopijas_pamats(vards)[1]:
        v -= 100
    pilns = atsifret(stem)
    zin = 0
    for t in tokeni(pilns):
        k = atslega(t)
        if k in _VARDNICA or k in VISPARIGIE or (_VV_AKT is not None and k in _VV_AKT.vardi):
            zin += 1
    v += 2 * zin
    if pilns != nfc(stem):
        v += 1                                   # zināms saīsinājums
    sc = stem.casefold()
    for o in citi:
        os_ = Path(o).stem.casefold()
        if os_ != sc and sc.startswith(os_) and 0 < len(sc) - len(os_) <= 3:
            v -= 5                               # nejaušs piedēklis
    return v


def paliekoso_nosaukumi(faili, kopas, vietas_nosaukums="", parraksti=None):
    """Paliekošo failu jaunie nosaukumi:
      – bezvārda dokumentiem (“New Microsoft Word Document.docx”) – no pirmās teksta rindas;
      – ja no vienāda satura failiem paliek viens – labākais nosaukums no tiem (bez “Copy”, bez
        piedēkļiem, ar garumzīmēm);
      – “… - Copy” / “Copy of …” → tīrs nosaukums;
      – ja ieslēgta failu nosaukumu sakārtošana – pasvītras, paplašinājums, saīsinājumi, garumzīmes.
    Nosaukumi unikāli katrā galamērķa mapē. parraksti – {rel: nosaukums}, ko ievadījis lietotājs."""
    parraksti = parraksti or {}
    izmest = set(izmetamie(kopas))
    paliek = [f for f in faili if f["rel"] not in izmest]

    def mape_d(f):
        return f["dest"].rsplit("/", 1)[0] if "/" in f["dest"] else ""

    def vards(f):
        return f["iek"].rsplit("/", 1)[-1]
    aiznemti = defaultdict(set)
    for f in paliek:
        if not ir_bezvarda_dokuments(vards(f)):
            aiznemti[mape_d(f)].add(vards(f).casefold())
    rez, numurs = {}, 0
    # 1) bezvārda dokumenti
    for f in sorted(paliek, key=lambda f: (f["nr"], f["dest"])):
        if not ir_bezvarda_dokuments(vards(f)) and f["rel"] not in parraksti:
            continue
        ext = Path(vards(f)).suffix.lower()
        if f["rel"] in parraksti:
            pamats = Path(parraksti[f["rel"]]).stem if parraksti[f["rel"]].lower().endswith(ext) \
                else parraksti[f["rel"]]
        else:
            if f.get("teksts") is None:
                f["teksts"] = dokumenta_teksts(f["cels"])
            pamats = nosaukums_no_teksta(f["teksts"])
            if not pamats:
                numurs += 1
                pamats = f"{vietas_nosaukums or 'Dokuments'} dokuments {numurs:02d}"
            if _KARTOT_FAILUS:
                pamats = Path(sakartot_faila_nosaukumu(pamats + ext)).stem
        aiznemti[mape_d(f)].discard(vards(f).casefold())
        jauns, n = pamats + ext, 2
        while jauns.casefold() in aiznemti[mape_d(f)]:
            jauns, n = f"{pamats} ({n}){ext}", n + 1
        aiznemti[mape_d(f)].add(jauns.casefold())
        rez[f["rel"]] = jauns
    # 2) labākais nosaukums no vienāda satura failiem
    pec_rel = {f["rel"]: f for f in faili}
    labakais_vards = {}
    for k in kopas:
        for kl in k.get("klasteri", [k["versijas"]]):
            paliek_kl = [r for r in kl if r in k["paturet"]]
            if len(kl) < 2 or len(paliek_kl) != 1:
                continue
            vardi = [vards(pec_rel[r]) for r in kl if r in pec_rel]
            vardi = [v for v in vardi if not ir_bezvarda_dokuments(v)] or vardi
            labakais_vards[paliek_kl[0]] = max(vardi, key=lambda v: (nosaukuma_kvalitate(v, vardi), -len(v)))
    # 3) tīri / sakārtoti nosaukumi
    for f in sorted(paliek, key=lambda f: (f["nr"], f["dest"])):
        if f["rel"] in rez or ir_bezvarda_dokuments(vards(f)):
            continue
        sava = vards(f)
        bazes = labakais_vards.get(f["rel"], sava)
        bazes = Path(kopijas_pamats(bazes)[0]).stem + Path(sava).suffix
        if _KARTOT_FAILUS:
            bazes = sakartot_faila_nosaukumu(bazes)
        if bazes == sava or not derigs_nosaukums(bazes):
            continue
        if bazes.casefold() in aiznemti[mape_d(f)] and bazes.casefold() != sava.casefold():
            continue
        aiznemti[mape_d(f)].discard(sava.casefold())
        aiznemti[mape_d(f)].add(bazes.casefold())
        rez[f["rel"]] = bazes
    return rez


bezvarda_nosaukumi = paliekoso_nosaukumi      # vecais nosaukums (saderībai)


def izmetamie(kopas):
    """Relatīvie ceļi, ko izmest (uz _DUBLIKATI) pirms apvienošanas."""
    rez = []
    for k in kopas:
        for v in k["versijas"]:
            if v not in k["paturet"]:
                rez.append(v)
    return rez


def izpildit_darbus(sakne, darbi, zurnala_cels=None, log=print, progress=None, izmest=None, parsaukt=None,
                    tirisana=None):
    """Izpilda darbus.
    izmest   = {grupa: [rel]} – faili, kas pirms apvienošanas jāpārvieto uz _DUBLIKATI;
    parsaukt = {grupa: [(rel, jaunais_vārds)]} – faili (piem., bezvārda dokumenti), kas jāpārdēvē.
    Atgriež (statistika, kļūdu skaits, žurnāla ceļš, karantīnas ceļš)."""
    izmest = izmest or {}
    parsaukt = parsaukt or {}
    sakne = Path(sakne).resolve()
    laiks = datetime.now().strftime("%Y%m%d_%H%M%S")
    karantina = sakne / KARANTINA / laiks
    zcels = Path(zurnala_cels or f"zurnals_{laiks}.csv")
    zcels.parent.mkdir(parents=True, exist_ok=True)
    z = Zurnals(zcels)
    ap = Apvienotajs(sakne, z, karantina, True)
    kludas = 0

    def nodrosinat_mapi(p):
        """Izveido mapi (un vecākus), katru izveidi ierakstot žurnālā."""
        jaizveido = []
        while not p.exists():
            jaizveido.append(p)
            p = p.parent
        for q in reversed(jaizveido):
            q.mkdir()
            z.raksti("IZVEIDOTA_MAPE", "", q)

    try:
        # 0) failu kopijas, tukšie un pagaidu faili visā arhīvā (ja padoti)
        if tirisana:
            for x in tirisana.get("izmest", []):
                p = sakne / x["rel"]
                try:
                    if p.is_file():
                        ap.uz_karantinu(p)
                        ap.sk[{"kopija": "failu kopijas", "tukss": "tukši (0 baitu) faili"}.get(
                            x["veids"], "pagaidu/sistēmas faili")] += 1
                except Exception as e:
                    kludas += 1
                    log(f"  KĻŪDA: {x['rel']}: {e}")
            for rel, jauns in tirisana.get("parsaukt", []):
                p = sakne / rel
                try:
                    if p.is_file() and derigs_nosaukums(jauns) and p.name != jauns and not p.with_name(jauns).exists():
                        q = p.with_name(jauns)
                        parvietot(p, q)
                        z.raksti("PĀRVIETOTS", p, q)
                        ap.sk["kopijām atjaunots oriģinālais nosaukums"] += 1
                except Exception as e:
                    kludas += 1
                    log(f"  KĻŪDA: {rel}: {e}")
            if tirisana.get("dzest_tuksas_mapes", True):
                n = dzest_tuksas_mapes(sakne, z, log)
                if n:
                    ap.sk["izdzēstas tukšās mapes"] += n
        for i, d in enumerate(darbi, 1):
            if progress:
                progress(i, len(darbi), d.gid)
            try:
                # 1) pagaidu faili (~$…, Thumbs.db) – ārā
                for src, _ in d.soli:
                    for dirpath, dirnames, filenames in os.walk(src):
                        dirnames[:] = [x for x in dirnames if not sistemas(x)]
                        for f in filenames:
                            fp = Path(dirpath) / f
                            if ir_lieks(f):
                                ap.uz_karantinu(fp)
                                ap.sk["pagaidu/sistēmas faili"] += 1
                            elif ir_tukss(fp):
                                ap.uz_karantinu(fp)
                                ap.sk["tukši (0 baitu) faili"] += 1
                # 2) dublikāti un neizvēlētās versijas – ārā
                for rel in izmest.get(d.gid, []):
                    p = sakne / rel
                    if p.is_file():
                        ap.uz_karantinu(p)
                # 3) bezvārda dokumentu pārdēvēšana (vēl sākotnējā vietā)
                for rel, jauns in parsaukt.get(d.gid, []):
                    p = sakne / rel
                    if p.is_file() and derigs_nosaukums(jauns) and p.name != jauns:
                        q = p.with_name(jauns)
                        if q.exists() and not os.path.samefile(p, q):
                            q = unikals_vards(p.parent, jauns)
                        parvietot(p, q)
                        z.raksti("PĀRVIETOTS", p, q)
                        ap.sk["pārdēvēti faili (bezvārda dokumenti, kopijas)"] += 1
                # 4) mapes – galvenajā mapē vai apakšmapēs
                for src, dest in d.soli:
                    if not src.exists():
                        continue
                    if src == dest:
                        continue
                    if dest.exists() and os.path.samefile(src, dest):
                        os.rename(src, dest)            # tikai lielo/mazo burtu maiņa
                        z.raksti("PĀRVIETOTS", src, dest)
                        continue
                    if not dest.exists():
                        nodrosinat_mapi(dest.parent)
                        parvietot(src, dest)
                        z.raksti("PĀRVIETOTS", src, dest)
                        ap.sk["pārdēvētas/pārvietotas mapes"] += 1
                    else:
                        idx = ap.indekss(dest)
                        ap.apvienot(src, dest, idx)
                        ap.sk["apvienotas mapes"] += 1
            except Exception as e:
                kludas += 1
                log(f"  KĻŪDA grupā {d.gid}: {e}")
                z.raksti("KĻŪDA", d.gid, str(e))
    finally:
        z.aizvert()
    return dict(ap.sk), kludas, zcels, karantina


def analizet_darbus(sakne, darbi, kese=None, log=print):
    """Komandrindai: automātiskie lēmumi (dublikāti ārā, līdzīgie paliek, dokumentiem nosaukumi)."""
    izmest, parsaukt = {}, {}
    for d in darbi:
        an = analizet_grupu(sakne, d.mapes_rel, kese, apaksmapes=d.apaksmapes(),
                            vietas_nosaukums=d.dst.name)
        izmest[d.gid] = izmetamie(an[1])
        parsaukt[d.gid] = [(rel, jauns) for rel, jauns in an[2].items() if rel not in izmest[d.gid]]
    return izmest, parsaukt


def cmd_tirit(arg):
    sakne = Path(arg.arhivs).resolve()
    mapes, _ = atrast_mapes(sakne, arg.bez_burtiem)
    t = atrast_liekos_failus(sakne, mapes)
    print(f"Tukši/pagaidu faili: {len(t['lieki'])}, kopiju grupas: {len(t['kopiju_grupas'])} – salīdzinu saturu…")
    an = analizet_kopijas(sakne, t)
    sk = defaultdict(int)
    for k in an["kopas"]:
        sk[k["veids"]] += 1
    print(f"  identiskas: {sk['identiski']}, vizuāli vienādas: {sk['vienadi']}, līdzīgas (paliek visas): "
          f"{sk['jaizlemj']}, dažādas: {sk['atskirigi']}")
    (sakne / "_ZURNALI").mkdir(exist_ok=True)
    zc = sakne / "_ZURNALI" / f"zurnals_{datetime.now():%Y%m%d_%H%M%S}.csv"
    for k in an["kopas"]:                      # komandrindā līdzīgās paliek visas
        if k["veids"] == "jaizlemj":
            k["paturet"] = set(k["versijas"])
    rez, kludas, zc, kar = izpildit_darbus(sakne, [], zc, tirisana=tirisanas_darbibas(t, an))
    for k, v in rez.items():
        print(f"  {k}: {v}")
    print(f"Žurnāls: {zc}")


def cmd_apvienot(arg):
    sakne = Path(arg.arhivs).resolve()
    try:
        rindas = lasit_planu(arg.plans)
    except PlanaKluda as e:
        sys.exit(str(e))
    darbi = sagatavot_darbus(sakne, rindas, arg.bez_burtiem)

    print(f"Plānā {len(darbi)} grupas ar darbībām:\n")
    for d in darbi:
        print(f"[{d.gid}] → {d.dst.relative_to(sakne).as_posix()}")
        for src, dest in d.soli:
            kur = "galvenajā mapē" if dest == d.dst else f"apakšmapē “{dest.name}”"
            print(f"     {src.relative_to(sakne).as_posix()}  →  {kur}")
    if not arg.izpildit:
        print("\nTas bija tikai plāns – nekas netika mainīts. Lai izpildītu, pievieno --izpildit")
        return

    print("\nSalīdzinu failus (identiskie un vizuāli vienādie tiks izmesti, līdzīgie – paturēti visi)...")
    kese = None
    try:
        (sakne / "_ZURNALI").mkdir(exist_ok=True)
        kese = AttelaKese(sakne / "_ZURNALI" / "attelu_kese.sqlite")
    except Exception:
        pass
    izmest, parsaukt = analizet_darbus(sakne, darbi, kese)
    if kese:
        kese.aizvert()
    sk, kludas, zcels, karantina = izpildit_darbus(sakne, darbi, arg.zurnals, izmest=izmest, parsaukt=parsaukt)
    print("\nGatavs.")
    for k, v in sk.items():
        print(f"  {k}: {v}")
    if kludas:
        print(f"  kļūdas: {kludas} (skat. žurnālu)")
    print(f"Žurnāls: {zcels}  (atsaukšanai: python arhivs.py atsaukt \"{zcels}\")")
    print(f"Dublikāti pārvietoti uz: {karantina}")


def iztirit_liekos(sakne, zurnala_cels=None, log=print):
    """Visā arhīvā pārvieto pagaidu/sistēmas failus (~$…, Thumbs.db) uz _DUBLIKATI."""
    sakne = Path(sakne).resolve()
    laiks = datetime.now().strftime("%Y%m%d_%H%M%S")
    zcels = Path(zurnala_cels or f"zurnals_{laiks}.csv")
    zcels.parent.mkdir(parents=True, exist_ok=True)
    z = Zurnals(zcels)
    ap = Apvienotajs(sakne, z, sakne / KARANTINA / laiks, True)
    n = m = 0
    try:
        for dirpath, dirnames, filenames in os.walk(sakne):
            dirnames[:] = [x for x in dirnames if not sistemas(x)]
            for f in filenames:
                if ir_lieks(f) or ir_tukss(Path(dirpath) / f):
                    try:
                        ap.uz_karantinu(Path(dirpath) / f)
                        n += 1
                    except Exception as e:
                        log(f"  Neizdevās: {Path(dirpath) / f}: {e}")
        m = dzest_tuksas_mapes(sakne, z, log)
    finally:
        z.aizvert()
    log(f"Izmesti {n} pagaidu/sistēmas/tukši faili, izdzēstas {m} tukšās mapes.")
    return n, zcels, m


def atsaukt(zurnala_cels, log=print):
    """Atceļ visas žurnālā ierakstītās darbības. Atgriež kļūdu skaitu."""
    teksts = lasit_tekstu(zurnala_cels)
    rindas = list(csv.reader(teksts.splitlines(), delimiter=CSV_ATDALITAJS))[1:]
    kludas = 0
    for laiks, darb, no, uz in reversed([r[:4] for r in rindas if len(r) >= 4]):
        try:
            if darb in ("PĀRVIETOTS", "KARANTĪNA"):
                parvietot(uz, no)
            elif darb == "DZĒSTA_TUKŠA_MAPE":
                Path(no).mkdir(parents=True, exist_ok=True)
            elif darb == "IZVEIDOTA_MAPE":
                p = Path(uz)
                if p.is_dir() and not any(p.iterdir()):
                    p.rmdir()
        except Exception as e:
            kludas += 1
            log(f"  Neizdevās atsaukt {darb} {no} → {uz}: {e}")
    # notīra tukšās karantīnas mapes
    for r in rindas:
        if len(r) >= 4 and r[1] == "KARANTĪNA":
            p = Path(r[3]).parent
            while KARANTINA in p.parts and p.is_dir() and not any(p.iterdir()):
                p.rmdir()
                p = p.parent
    # atzīmē žurnālu kā atsauktu, lai to nejauši neatsauktu divreiz
    try:
        zc = Path(zurnala_cels)
        zc.rename(zc.with_name(zc.stem + "_ATSAUKTS" + zc.suffix))
    except OSError:
        pass
    return kludas


def cmd_atsaukt(arg):
    kludas = atsaukt(arg.zurnals)
    print(f"Atsaukšana pabeigta. Kļūdas: {kludas}")


# ---------------------------------------------------------------------------
# Identiska satura failu atskaite
# ---------------------------------------------------------------------------
def dalejs_jaucejs(p, n=65536):
    with open(p, "rb") as f:
        return hashlib.sha1(f.read(n)).hexdigest()


def cmd_dublikati(arg):
    sakne = Path(arg.arhivs).resolve()
    pec_izm = defaultdict(list)
    print("Skenēju failus...")
    for dirpath, dirnames, filenames in os.walk(sakne):
        dirnames[:] = [d for d in dirnames if not sistemas(d)]
        for f in filenames:
            if ir_lieks(f):
                continue
            p = Path(dirpath) / f
            try:
                s = p.stat().st_size
            except OSError:
                continue
            if s > 0:
                pec_izm[s].append(p)
    kandidati = [v for v in pec_izm.values() if len(v) > 1]
    print(f"  {sum(len(v) for v in kandidati)} faili ar sakrītošu izmēru, salīdzinu saturu...")
    grupas = []
    for faili in kandidati:
        pec_dal = defaultdict(list)
        for p in faili:
            pec_dal[dalejs_jaucejs(p)].append(p)
        for d in pec_dal.values():
            if len(d) < 2:
                continue
            pec_pilna = defaultdict(list)
            for p in d:
                pec_pilna[jaucejs(p)].append(p)
            grupas.extend(v for v in pec_pilna.values() if len(v) > 1)
    with open(arg.izeja, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f, delimiter=CSV_ATDALITAJS)
        w.writerow(["grupa", "izmērs_KB", "fails", "vietas_mape"])
        lieki = 0
        for i, g in enumerate(sorted(grupas, key=lambda g: -g[0].stat().st_size), 1):
            lieki += g[0].stat().st_size * (len(g) - 1)
            for p in g:
                rel = p.relative_to(sakne).parts
                vieta = "/".join(rel[:2]) if len(rel) > 2 else ""
                w.writerow([f"D{i:05d}", round(p.stat().st_size / 1024), "/".join(rel), vieta])
    print(f"Identiska satura grupas: {len(grupas)}, lieki aizņemtā vieta ~{lieki / 1048576:.0f} MB")
    print(f"Atskaite: {arg.izeja}")


# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description="Piļu, muižu un vietu arhīva kārtotājs")
    sub = ap.add_subparsers(dest="komanda", required=True)

    p = sub.add_parser("vietvardi", help="lejupielādēt vietvārdu sarakstu no Wikidata")
    p.add_argument("--izeja", default="vietvardi.txt")
    p.set_defaults(fn=cmd_vietvardi)

    p = sub.add_parser("skenet", help="analizēt arhīvu un izveidot plānu (neko nemaina)")
    p.add_argument("arhivs")
    p.add_argument("--saraksts", action="append", help="vietvārdu saraksts (.txt vai .csv); var norādīt vairākkārt")
    p.add_argument("--izeja", default="grupas.csv")
    p.add_argument("--bez-burtiem", action="store_true", help="vietu mapes ir tieši arhīva saknē")
    p.add_argument("--troksnis", default=TROKSNIS_NOKLUSETAIS,
                   help=f"nenozīmīgās piebildes mapju nosaukumos (noklusējums: \"{TROKSNIS_NOKLUSETAIS}\")")
    p.add_argument("--etaps", type=int, choices=(1, 2), default=2,
                   help="1 – tikai kopijas; 2 – vieta, objekti, apakšmapes (noklusējums)")
    p.add_argument("--objekti-apaksmapes", action="store_true",
                   help="2. etapā objektus (Remtes baznīca) likt vietas mapē (Remte\\Remtes baznīca)")
    p.set_defaults(fn=cmd_skenet)

    p = sub.add_parser("tirit", help="izmest pagaidu/sistēmas failus (~$…, Thumbs.db) no visa arhīva")
    p.add_argument("arhivs")
    p.add_argument("--bez-burtiem", action="store_true")
    p.set_defaults(fn=cmd_tirit)

    p = sub.add_parser("apvienot", help="izpildīt plānu (bez --izpildit tikai parāda)")
    p.add_argument("arhivs")
    p.add_argument("--plans", default="grupas.csv")
    p.add_argument("--izpildit", action="store_true")
    p.add_argument("--zurnals")
    p.add_argument("--bez-burtiem", action="store_true")
    p.set_defaults(fn=cmd_apvienot)

    p = sub.add_parser("atsaukt", help="atcelt apvienošanu pēc žurnāla")
    p.add_argument("zurnals")
    p.set_defaults(fn=cmd_atsaukt)

    p = sub.add_parser("dublikati", help="atskaite par identiska satura failiem (neko nemaina)")
    p.add_argument("arhivs")
    p.add_argument("--izeja", default="dublikati.csv")
    p.set_defaults(fn=cmd_dublikati)

    arg = ap.parse_args()
    arg.fn(arg)


if __name__ == "__main__":
    main()
