# -*- coding: utf-8 -*-
"""
Programmas atjaunināšana no GitHub.

Publiskajā repozitorijā  askoldsb/arhiva-kartotajs-releases  ir fails latest.json ar jaunāko versiju
(numurs, zip adrese, sha256, kas jauns). Programma to nolasa, lejupielādē zip, pārbauda kontrolsummu,
iepriekšējo versiju noliek mapē _vecas_versijas un ieliek jaunos programmas failus.
Lietotāja dati (arhīvs, lēmumi, vardnica.txt, iestatījumi) netiek aiztikti.
"""
import hashlib
import json
import shutil
import ssl
import tempfile
import urllib.request
import zipfile
from datetime import datetime
from pathlib import Path

VERSIJA = "1.0.1"
MANIFESTS_URL = "https://raw.githubusercontent.com/askoldsb/arhiva-kartotajs-releases/main/latest.json"

PROGRAMMAS_MAPE = Path(__file__).resolve().parent
# faili, ko atjauninājums aizstāj
KODA_FAILI = ["arhivs.py", "arhivs_gui.py", "atjauninatajs.py", "LASIMANI.md", "Palaist.bat"]
# faili, ko ieliek tikai tad, ja to vēl nav (lietotājs tos var būt atjauninājis pats)
DATU_FAILI = ["vietvardi.txt", "vietvardi_pilns.txt"]
VECAS_VERSIJAS = "_vecas_versijas"


def versijas_skaitli(v):
    out = []
    for d in str(v).strip().lstrip("vV").split("."):
        try:
            out.append(int(d))
        except ValueError:
            out.append(0)
    return tuple(out + [0] * (3 - len(out)))


def ir_jaunaka(v, pret=VERSIJA):
    return versijas_skaitli(v) > versijas_skaitli(pret)


def _atvert(url, timeout):
    req = urllib.request.Request(url, headers={"User-Agent": f"arhiva-kartotajs/{VERSIJA}",
                                               "Cache-Control": "no-cache"})
    return urllib.request.urlopen(req, timeout=timeout, context=ssl.create_default_context())


def iegut_manifestu(kanals="stable", timeout=15):
    """Atgriež {'version', 'url', 'sha256', 'size', 'date', 'notes': {'lv': [...]}} vai izmet kļūdu."""
    with _atvert(MANIFESTS_URL + f"?t={datetime.now():%Y%m%d%H%M%S}", timeout) as r:
        dati = json.loads(r.read().decode("utf-8"))
    info = dati.get(kanals) or dati.get("stable")
    if not info or "version" not in info or "url" not in info:
        raise ValueError("Atjauninājumu manifestā nav versijas informācijas.")
    return info


def jaunumi(info, valoda="lv"):
    n = info.get("notes") or {}
    return n.get(valoda) or n.get("lv") or []


def uzstadit(info, progress=lambda teksts: None, timeout=60):
    """Lejupielādē un uzstāda versiju. Atgriež uzstādīto versiju; kļūdas gadījumā neko nemaina."""
    tmp = Path(tempfile.mkdtemp(prefix="arhiva_atj_"))
    try:
        zf = tmp / "versija.zip"
        progress(f"Lejupielādēju versiju {info['version']}…")
        h = hashlib.sha256()
        with _atvert(info["url"], timeout) as r, open(zf, "wb") as f:
            while True:
                b = r.read(65536)
                if not b:
                    break
                h.update(b)
                f.write(b)
        if info.get("sha256") and h.hexdigest().lower() != info["sha256"].lower():
            raise ValueError("Lejupielādētais fails ir bojāts (nesakrīt kontrolsumma). Nekas netika mainīts.")
        progress("Pārbaudu failus…")
        izp = tmp / "x"
        with zipfile.ZipFile(zf) as z:
            for n in z.namelist():
                if n.startswith("/") or ".." in Path(n).parts:
                    raise ValueError(f"Aizdomīgs ceļš arhīvā: {n}")
            z.extractall(izp)
        # faili var būt arhīva saknē vai vienā apakšmapē
        sakne = izp
        if not (sakne / "arhivs_gui.py").exists():
            apaks = [p for p in izp.iterdir() if p.is_dir() and (p / "arhivs_gui.py").exists()]
            if not apaks:
                raise ValueError("Arhīvā nav programmas failu. Nekas netika mainīts.")
            sakne = apaks[0]
        for f in ("arhivs.py", "arhivs_gui.py"):
            compile((sakne / f).read_text(encoding="utf-8"), f, "exec")   # sintakses pārbaude
        # vecās versijas rezerves kopija
        progress("Saglabāju iepriekšējo versiju…")
        rez = PROGRAMMAS_MAPE / VECAS_VERSIJAS / f"{VERSIJA}_{datetime.now():%Y%m%d_%H%M%S}"
        rez.mkdir(parents=True, exist_ok=True)
        for f in KODA_FAILI:
            if (PROGRAMMAS_MAPE / f).exists():
                shutil.copy2(PROGRAMMAS_MAPE / f, rez / f)
        progress("Ielieku jauno versiju…")
        for f in KODA_FAILI:
            if (sakne / f).exists():
                shutil.copy2(sakne / f, PROGRAMMAS_MAPE / f)
        for f in DATU_FAILI:
            if (sakne / f).exists() and not (PROGRAMMAS_MAPE / f).exists():
                shutil.copy2(sakne / f, PROGRAMMAS_MAPE / f)
        return info["version"]
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
